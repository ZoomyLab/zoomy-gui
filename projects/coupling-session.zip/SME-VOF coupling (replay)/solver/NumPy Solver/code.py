"""sme_vof — GUI REPLAY of the recorded SME(1)<->VOF preCICE coupled run.

The REAL solver invocation is the case's own run.py (thesis/notebooks/coupling/
cases/sme_vof): the emitted zoomyFoam_L1w SME participant and stock OpenFOAM
incompressibleVoF run coupled through preCICE inside the openfoam container —
an environment the pullable backend images do not carry. The full coupled
benchmark takes ~33 s wall; rerun it in the case folder with:

    python run.py --level 1 --snap gui_l1

This card materializes that recorded run (raw foam time dirs + h5 stores) so
the Visualization card recomposes the case's real figures from the actual
participant outputs. Replayed data, clearly labeled — no simulation happens
here.
"""
import io
import os
import shutil
import tarfile
import urllib.request

PAYLOAD = ("https://github.com/ZoomyLab/Zoomy/releases/download/"
           "case-data-v1/sme_vof_snap_gui_l1.tar.gz")
RUN = "snap_gui_l1"

if not os.path.isdir(RUN):
    print("fetching recorded coupled run:", PAYLOAD, flush=True)
    with urllib.request.urlopen(PAYLOAD, timeout=180) as r:
        _buf = io.BytesIO(r.read())
    with tarfile.open(fileobj=_buf, mode="r:gz") as t:
        t.extractall(".")
    print("extracted ->", RUN)
else:
    print("recorded run already present ->", RUN)

shutil.copy(os.path.join(RUN, "outputs", "swe_case.h5"), "simulation.h5")
print("artifact -> simulation.h5 (SME participant store; VOF store at "
      + RUN + "/outputs/vof_case.h5)")
