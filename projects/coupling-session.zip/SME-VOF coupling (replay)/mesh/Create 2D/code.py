"""sme_vof — GUI folder-case `mesh.py`: both participants' meshes.

The meshes are structured blockMesh channels written by `generate.py`
(swe_case: 1-D 120 cells on [-0.6, 0]; vof_case: 120x40 on [0, 1.5]x[0, 0.4],
optionally NZ layers 3-D) as part of the full case tree — mesh dicts land in
`<RUNDIR>/{swe_case,vof_case}/system/blockMeshDict` and `blockMesh` runs
inside the container (run.py).  This wrapper regenerates the tree so the GUI
has a single mesh entry point.

Usage: mesh.py [LEVEL [WINDOW SCHEME GHOST FROZEN LEDGER]]
"""
import json
import subprocess
import sys
from pathlib import Path

import os
HERE = (Path(__file__).resolve().parent
        if "__file__" in globals() else Path(os.getcwd()))
_SJ = HERE / "settings.json"
#: embedded copy of the case settings; a sibling settings.json is used only
#: when it is the CASE file ("level" key) — the GUI writes a generic one.
S = (json.loads(_SJ.read_text()) if _SJ.exists() else {})
if "level" not in S:
    S = {'name': 'sme_vof',
 'title': 'SME(level) <-> VOF two-way coupled dam break (preCICE)',
 'level': 1,
 'window': 0.002,
 'scheme': 'parallel-explicit',
 'ghost': 'characteristic',
 'outer': 'wall',
 'frozen': 'auto',
 'ledger': 20,
 'closure': 'newtonian',
 'nu': 0.005,
 'lambda_s': 0.1,
 'notes': 'production scheme: characteristic ghost + qstarMode=rp mass row '
          '(generate.py defaults); outputs replayed by visualize.py'}

_gen = HERE / "generate.py"
if _gen.exists():
    args = sys.argv[1:] or [str(S["level"]), str(S["window"]), S["scheme"],
                            S["ghost"], str(S["frozen"]), str(S["ledger"])]
    subprocess.run([sys.executable, str(_gen), *args], check=True)
    print("mesh dicts in RUNDIR/{swe_case,vof_case}/system/blockMeshDict")
else:
    print("replay session: the recorded run tree (snap_gui_l1/*/system/"
          "blockMeshDict) already carries both participants' meshes; the full "
          "case regenerates them via generate.py (see the case folder).")
