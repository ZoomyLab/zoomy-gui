"""sme_vof — GUI folder-case `visualize.py`: recompose the case figures.

Thin config over the generalized column-plot layer
(`zoomy_core.postprocessing.column_plots` — the migration source for the
zoomy_plotting panel collection): the standard 3-panel coupled view
(SME free surface + moment profiles | interface | VOF columns) as a PNG
snapshot and the animation GIF — the same figures the campaign shipped
(sme_vof_L0_ws3.gif family).  Reads the foam run tree; the h5 store
(RUNDIR/outputs/*.h5, written by run.py) is the GUI's replay payload.

Usage: visualize.py [RUNDIR] [--level N] [--gif]
"""
import argparse
import json
from pathlib import Path

import numpy as np

import os
HERE = (Path(__file__).resolve().parent
        if "__file__" in globals() else Path(os.getcwd()))
_SJ = HERE / "settings.json"
#: embedded copy of the case settings; a sibling settings.json is used only
#: when it is the CASE file ("level" key) — the GUI writes a generic one.
S = (json.loads(_SJ.read_text()) if _SJ.exists() else {})
if "level" not in S:
    S = {'name': 'sme_vof',
 'title': 'SME(level) <-> VOF two-way coupled dam break (preCICE)',
 'level': 1,
 'window': 0.002,
 'scheme': 'parallel-explicit',
 'ghost': 'characteristic',
 'outer': 'wall',
 'frozen': 'auto',
 'ledger': 20,
 'closure': 'newtonian',
 'nu': 0.005,
 'lambda_s': 0.1,
 'notes': 'production scheme: characteristic ghost + qstarMode=rp mass row '
          '(generate.py defaults); outputs replayed by visualize.py'}


def main():
    class a:                     # GUI replay card: fixed args
        rundir = "snap_gui_l1"   # materialized by the Run section
        level = S["level"]
        gif = True
    run = Path(a.rundir)

    from zoomy_core.model.models import SME
    from zoomy_core.systemmodel import SystemModel
    from zoomy_core.model.boundary_conditions import (
        BoundaryConditions, Coupled, FromModel)
    from zoomy_core.postprocessing import style
    style.use("screen")
    from zoomy_core.postprocessing.column_plots import (
        read_columns, read_zoomyfoam, read_vof_raw, fig_coupling, animate)
    import matplotlib.pyplot as plt

    bcs = BoundaryConditions([FromModel(tag="outer", definition="wall"),
                              Coupled(tag="coupled", mesh_name="interface")])
    sm = SystemModel.from_model(SME(level=a.level, boundary_conditions=bcs))
    x = np.linspace(-0.6, 0, 121)
    x = 0.5 * (x[:-1] + x[1:])

    sme = read_zoomyfoam(str(run / "swe_case"), sm, 120, x, K=40, label="SME")
    vif = read_columns(str(run / "vof_case"), label="VOF")
    raw, vmid = read_vof_raw(str(run / "vof_case"), nx=120, ny=40,
                             lx=1.5, ly=0.4, stations=[0.75], label="VOF")
    panels = [("mid SME", -0.30, [sme], "tab:blue"),
              ("interface", 0.00, [sme, vif], "tab:purple"),
              ("mid VOF", 0.75, [vmid], "tab:green")]

    def compose(fig, t):
        fig_coupling(fig, t, sme, raw, panels, interface_x=0.0,
                     xlim=(-0.6, 1.5), ylim=(0, 0.22), ulim=(-0.6, 0.6),
                     title=f"SME({a.level}) | VOF   t={t:5.2f}s")

    # final-time snapshot PNG
    fig = plt.figure(figsize=(10, 6))
    compose(fig, float(sme.t[-1]))
    png = run / f"sme_vof_L{a.level}_final.png"
    fig.savefig(png, dpi=130)
    print("->", png)

    # --- closed-run mass audit (reuse analysis/total_mass_audit) -------------
    import sys as _sys
    _sys.path.insert(0, str(HERE / "analysis"))
    try:
        from total_mass_audit import mass_series
        ts, Ms, Mv = mass_series(run)
        M = Ms + Mv
        figm, axm = plt.subplots(figsize=(8, 4))
        axm.plot(ts, (M - M[0]) * 1e3, "k-", lw=1.6, label="total M(t)−M(0)")
        axm.plot(ts, (Ms - Ms[0]) * 1e3, "tab:blue", lw=1.0, ls="--", label="SME ∫h dx")
        axm.plot(ts, (Mv - Mv[0]) * 1e3, "tab:green", lw=1.0, ls="--", label="VOF ∫α dA")
        axm.axhline(0.0, color="0.6", lw=0.8)
        axm.set(xlabel="t [s]", ylabel="mass change [$10^{-3}$ m$^2$]",
                title=f"closed-run mass audit  "
                      f"drift={M[-1]-M[0]:+.2e} m² ({(M[-1]-M[0])/M[0]*100:+.3f}%)")
        axm.grid(alpha=0.3); axm.legend(fontsize=9)
        figm.tight_layout()
        pmass = run / f"sme_vof_L{a.level}_mass_audit.png"
        figm.savefig(pmass, dpi=130); plt.close(figm)
        print("->", pmass)
    except Exception as e:                                   # pragma: no cover
        print("mass audit skipped:", e)

    # --- interface height: coupled vs monolithic VOF (when the mono reference
    #     series analysis/mono_interface_ref.npy is present; skip otherwise) ---
    try:
        import compare_mono_coupled as cmc
        cmc.figure(cmc.read_coupled_data(run),          # prints '->' or 'skipped'
                   out=run / "interface_h_mono_vs_coupled.png")
    except Exception as e:                                   # pragma: no cover
        print("mono-vs-coupled comparison skipped:", e)

    if a.gif:
        gif = run / f"sme_vof_L{a.level}.gif"
        animate(compose, list(sme.t), str(gif), figsize=(10, 6), fps=8)
        print("->", gif)


main()
