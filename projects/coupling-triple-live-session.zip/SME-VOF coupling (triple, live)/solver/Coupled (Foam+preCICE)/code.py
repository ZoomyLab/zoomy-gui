"""sme_vof — LIVE two-way SME(1)<->VOF preCICE coupled run.

Drives the case's OWN run.py IN PLACE on the server machine: the coupled case
needs its full tree (generate.py, compile.sh, run.sh, vof_template/) which the
composed folder cannot carry. The foam backend container (zoomy_openfoam) sees
the host home via apptainer's default binds, so the standard gaia checkout
path works out of the box; override with SME_VOF_CASE for other layouts.
On-demand model compile ~30 s (cached binary afterwards); coupled run ~30 s.
"""
import json
import os
import shutil
import subprocess
import sys

CASE = os.environ.get(
    "SME_VOF_TRIPLE_CASE",
    "/Users/adam-obbpb5az1dhsjzf/git/Zoomy/thesis/notebooks/coupling/cases/sme_vof_triple")
if not os.path.isdir(CASE):
    raise SystemExit(
        "live coupling needs the case tree on the server machine: " + CASE +
        " not found — set SME_VOF_CASE or bind the Zoomy checkout into the container")

# honor the GUI time knob when present (pair runs t=0..4 by default)
_gui = globals().get("settings")
snap = "gui_live_triple"
cmd = [sys.executable, os.path.join(CASE, "run.py"), "--snap", snap]
print("live coupled run:", " ".join(cmd), flush=True)
subprocess.run(cmd, check=True, cwd=CASE)

run_dir = os.path.join(CASE, "snap_" + snap)
shutil.copy(os.path.join(run_dir, "outputs", "swe_case.h5"), "simulation.h5")
# render the case's real figures on the fresh run tree, then stage them
subprocess.run([sys.executable, os.path.join(CASE, "visualize.py"), run_dir],
               check=True, cwd=CASE)
for name in os.listdir(run_dir):
    if name.endswith((".png", ".gif")):
        shutil.copy(os.path.join(run_dir, name), name)
print("artifact -> simulation.h5 (SME participant store; full run tree at "
      + run_dir + ")")
