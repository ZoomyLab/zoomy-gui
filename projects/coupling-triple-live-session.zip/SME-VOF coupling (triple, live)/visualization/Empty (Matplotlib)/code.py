"""sme_vof_triple — GUI folder-case `visualize.py`: recompose the TRIPLE view.

Reads the three-participant foam run tree (swe_case | vof_case | swe2_case,
closed box) written by run.py and composes the five-station SME|VOF|SME
picture — mid SME | intf L | mid VOF | intf R | mid SME2 — as a final-time
PNG + GIF plus the closed-box mass audit, in the same styling family as the
sme_vof pair figures (`sme_vof_sme_triple.gif`). Column tools are the shared
`zoomy_core.postprocessing.column_plots` layer (as the pair's visualize.py).

Usage: visualize.py [RUNDIR] [--level N] [--no-gif]
"""
import argparse
import json
from pathlib import Path

import numpy as np

import os
HERE = (Path(__file__).resolve().parent
        if "__file__" in globals() else Path(os.getcwd()))
_SJ = HERE / "settings.json"
#: embedded copy of the case settings; a sibling settings.json is used only
#: when it is the CASE file ("level" key) — the GUI writes a generic one.
S = (json.loads(_SJ.read_text()) if _SJ.exists() else {})
if "level" not in S:
    S = {'name': 'sme_vof_triple',
 'title': 'SME(level) | VOF | SME(level) three-participant coupled dam break '
          '(preCICE)',
 'level': 1,
 'window': 0.002,
 'scheme': 'parallel-explicit',
 'ghost': 'characteristic',
 'outer': 'wall',
 'frozen': 'auto',
 'ledger': 20,
 'closure': 'newtonian',
 'nu': 0.005,
 'lambda_s': 0.1,
 'notes': 'triple sibling of sme_vof: SME|VOF|SME closed box '
          '(coupling-scheme:multi, MODE=triple in generate.py driven by '
          'run.sh). Same production coupling scheme as the pair '
          '(characteristic ghost + qstarMode=rp mass row). run.py routes '
          'run.sh (three participants: swe_case, swe2_case, vof_case); '
          'outputs replayed by visualize.py.'}


def main():
    class a:                     # GUI replay card: fixed args
        rundir = "snap_gui_live_triple"   # materialized by the Run section
        level = S["level"]
        no_gif = False
    run = Path(a.rundir)

    from zoomy_core.model.models import SME
    from zoomy_core.systemmodel import SystemModel
    from zoomy_core.model.boundary_conditions import (
        BoundaryConditions, Coupled, FromModel)
    from zoomy_core.postprocessing import style
    style.use("screen")
    from zoomy_core.postprocessing.column_plots import (
        read_zoomyfoam, read_vof_raw, plot_water_columns, plot_water_vof,
        plot_profiles, mark_stations, frame_color, animate)
    import matplotlib.pyplot as plt

    bcs = BoundaryConditions([FromModel(tag="outer", definition="wall"),
                              Coupled(tag="coupled", mesh_name="interface")])
    sm = SystemModel.from_model(SME(level=a.level, boundary_conditions=bcs))
    x1 = np.linspace(-0.6, 0, 121); x1 = 0.5 * (x1[:-1] + x1[1:])
    x2 = np.linspace(1.5, 2.1, 121); x2 = 0.5 * (x2[:-1] + x2[1:])

    sme1 = read_zoomyfoam(str(run / "swe_case"), sm, 120, x1, K=40, label="SME")
    sme2 = read_zoomyfoam(str(run / "swe2_case"), sm, 120, x2, K=40, label="SME")
    raw, vmid = read_vof_raw(str(run / "vof_case"), nx=120, ny=40, lx=1.5,
                             ly=0.4, stations=[0.75], label="VOF")

    panels = [("mid SME", -0.30, [sme1], "tab:blue"),
              ("intf L", 0.00, [sme1, vmid], "tab:purple"),
              ("mid VOF", 0.75, [vmid], "tab:green"),
              ("intf R", 1.50, [sme2, vmid], "tab:orange"),
              ("mid SME2", 1.80, [sme2], "tab:red")]

    def draw(fig, t):
        gs = fig.add_gridspec(2, len(panels), height_ratios=[1.2, 1.0],
                              hspace=0.45, wspace=0.45)
        ax = fig.add_subplot(gs[0, :])
        plot_water_vof(ax, raw, t, color=style.COLORS["water"])
        plot_water_columns(ax, sme1, t, style="fill",
                           color=style.COLORS["water"])
        plot_water_columns(ax, sme2, t, style="fill",
                           color=style.COLORS["water"])
        for xi in (0.0, 1.5):
            ax.axvline(xi, color=style.COLORS["interface"], lw=1.6)
        mark_stations(ax, [s for _, s, _, _ in panels],
                      [c for _, _, _, c in panels],
                      labels=[n for n, _, _, _ in panels])
        ax.set_xlim(-0.6, 2.1); ax.set_ylim(0, 0.22)
        ax.set_title(f"SME({a.level}) | VOF | SME({a.level})   t = {t:5.2f} s")
        for k, (name, xq, src, color) in enumerate(panels):
            aa = fig.add_subplot(gs[1, k])
            plot_profiles(aa, src, xq, t,
                          colors=[style.COLORS["reduced"],
                                  style.COLORS["resolved"]][:len(src)])
            aa.set_title(name); aa.set_xlim(-0.6, 0.6); frame_color(aa, color)
        style.figure_legend(fig, extra=[
            ("interface", style.line("interface")),
            ("water", style.line("water", lw=5))])

    # final-time snapshot PNG
    fig = plt.figure(figsize=(13, 6.5))
    draw(fig, float(sme1.t[-1]))
    png = run / f"sme_vof_L{a.level}_triple_final.png"
    fig.savefig(png, dpi=130); plt.close(fig)
    print("->", png)

    # --- closed-box mass audit: SME1 + SME2 + VOF (total_mass_audit sums the
    #     second SME participant automatically when swe2_case is present) ------
    import sys as _sys
    _sys.path.insert(0, str(HERE / "analysis"))
    try:
        from total_mass_audit import mass_series
        ts, Ms, Mv = mass_series(run)
        M = Ms + Mv
        figm, axm = plt.subplots(figsize=(8, 4))
        axm.plot(ts, (M - M[0]) * 1e3, "k-", lw=1.6, label="total M(t)−M(0)")
        axm.plot(ts, (Ms - Ms[0]) * 1e3, "tab:blue", lw=1.0, ls="--",
                 label="SME ∫h dx (both)")
        axm.plot(ts, (Mv - Mv[0]) * 1e3, "tab:green", lw=1.0, ls="--",
                 label="VOF ∫α dA")
        axm.axhline(0.0, color="0.6", lw=0.8)
        axm.set(xlabel="t [s]", ylabel="mass change [$10^{-3}$ m$^2$]",
                title=f"closed triple-run mass audit  "
                      f"drift={M[-1]-M[0]:+.2e} m² "
                      f"({(M[-1]-M[0])/M[0]*100:+.3f}%)")
        axm.grid(alpha=0.3); axm.legend(fontsize=9); figm.tight_layout()
        pmass = run / f"sme_vof_L{a.level}_triple_mass_audit.png"
        figm.savefig(pmass, dpi=130); plt.close(figm)
        print("->", pmass)
    except Exception as e:                                   # pragma: no cover
        print("mass audit skipped:", e)

    if not a.no_gif:
        gif = run / f"sme_vof_L{a.level}_triple.gif"
        animate(draw, list(sme1.t), str(gif), figsize=(13, 6.5), fps=8)
        print("->", gif)


main()
