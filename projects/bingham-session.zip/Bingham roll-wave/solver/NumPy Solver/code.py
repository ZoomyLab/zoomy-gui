"""Bingham roll wave (numpy backend) — GUI folder-case ``run.py`` (REQ-136).

Reads ``settings.json``, builds the 1-D periodic mesh + SME(+Bingham) model
(IC/BC baked), constructs the REAL numpy engine with the exact kwargs of the
canonical ``bingham_permanent_rollwave.py`` (``adaptive(CFL=0.9, dimension=1,
dt_max=dt_cap)``, order-1 reconstruction — passed through untouched), does ONE
CONTINUOUS solve (NOT the NFRM restart loop) and writes ``output/<name>.h5``
(``/mesh`` + ``iteration_*`` snapshots).

The continuous-solve + HDF5-snapshot mechanism is the one proven faithful in
``bingham_jax_periodic_blocker.py::numpy_amps`` (continuous == windowed here,
verified there).  The server executes this file as-is in the backend container.

Standalone: ``python run.py``.
"""

import json
import os
import time

from zoomy_core.fvm.solver_numpy import HyperbolicSolver
from zoomy_core.fvm import timestepping
from zoomy_core.mesh import BaseMesh  # noqa: F401  (keeps the numpy stack imported)
from zoomy_core.misc.misc import Settings, Zstruct, get_main_directory

# Case modules: defined by the Model/Mesh cells in notebook form;
# imported from the sibling files in a materialized case folder.
try:
    build_mesh, build_model  # noqa: B018  (probe the notebook namespace)
except NameError:
    from mesh import build_mesh
    from model import build_model

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())


#: Full benchmark settings (the canonical case's settings.json), used whenever
#: the sibling settings.json is absent (notebook) or GUI-generic (no "numerics").
_CASE_SETTINGS = {'name': 'bingham_permanent_rollwave',
 'backend': 'numpy',
 'model': {'type': 'SME',
           'level': 2,
           'quadrature_order': 12,
           'rheology': 'bingham',
           'n': 1,
           'alpha': 0.3,
           'beta': 27.0,
           'g': 9.81,
           's': 0.1,
           'H0': 1.0,
           'lambda_s': 50.0},
 'ic': {'wavenumber': 1.2, 'seed_amplitude': 0.01},
 'mesh': {'n_inner_cells': 1000},
 'numerics': {'order': 1,
              'cfl': 0.9,
              'riemann': 'rusanov',
              'reconstruction_variables': 'conservative',
              'dt_cap_safety': 0.4},
 'run': {'solver': 'explicit', 't_end_prime': 200.0, 'snapshots': 81}}


def load_settings(path=None):
    p = path or os.path.join(CASE_DIR, "settings.json")
    s = json.load(open(p)) if os.path.exists(p) else {}
    if "numerics" not in s:                       # GUI-generic or missing
        gui = s or (globals().get("settings")
                    if isinstance(globals().get("settings"), dict) else None) or {}
        s = json.loads(json.dumps(_CASE_SETTINGS))
        if gui.get("time_end") is not None:       # GUI knob = t' (t_end_prime)
            s["run"] = dict(s["run"], t_end_prime=float(gui["time_end"]))
    return s


def run(settings=None):
    """Build + solve from ``settings`` (dict or None → settings.json).  Returns
    the output ``.h5`` path."""
    if settings is None:
        settings = load_settings()
    name = settings.get("name", "bingham_permanent_rollwave")
    num, run_cfg = settings["numerics"], settings["run"]

    mesh = build_mesh(settings, CASE_DIR)
    bundle = build_model(settings, mesh, CASE_DIR)
    nsm, sc, dtc = bundle["nsm"], bundle["sc"], bundle["dt_cap"]
    t_end = run_cfg["t_end_prime"] * sc["tscale"]      # t' -> physical time
    print(f"[{name}] mesh: {mesh.n_inner_cells} cells; "
          f"states={[str(s) for s in bundle['sm'].state]}; "
          f"nu={sc['nu']:.4f} lambda={sc['lam_wave']:.2f} "
          f"tscale={sc['tscale']:.3f} T={t_end:.1f}s dt_cap={dtc:.5f}", flush=True)

    out_rel = os.path.relpath(os.path.join(CASE_DIR, "output"), get_main_directory())
    solver = HyperbolicSolver(
        time_end=t_end,
        compute_dt=timestepping.adaptive(
            CFL=num.get("cfl", 0.9), dimension=1, dt_max=dtc),
        settings=Settings(name=name, output=Zstruct(
            directory=out_rel, filename=name,
            snapshots=run_cfg.get("snapshots", 81), clean_directory=False)))

    print(f"[{name}] solving t_end={t_end:.1f}s "
          f"(t'={run_cfg['t_end_prime']}, order={num.get('order', 1)}) ...",
          flush=True)
    t0 = time.perf_counter()
    solver.solve(mesh, nsm, write_output=True)
    h5 = os.path.join(CASE_DIR, "output", name + ".h5")
    print(f"[{name}] done ({time.perf_counter()-t0:.0f}s) -> {h5}", flush=True)
    return h5


_h5 = run()
import shutil

shutil.copy(_h5, "simulation.h5")   # standard artifact name (viz prelude / postproc)
print("artifact -> simulation.h5")
