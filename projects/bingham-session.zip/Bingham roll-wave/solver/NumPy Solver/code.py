"""Bingham roll wave (numpy backend) — GUI folder-case ``run.py`` (REQ-136).

Reads ``settings.json``, builds the 1-D periodic mesh + SME(+Bingham) model
(IC/BC baked), constructs the REAL numpy engine with the exact kwargs of the
canonical ``bingham_permanent_rollwave.py`` (``adaptive(CFL=0.9, dimension=1,
dt_max=dt_cap)``, order-1 reconstruction — passed through untouched), does ONE
CONTINUOUS solve (NOT the NFRM restart loop) and writes ``output/<name>.h5``
(``/mesh`` + ``iteration_*`` snapshots).

The continuous-solve + HDF5-snapshot mechanism is the one proven faithful in
``bingham_jax_periodic_blocker.py::numpy_amps`` (continuous == windowed here,
verified there).  The server executes this file as-is in the backend container.

Standalone: ``python run.py``.
"""
from __future__ import annotations

import json
import os
import time

from zoomy_core.fvm.solver_numpy import HyperbolicSolver
from zoomy_core.fvm import timestepping
from zoomy_core.mesh import BaseMesh  # noqa: F401  (keeps the numpy stack imported)
from zoomy_core.misc.misc import Settings, Zstruct, get_main_directory

from mesh import build_mesh
from model import build_model

CASE_DIR = os.path.dirname(os.path.abspath(__file__))


def load_settings(path=None):
    with open(path or os.path.join(CASE_DIR, "settings.json")) as f:
        return json.load(f)


def run(settings=None):
    """Build + solve from ``settings`` (dict or None → settings.json).  Returns
    the output ``.h5`` path."""
    if settings is None:
        settings = load_settings()
    name = settings.get("name", "bingham_permanent_rollwave")
    num, run_cfg = settings["numerics"], settings["run"]

    mesh = build_mesh(settings, CASE_DIR)
    bundle = build_model(settings, mesh, CASE_DIR)
    nsm, sc, dtc = bundle["nsm"], bundle["sc"], bundle["dt_cap"]
    t_end = run_cfg["t_end_prime"] * sc["tscale"]      # t' -> physical time
    print(f"[{name}] mesh: {mesh.n_inner_cells} cells; "
          f"states={[str(s) for s in bundle['sm'].state]}; "
          f"nu={sc['nu']:.4f} lambda={sc['lam_wave']:.2f} "
          f"tscale={sc['tscale']:.3f} T={t_end:.1f}s dt_cap={dtc:.5f}", flush=True)

    out_rel = os.path.relpath(os.path.join(CASE_DIR, "output"), get_main_directory())
    solver = HyperbolicSolver(
        time_end=t_end,
        compute_dt=timestepping.adaptive(
            CFL=num.get("cfl", 0.9), dimension=1, dt_max=dtc),
        settings=Settings(name=name, output=Zstruct(
            directory=out_rel, filename=name,
            snapshots=run_cfg.get("snapshots", 81), clean_directory=False)))

    print(f"[{name}] solving t_end={t_end:.1f}s "
          f"(t'={run_cfg['t_end_prime']}, order={num.get('order', 1)}) ...",
          flush=True)
    t0 = time.perf_counter()
    solver.solve(mesh, nsm, write_output=True)
    h5 = os.path.join(CASE_DIR, "output", name + ".h5")
    print(f"[{name}] done ({time.perf_counter()-t0:.0f}s) -> {h5}", flush=True)
    return h5


if __name__ == "__main__":
    run()
