import numpy as np

import zoomy_core.model.initial_conditions as IC
from zoomy_core.fvm import timestepping
from zoomy_core.fvm.solver_numpy import HyperbolicSolver
from zoomy_core.numerics import NumericalSystemModel, ReconstructionSpec
from zoomy_core.systemmodel import SystemModel

sm = SystemModel.from_model(model)
z_c = H0 - tau_y / a
sm.initial_conditions = IC.Project3D(
    sm,
    height=lambda x: H0 * (1 + seed * np.sin(2 * np.pi * x[0] / wave_length)),
    velocity=lambda x, zeta: a * H0 / lambda_s + a / nu * np.where(
        zeta * H0 <= z_c, z_c * zeta * H0 - (zeta * H0)**2 / 2, z_c**2 / 2))
sm.aux_initial_conditions = IC.Constant(constants=lambda n: np.zeros(n))
display(sm.describe())

nsm = NumericalSystemModel.from_system_model(sm, reconstruction=ReconstructionSpec(order=1))

nu_eff = nu + tau_y / eps_reg
rate = max((2 * level + 1) * nu_eff * 12 / H0**2, (level + 1)**2 * lambda_s / H0)
solver = HyperbolicSolver(
    time_end=settings["time_end"] * tscale,
    compute_dt=timestepping.adaptive(CFL=0.9, dimension=1, dt_max=0.4 / rate))
solver.settings.output.snapshots = 81
Q, Qaux = solver.solve(mesh, nsm)
