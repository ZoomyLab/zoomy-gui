import os

import numpy as np

from zoomy_core.mesh import BaseMesh

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())


def wave_length(settings):
    m, ic = settings["model"], settings["ic"]
    xscale = m["H0"] / m["s"]
    return 2.0 * np.pi / ic["wavenumber"] * xscale


def build_mesh(settings, case_dir=None):
    lam = wave_length(settings)
    nc = int(settings["mesh"]["n_inner_cells"])
    return BaseMesh.create_1d(domain=(0.0, lam), n_inner_cells=nc)
