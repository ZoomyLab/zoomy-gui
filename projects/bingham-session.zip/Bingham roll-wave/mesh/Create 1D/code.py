from zoomy_core.mesh import BaseMesh

mesh = BaseMesh.create_1d(domain=(0.0, wave_length), n_inner_cells=1000)
