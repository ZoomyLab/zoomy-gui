"""Bingham roll wave (numpy backend) — GUI folder-case ``mesh.py`` (REQ-136).

The 1-D PERIODIC mesh of the Liu & Mei (1994) §VI permanent-roll-wave benchmark:
a single wavelength ``L = 2*pi/k * (H0/s)`` (the physical length of the seeded
mode), discretised into ``settings["mesh"]["n_inner_cells"]`` cells.  Periodicity
is carried by the model's ``Periodic`` boundary conditions (see ``model.py``);
this module owns only the geometry, sized from ``settings``.
"""
from __future__ import annotations

import os

import numpy as np

from zoomy_core.mesh import BaseMesh

CASE_DIR = os.path.dirname(os.path.abspath(__file__))


def wave_length(settings):
    """Physical domain length = one seeded wavelength, ``2*pi/k * (H0/s)``."""
    m, ic = settings["model"], settings["ic"]
    xscale = m["H0"] / m["s"]                      # Liu & Mei length scale H*cot(theta)
    return 2.0 * np.pi / ic["wavenumber"] * xscale


def build_mesh(settings, case_dir=None):
    """Build the 1-D periodic mesh sized from ``settings['mesh']`` + ``ic``."""
    lam = wave_length(settings)
    nc = int(settings["mesh"]["n_inner_cells"])
    return BaseMesh.create_1d(domain=(0.0, lam), n_inner_cells=nc)
