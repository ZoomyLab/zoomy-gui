import matplotlib.pyplot as plt
import zoomy_plotting as zp

store = zp.read_hdf5("output/simulation.h5")
x = store.cell_centers[:, 0]
first, last = 0, store.n_snapshots - 1

with zp.apply_style():
    fig, (ax_h, ax_u) = plt.subplots(1, 2, figsize=(7.0, 2.6))
    for step in (first, last):
        h = store.get_cell(step, "h")
        label = f"t' = {store.times[step] / tscale:.1f}"
        ax_h.plot(x, h, marker="None", label=label)
        ax_u.plot(x, store.get_cell(step, "q_0") / h, marker="None", label=label)
    ax_h.set(xlabel="$x$ [m]", ylabel="$h$ [m]", title="(a) depth")
    ax_u.set(xlabel="$x$ [m]", ylabel=r"$\bar u$ [m s$^{-1}$]", title="(b) mean velocity")
    zp.figure_legend(fig)
fig
