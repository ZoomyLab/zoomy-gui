import json
import os

import numpy as np
import numpy.polynomial.legendre as npleg
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter

from zoomy_plotting import read_hdf5

try:
    scales
except NameError:
    from model import scales

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())


_CASE_SETTINGS = {'name': 'bingham_permanent_rollwave',
 'backend': 'numpy',
 'model': {'type': 'SME',
           'level': 2,
           'quadrature_order': 12,
           'rheology': 'bingham',
           'n': 1,
           'alpha': 0.3,
           'beta': 27.0,
           'g': 9.81,
           's': 0.1,
           'H0': 1.0,
           'lambda_s': 50.0},
 'ic': {'wavenumber': 1.2, 'seed_amplitude': 0.01},
 'mesh': {'n_inner_cells': 1000},
 'numerics': {'order': 1,
              'cfl': 0.9,
              'riemann': 'rusanov',
              'reconstruction_variables': 'conservative',
              'dt_cap_safety': 0.4},
 'run': {'solver': 'explicit', 't_end_prime': 200.0, 'snapshots': 81}}


def load_settings(path=None):
    p = path or os.path.join(CASE_DIR, "settings.json")
    s = json.load(open(p)) if os.path.exists(p) else {}
    if "numerics" not in s:
        gui = s or (globals().get("settings")
                    if isinstance(globals().get("settings"), dict) else None) or {}
        s = json.loads(json.dumps(_CASE_SETTINGS))
        if gui.get("time_end") is not None:
            s["run"] = dict(s["run"], t_end_prime=float(gui["time_end"]))
    return s


TARGET = dict(Cs=0.34, c_lin=0.25, hmax=1.85, hmin=0.70,
              F2_deep=0.12, F2_shallow=3.03)

FIG8_X = np.array([0.0, 0.7, 1.4, 2.0, 2.5, 2.8, 2.92, 2.97, 3.4, 4.2, 5.24])
FIG8_H = np.array([0.85, 0.97, 1.15, 1.36, 1.58, 1.75, 1.85, 0.70, 0.74,
                   0.80, 0.85])


def _xshift(a, b):
    c = np.fft.ifft(np.fft.fft(b) * np.conj(np.fft.fft(a))).real
    s = int(np.argmax(c))
    return s if s <= len(a) // 2 else s - len(a)


def _leg(k, zeta):
    c = np.zeros(k + 1); c[k] = 1.0
    return npleg.legval(2.0 * zeta - 1.0, c)


def load_snapshots(settings):
    name = settings.get("name", "bingham_permanent_rollwave")
    h5 = os.path.join(CASE_DIR, "output", name + ".h5")
    if not os.path.exists(h5):
        raise SystemExit(f"no run store at {h5} — run.py first")
    level = settings["model"]["level"]
    n_state = 2 + (level + 1)
    store = read_hdf5(h5)
    xc = np.asarray(store.cell_centers)[:, 0]
    all_t = np.asarray(store.times)
    frames = []
    for t in range(store.n_snapshots):
        Q = np.stack([np.asarray(store.get_cell(t, i)) for i in range(n_state)])
        frames.append(Q)
    store.close()

    if all_t[0] == 0.0:
        return all_t[1:], frames[1:], xc, level
    return all_t, frames, xc, level


def diagnostics(settings, times, snaps, xc, sc):
    ih = 1
    h0, ubar, beta = sc["h0"], sc["ubar"], settings["model"]["beta"]
    level = settings["model"]["level"]
    dx = xc[1] - xc[0]
    amps = np.array([f[ih].max() - f[ih].min() for f in snaps])

    disp = np.zeros(len(snaps), dtype=int)
    for i in range(1, len(snaps)):
        disp[i] = disp[i - 1] + _xshift(snaps[i - 1][ih], snaps[i][ih])
    unwrap = disp * dx
    n0 = 2 * len(snaps) // 3
    cs_phys = np.polyfit(times[n0:], unwrap[n0:], 1)[0]
    cs_prime = cs_phys / ubar

    h_fin = snaps[-1][ih]
    hmax, hmin = h_fin.max() / h0, h_fin.min() / h0
    amp_sat = amps[-5:].mean() / h0
    sat = np.abs(amps[n0:] - amps[n0:].mean()).max() / amps[n0:].mean()

    def u_surface(f):
        return sum(f[2 + i] * 1.0 for i in range(level + 1)) / f[ih]

    ifr = int(np.argmax(np.abs(np.gradient(h_fin, dx))))
    nc = len(xc)
    ioff = max(8, nc // 60)
    i_deep = (ifr - ioff) % nc
    i_shal = (ifr + ioff) % nc
    up = u_surface(snaps[-1])
    f2_deep = beta * ((up[i_deep] / ubar - cs_prime) ** 2) / (h_fin[i_deep] / h0)
    f2_shal = beta * ((up[i_shal] / ubar - cs_prime) ** 2) / (h_fin[i_shal] / h0)
    fr_base = np.sqrt(beta) * (up.mean() / ubar) / np.sqrt(h_fin.mean() / h0)

    return dict(cs_prime=cs_prime, hmax=hmax, hmin=hmin, amp_sat=amp_sat,
                sat=sat, f2_deep=f2_deep, f2_shal=f2_shal, fr_base=fr_base,
                amps=amps, disp=disp, ifr=ifr, h_fin=h_fin)


def figures(settings, times, snaps, xc, sc, dg):
    ih = 1
    h0, xscale, tscale = sc["h0"], sc["xscale"], sc["tscale"]
    level = settings["model"]["level"]
    nc = len(xc)
    dx = xc[1] - xc[0]
    xprime = xc / xscale
    tprime = times / tscale


    H = np.array([f[ih] / h0 for f in snaps])
    fig, (axm, axp) = plt.subplots(1, 2, figsize=(11, 4.6))
    im = axm.pcolormesh(xprime, tprime, H, shading="auto", cmap="viridis")
    axm.set(xlabel="x' = x·s/H", ylabel="t' = t/tscale",
            title=f"Bingham roll wave x-t (SME{level})")
    fig.colorbar(im, ax=axm, label="h/H")


    i295 = int(round(2.95 * xscale / dx))
    f_al = np.roll(snaps[-1][ih], i295 - dg["ifr"])
    axp.plot(xprime, f_al / h0, "C0", lw=1.8,
             label=f"SME({level})+Bingham (ours)")
    axp.plot(FIG8_X, FIG8_H, "k--o", ms=3, lw=1.0,
             label="Liu&Mei Fig. 8 (digitized)")
    axp.set(xlim=(0, sc["lam_wave"] / xscale), ylim=(0.4, 2.05),
            xlabel="x' = x·s/H", ylabel="h/H",
            title=f"saturated wave  C_s'={dg['cs_prime']:.3f}")
    axp.legend(loc="upper left", fontsize=9)
    fig.tight_layout()


    p_xt = os.path.join(CASE_DIR, "output", "fig_bingham_permanent_xt.png")
    fig.savefig(p_xt, dpi=130)
    plt.close(fig)


    fig2, ax2 = plt.subplots(figsize=(7, 4))
    ax2.plot(tprime, dg["amps"] / h0, "C0", lw=1.6)
    ax2.axhline(TARGET["hmax"] - TARGET["hmin"], color="k", ls="--", lw=1.0,
                label="Liu&Mei saturated amplitude")
    ax2.set(xlabel="t' = t/tscale", ylabel="(h_max−h_min)/H",
            title=f"saturation (flatness {dg['sat']:.1%})")
    ax2.legend(fontsize=9); ax2.grid(alpha=0.3)
    fig2.tight_layout()
    p_amp = os.path.join(CASE_DIR, "output", "fig_bingham_permanent_profile.png")
    fig2.savefig(p_amp, dpi=130)
    plt.close(fig2)
    return p_xt, p_amp


def animation(settings, times, snaps, xc, sc, dg):
    ih = 1
    h0, xscale, tscale = sc["h0"], sc["xscale"], sc["tscale"]
    level = settings["model"]["level"]
    dx = xc[1] - xc[0]
    xprime = xc / xscale
    tprime = times / tscale
    amps, disp, ifr = dg["amps"], dg["disp"], dg["ifr"]

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 7))
    (lh,) = ax1.plot([], [], "C0", lw=1.8, label=f"SME({level})+Bingham (ours)")
    ax1.plot(FIG8_X, FIG8_H, "k--o", ms=3, lw=1.0,
             label="Liu&Mei Fig. 8 (digitized, shock-aligned)")
    ax1.set(xlim=(0, sc["lam_wave"] / xscale), ylim=(0.4, 2.05),
            xlabel="x' = x·s/H", ylabel="h/H")
    ax1.legend(loc="upper left", fontsize=9)
    (la,) = ax2.plot([], [], "C0", lw=1.6)
    ax2.axhline(TARGET["hmax"] - TARGET["hmin"], color="k", ls="--", lw=1.0,
                label="Liu&Mei saturated amplitude")
    ax2.set(xlabel="t' = t/tscale", ylabel="(h_max−h_min)/H",
            xlim=(0, float(tprime.max()) or 1.0),
            ylim=(0, max(1.4, float(amps.max() / h0) * 1.15)))
    ax2.legend(fontsize=9); ax2.grid(alpha=0.3)
    ta, aa = [], []


    i295 = int(round(2.95 * xscale / dx))
    roll0 = i295 - ifr
    roll_per_frame = [roll0 + (disp[-1] - disp[i]) for i in range(len(snaps))]

    def upd(i):
        f_al = np.roll(snaps[i][ih], roll_per_frame[i])
        lh.set_data(xprime, f_al / h0)
        ta.append(tprime[i]); aa.append(amps[i] / h0)
        la.set_data(ta, aa)
        fig.suptitle(f"Bingham permanent roll wave (SME{level}, α="
                     f"{settings['model']['alpha']}, β={settings['model']['beta']}"
                     f", k={settings['ic']['wavenumber']}) — t' = {tprime[i]:.2f}")
        return [lh, la]

    out = os.path.join(CASE_DIR, "output", "bingham_permanent_rollwave.gif")
    FuncAnimation(fig, upd, frames=len(snaps)).save(out, writer=PillowWriter(fps=7))
    plt.close(fig)
    return out


def crest_and_plug_figure(settings, snaps, xc, sc, dg):
    ih = 1
    level = settings["model"]["level"]
    h0, ubar, xscale = sc["h0"], sc["ubar"], sc["xscale"]
    gdot_eps = sc["eps_reg"]
    xprime = xc / xscale
    f = snaps[-1]
    h = f[ih]

    zp = np.linspace(0.0, 1.0, 200)
    phi = np.stack([_leg(k, zp) for k in range(level + 1)], axis=1)


    ic = int(np.argmax(h))
    qv_c = np.array([f[2 + k][ic] for k in range(level + 1)])
    u_crest = (phi @ qv_c) / h[ic]


    Q = np.stack([f[2 + k] for k in range(level + 1)], axis=0)
    U = (phi @ Q) / h[None, :]
    dudz = np.gradient(U, zp, axis=0) / h[None, :]
    hp = h * (np.abs(dudz) < gdot_eps).mean(axis=0)

    fig, (axv, axp) = plt.subplots(1, 2, figsize=(11, 4.4))
    axv.plot(u_crest / ubar, zp, "C0", lw=2.0, label=f"SME({level}) crest")

    plug_mask_c = np.abs(np.gradient(u_crest, zp) / h[ic]) < gdot_eps
    if plug_mask_c.any():
        z_yield = zp[np.argmax(plug_mask_c)]
        axv.axhline(z_yield, color="0.4", ls=":", lw=1.2,
                    label=f"yield surface ζ_c={z_yield:.2f}")
    axv.set(xlabel="u(ζ) / ū", ylabel="ζ = z/h", ylim=(0, 1),
            title=f"crest velocity profile (h/H={h[ic]/h0:.2f})")
    axv.legend(fontsize=9); axv.grid(alpha=0.3)

    axp.plot(xprime, hp / h0, "C1", lw=1.6)
    axp.plot(xprime, h / h0, "0.6", lw=1.0, ls="--", label="h/H")
    axp.set(xlabel="x' = x·s/H", ylabel="plug thickness h_p/H",
            xlim=(0, sc["lam_wave"] / xscale),
            title="dynamic plug thickness (|∂_z u|<γ̇_ε)")
    axp.legend(fontsize=9); axp.grid(alpha=0.3)
    fig.tight_layout()
    out = os.path.join(CASE_DIR, "output", "fig_bingham_permanent_crestprofile.png")
    fig.savefig(out, dpi=130)
    plt.close(fig)
    return out, float(hp.max() / h0)


def visualize(settings=None):
    if settings is None:
        settings = load_settings()
    sc = scales(settings)
    times, snaps, xc, level = load_snapshots(settings)
    dg = diagnostics(settings, times, snaps, xc, sc)

    print("\n=== saturated roll wave vs Liu & Mei (1994) ===")
    print(f"level (SME N)      : {level}")
    print(f"shock speed C_s'   : {dg['cs_prime']:.3f}   "
          f"(Liu&Mei {TARGET['Cs']}, REPORT §6.3 ~0.457)")
    print(f"base Froude number : {dg['fr_base']:.3f}")
    print(f"h_max/H            : {dg['hmax']:.2f}    (Liu&Mei ~{TARGET['hmax']})")
    print(f"h_min/H            : {dg['hmin']:.2f}    (Liu&Mei ~{TARGET['hmin']})")
    print(f"F² deep / shallow  : {dg['f2_deep']:.2f} / {dg['f2_shal']:.2f}  "
          f"(Liu&Mei {TARGET['F2_deep']} / {TARGET['F2_shallow']})")
    print(f"saturation flatness (last third amp variation): {dg['sat']:.1%}")

    p_xt, p_amp = figures(settings, times, snaps, xc, sc, dg)
    p_gif = animation(settings, times, snaps, xc, sc, dg)
    p_prof, hp_max = crest_and_plug_figure(settings, snaps, xc, sc, dg)
    print(f"max plug thickness h_p/H : {hp_max:.2f}")
    print("->", p_xt)
    print("->", p_amp)
    print("->", p_gif)
    print("->", p_prof)
    return dg


visualize()
