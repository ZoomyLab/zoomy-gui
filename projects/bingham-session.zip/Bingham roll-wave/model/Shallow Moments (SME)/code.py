import numpy as np

from zoomy_core.model.boundary_conditions import BoundaryConditions, Periodic
from zoomy_core.model.models import SME
from zoomy_core.model.models.closures import Bingham, NavierSlip, StressFree

g, s, H0, level, lambda_s = 9.81, 0.1, 1.0, 2, 50.0
alpha, beta, k_wave, seed = 0.3, 27.0, 1.2, 0.01

a = g * s
tau_y = alpha * a * H0
nu = np.sqrt(g * s**2 * H0**3 / beta)
eps_reg = 0.05 * a * (H0 - tau_y / a) / nu
tscale = nu / (g * s**2)
wave_length = 2 * np.pi / k_wave * H0 / s

model = SME(
    level=level, quadrature_order=12,
    closures=[Bingham(), NavierSlip(), StressFree()],
    parameters={"nu": nu, "tau_y": tau_y, "eps_reg": eps_reg,
                "lambda_s": lambda_s, "e_x": s},
    boundary_conditions=BoundaryConditions([
        Periodic(tag="left", periodic_to_physical_tag="right"),
        Periodic(tag="right", periodic_to_physical_tag="left")]))
