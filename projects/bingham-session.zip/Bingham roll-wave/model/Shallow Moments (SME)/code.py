import os

import numpy as np
import numpy.polynomial.legendre as npleg

import zoomy_core.model.initial_conditions as IC
from zoomy_core.model.models import SME
from zoomy_core.model.models.closures import NavierSlip, StressFree
from zoomy_core.model.boundary_conditions import BoundaryConditions, Periodic
from zoomy_core.numerics import NumericalSystemModel, ReconstructionSpec
from zoomy_core.systemmodel import SystemModel


import sympy as sp

from zoomy_core.model.models.closures import Bingham


class HerschelBulkley(Bingham):

    closes = "bulk"
    requires = ("u",)

    def register(self, m):
        m.parameter("nu", 0.0)
        m.parameter("tau_y", 0.0)
        m.parameter("eps_reg", 1e-3)
        m.parameter("K_hb", 1.0)
        m.parameter("n_hb", 1.0)

    def expression(self, s):
        gd = s.dz(s.u)
        e2 = gd ** 2 + s.par.eps_reg ** 2
        eta = (s.par.rho * s.par.nu
               + s.par.K_hb * e2 ** ((s.par.n_hb - 1) / 2)
               + s.par.tau_y / sp.sqrt(e2))
        return eta * gd


def wave_length(settings):
    m, ic = settings["model"], settings["ic"]
    xscale = m["H0"] / m["s"]
    return 2.0 * np.pi / ic["wavenumber"] * xscale


CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())


def scales(settings):
    m = settings["model"]
    g, s, h0 = m["g"], m["s"], m["H0"]
    alpha, beta = m["alpha"], m["beta"]
    lam_s = m["lambda_s"]
    a = g * s
    tau_y = alpha * a * h0
    nu = float(np.sqrt(g * s**2 * h0**3 / beta))
    ubar = a * h0**2 / nu
    xscale = h0 / s
    tscale = nu / (g * s**2)
    eps_reg = 0.05 * a * (h0 - tau_y / a) / nu
    return dict(g=g, s=s, h0=h0, a=a, tau_y=tau_y, nu=nu, lam_s=lam_s,
                ubar=ubar, xscale=xscale, tscale=tscale, eps_reg=eps_reg,
                lam_wave=wave_length(settings))


def _analytic_profile(zeta, sc):
    h0, a, nu, lam_s, tau_y = sc["h0"], sc["a"], sc["nu"], sc["lam_s"], sc["tau_y"]
    zc = h0 - tau_y / a
    u_slip = a * h0 / lam_s
    zz = zeta * h0
    return u_slip + (a / nu) * np.where(zz <= zc, zc * zz - zz**2 / 2, zc**2 / 2)


def _modal_base(level, sc):
    zf = np.linspace(0, 1, 400)
    u = _analytic_profile(zf, sc)
    qs = []
    for i in range(level + 1):
        c = np.zeros(i + 1); c[i] = 1.0
        qs.append((2 * i + 1) * sc["h0"]
                  * np.trapezoid(u * npleg.legval(2 * zf - 1, c), zf))
    return qs


def build_bc():
    return BoundaryConditions([
        Periodic(tag="left", periodic_to_physical_tag="right"),
        Periodic(tag="right", periodic_to_physical_tag="left")])


def build_ic(settings, sm, sc):
    m, icfg = settings["model"], settings["ic"]
    level = m["level"]
    seed = icfg["seed_amplitude"]
    lam = sc["lam_wave"]
    h0 = sc["h0"]
    names = [str(s_) for s_ in sm.state]
    qs0 = _modal_base(level, sc)

    def ic(xv):
        xx = float(xv[0])
        out = np.zeros(len(names))
        bump = 1.0 + seed * np.sin(2 * np.pi * xx / lam)
        out[0] = 0.0
        out[1] = h0 * bump
        for i in range(level + 1):
            out[2 + i] = qs0[i] * bump
        return out
    return ic


def dt_cap(settings, sc):
    m, num = settings["model"], settings["numerics"]
    level, h0, lam_s = m["level"], sc["h0"], sc["lam_s"]
    nu_eff = sc["nu"] + sc["tau_y"] / sc["eps_reg"]
    rate_bulk = (2 * level + 1) * nu_eff * 12.0 / h0**2
    rate_slip = (level + 1) ** 2 * lam_s / h0
    return num.get("dt_cap_safety", 0.4) / max(rate_bulk, rate_slip)


def build_model(settings, mesh, case_dir=None):
    m, num = settings["model"], settings["numerics"]
    sc = scales(settings)


    par = {"nu": sc["nu"], "lambda_s": sc["lam_s"], "tau_y": sc["tau_y"],
           "eps_reg": sc["eps_reg"], "e_x": sc["s"],
           "K_hb": 0.0, "n_hb": float(m.get("n", 1))}

    sm = SystemModel.from_model(SME(
        level=m["level"], quadrature_order=m.get("quadrature_order", 12),
        closures=[HerschelBulkley(), NavierSlip(), StressFree()],
        parameters=par, boundary_conditions=build_bc()))

    ic = build_ic(settings, sm, sc)
    sm.initial_conditions = IC.UserFunction(function=ic)
    sm.aux_initial_conditions = IC.Constant(constants=lambda n: np.zeros(n))

    nsm = NumericalSystemModel.from_system_model(
        sm, reconstruction=ReconstructionSpec(order=num.get("order", 1)))
    return {"nsm": nsm, "sm": sm, "sc": sc, "dt_cap": dt_cap(settings, sc)}
