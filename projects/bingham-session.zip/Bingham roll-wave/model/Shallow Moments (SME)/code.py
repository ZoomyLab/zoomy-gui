"""Bingham roll wave (numpy backend) — GUI folder-case ``model.py`` (REQ-136).

The Liu & Mei (1994) §VI permanent-roll-wave model: an ``SME`` moment hierarchy
closed by the case-local :class:`hb_closure.HerschelBulkley` bulk stress
(``n=1`` ⇒ regularized Bingham, bit-for-bit identical to the core ``Bingham``
closure — verified ``max|Δsource|≈1e-13``, ``Δflux=0``), Navier slip at the bed
and a stress-free surface.  The incline is carried by the ``e_x`` body force on a
FLAT bed (no topography); the domain is PERIODIC over one seeded wavelength.

The IC is the Liu & Mei steady base velocity profile projected onto the Legendre
moment modes, multiplied by a 1 % sinusoidal seed at the fundamental wavenumber.

Exposes ``build_model(settings, mesh)``, ``build_ic(...)``, ``build_bc(...)``
mirroring ``../malpasset_jax/model.py``; all physics is driven by
``settings.json``.
"""

import os

import numpy as np
import numpy.polynomial.legendre as npleg

import zoomy_core.model.initial_conditions as IC
from zoomy_core.model.models import SME
from zoomy_core.model.models.closures import NavierSlip, StressFree
from zoomy_core.model.boundary_conditions import BoundaryConditions, Periodic
from zoomy_core.numerics import NumericalSystemModel, ReconstructionSpec

# hb_closure.HerschelBulkley: inlined above (GUI card is self-contained)


# --- inlined case module: hb_closure.py ------------------------
# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
# ---

# %% [markdown]
# # Case-local Herschel–Bulkley bulk-stress closure
#
# The committed Bingham case injects `zoomy_core.model.models.closures.Bingham`
#
#     tau = (rho*nu + tau_y/sqrt(gdot^2 + eps^2)) * gdot          (gdot = d_z u)
#
# Herschel–Bulkley replaces the Newtonian part `rho*nu` by the power-law
# consistency term `K |gdot|^{n-1}` (flow index `n`; `n=1` is Bingham):
#
#     tau = (K*(gdot^2 + eps^2)^{(n-1)/2} + tau_y/sqrt(gdot^2 + eps^2)) * gdot
#
# The SAME eps-regularization is used on BOTH the power-law and the yield term:
# for `n < 1` the raw `|gdot|^{n-1}` diverges at the (unsheared) plug, so the
# `(gdot^2+eps^2)^{(n-1)/2}` form (Papanastasiou-style) keeps the apparent
# viscosity finite there — this is what lets the shear-thinning experimental
# indices (`n≈0.54` carbopol, `n≈0.25` kaolin) build and linearise without a
# singular plug.  **`n=1, K_hb = rho*nu, nu=0` reproduces `Bingham` bit-for-bit**
# (verified in `hb_dispersion.py`: `max|A_HB − A_Bingham| = 0`).
#
# CASE-LOCAL — subclasses the core `Bingham` Closure (the memory-confirmed
# no-core-edit route; cf. `mui_granular/mui_closure.py`, `calibration/`).  Build
# with `quadrature_order > 0`: the Galerkin projection of the non-polynomial
# stress is not analytically integrable.

# %%
import sympy as sp

from zoomy_core.model.models.closures import Bingham


class HerschelBulkley(Bingham):
    """Regularized Herschel–Bulkley bulk stress (case-local extension of
    `Bingham`).  Parameters: `K_hb` (consistency), `n_hb` (flow index),
    `tau_y`, `eps_reg` (shared regularization), plus the inherited `nu`
    (kept for an optional additive Newtonian floor; set 0 for pure HB)."""

    closes = "bulk"
    requires = ("u",)

    def register(self, m):
        m.parameter("nu", 0.0)
        m.parameter("tau_y", 0.0)
        m.parameter("eps_reg", 1e-3)
        m.parameter("K_hb", 1.0)
        m.parameter("n_hb", 1.0)

    def expression(self, s):
        gd = s.dz(s.u)
        e2 = gd ** 2 + s.par.eps_reg ** 2
        eta = (s.par.rho * s.par.nu
               + s.par.K_hb * e2 ** ((s.par.n_hb - 1) / 2)
               + s.par.tau_y / sp.sqrt(e2))
        return eta * gd


# --- inlined from mesh.py --------------------------------------
def wave_length(settings):
    """Physical domain length = one seeded wavelength, ``2*pi/k * (H0/s)``."""
    m, ic = settings["model"], settings["ic"]
    xscale = m["H0"] / m["s"]                      # Liu & Mei length scale H*cot(theta)
    return 2.0 * np.pi / ic["wavenumber"] * xscale
# ------------------------------------------------------------------
# mesh.wave_length: inlined above (GUI card is self-contained)

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())


def scales(settings):
    """Liu & Mei non-dimensionalising scales + derived physical constants.

    Returns a dict with the velocity/length/time scales (``ubar``, ``xscale``,
    ``tscale``), the physical viscosity ``nu``, yield stress ``tau_y``,
    regularization ``eps_reg`` and the wavelength — the single source of the
    Liu & Mei parameter algebra used by the IC, the timestep cap and the run's
    ``t_end`` conversion.
    """
    m = settings["model"]
    g, s, h0 = m["g"], m["s"], m["H0"]
    alpha, beta = m["alpha"], m["beta"]
    lam_s = m["lambda_s"]
    a = g * s
    tau_y = alpha * a * h0
    nu = float(np.sqrt(g * s**2 * h0**3 / beta))
    ubar = a * h0**2 / nu                          # velocity scale
    xscale = h0 / s                                # length scale H*cot(theta)
    tscale = nu / (g * s**2)                       # time scale
    eps_reg = 0.05 * a * (h0 - tau_y / a) / nu
    return dict(g=g, s=s, h0=h0, a=a, tau_y=tau_y, nu=nu, lam_s=lam_s,
                ubar=ubar, xscale=xscale, tscale=tscale, eps_reg=eps_reg,
                lam_wave=wave_length(settings))


def _analytic_profile(zeta, sc):
    """Liu & Mei steady base velocity u(zeta) (slip + plug-over-parabola)."""
    h0, a, nu, lam_s, tau_y = sc["h0"], sc["a"], sc["nu"], sc["lam_s"], sc["tau_y"]
    zc = h0 - tau_y / a
    u_slip = a * h0 / lam_s
    zz = zeta * h0
    return u_slip + (a / nu) * np.where(zz <= zc, zc * zz - zz**2 / 2, zc**2 / 2)


def _modal_base(level, sc):
    """Legendre-moment coefficients q_i of the steady base profile."""
    zf = np.linspace(0, 1, 400)
    u = _analytic_profile(zf, sc)
    qs = []
    for i in range(level + 1):
        c = np.zeros(i + 1); c[i] = 1.0
        qs.append((2 * i + 1) * sc["h0"]
                  * np.trapezoid(u * npleg.legval(2 * zf - 1, c), zf))
    return qs


def build_bc():
    """Periodic BCs wrapping the single-wavelength domain (left<->right)."""
    return BoundaryConditions([
        Periodic(tag="left", periodic_to_physical_tag="right"),
        Periodic(tag="right", periodic_to_physical_tag="left")])


def build_ic(settings, sm, sc):
    """IC = steady base moments * (1 + seed*sin(2*pi*x/lambda)) on a FLAT bed."""
    m, icfg = settings["model"], settings["ic"]
    level = m["level"]
    seed = icfg["seed_amplitude"]
    lam = sc["lam_wave"]
    h0 = sc["h0"]
    names = [str(s_) for s_ in sm.state]
    qs0 = _modal_base(level, sc)

    def ic(xv):
        xx = float(xv[0])
        out = np.zeros(len(names))
        bump = 1.0 + seed * np.sin(2 * np.pi * xx / lam)
        out[0] = 0.0                               # FLAT bed — incline via e_x
        out[1] = h0 * bump
        for i in range(level + 1):
            out[2 + i] = qs0[i] * bump
        return out
    return ic


def dt_cap(settings, sc):
    """Diffusive/slip timestep cap (the canonical rollwave.py stability bound)."""
    m, num = settings["model"], settings["numerics"]
    level, h0, lam_s = m["level"], sc["h0"], sc["lam_s"]
    nu_eff = sc["nu"] + sc["tau_y"] / sc["eps_reg"]
    rate_bulk = (2 * level + 1) * nu_eff * 12.0 / h0**2
    rate_slip = (level + 1) ** 2 * lam_s / h0
    return num.get("dt_cap_safety", 0.4) / max(rate_bulk, rate_slip)


def build_model(settings, mesh, case_dir=None):
    """Build the SME(+Bingham/HB) NSM with IC/BC baked, from ``settings.json``.

    Returns a dict ``{nsm, sm, sc, dt_cap}`` — ``sc`` (the Liu & Mei scales) and
    ``dt_cap`` are what ``run.py``/``visualize.py`` need to set ``t_end`` and the
    adaptive-dt bound and to non-dimensionalise the diagnostics.
    """
    m, num = settings["model"], settings["numerics"]
    sc = scales(settings)

    # HerschelBulkley with n=1, K_hb=0 == regularized Bingham (bit-faithful):
    # the Newtonian term is carried by the inherited `nu`, the yield term by
    # `tau_y/sqrt(gd^2+eps^2)`, and the power-law term `K_hb*e2^0` vanishes.
    par = {"nu": sc["nu"], "lambda_s": sc["lam_s"], "tau_y": sc["tau_y"],
           "eps_reg": sc["eps_reg"], "e_x": sc["s"],
           "K_hb": 0.0, "n_hb": float(m.get("n", 1))}

    sm = SME(level=m["level"], quadrature_order=m.get("quadrature_order", 12),
             closures=[HerschelBulkley(), NavierSlip(), StressFree()],
             parameters=par, boundary_conditions=build_bc()).system_model

    ic = build_ic(settings, sm, sc)
    sm.initial_conditions = IC.UserFunction(function=ic)
    sm.aux_initial_conditions = IC.Constant(constants=lambda n: np.zeros(n))

    nsm = NumericalSystemModel.from_system_model(
        sm, reconstruction=ReconstructionSpec(order=num.get("order", 1)))
    return {"nsm": nsm, "sm": sm, "sc": sc, "dt_cap": dt_cap(settings, sc)}
