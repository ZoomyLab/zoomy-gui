"""Bingham analytics (numpy) — GUI folder-case ``mesh.py`` (REQ-150).

The analytics sub-case is a LINEAR / WAVENUMBER-SPACE analysis (critical Reynolds
``Re_c``, cutoff frequency, dispersion relation) — there is NO spatial grid to
march, so ``build_mesh`` is a stub returning ``None``.  It is kept only to honour
the folder-case entry-point contract
(``build_mesh``/``build_model``/``load_settings``/``run``/``visualize``) that the
GUI / zoomy-server generic runner expects; ``run.py`` is executed directly and
never touches a mesh.
"""


def build_mesh(settings=None, case_dir=None):
    """No spatial mesh — the dispersion/threshold analysis lives in wavenumber
    space (real ω / complex k eigenproblems on the SME(N) Jacobians)."""
    return None
