import os
import sys

_CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
             if "__file__" in globals() else os.getcwd())
# Re-materialize the case sibling engines next to this card so
# ``import hb_dispersion`` resolves in BOTH the notebook (one scratch dir)
# and the folder form (python run.py / visualize.py).  The GUI card format
# has no sibling-module slot; these three modules are used module-qualified
# (HB.compute / HB.RE / …) across model/run/visualize, so they are shipped
# as files rather than inlined bare definitions.
_SIBS = {
    'hb_closure': '# ---\n# jupyter:\n#   jupytext:\n#     text_representation:\n#       extension: .py\n#       format_name: percent\n# ---\n\n# %% [markdown]\n# # Case-local Herschel–Bulkley bulk-stress closure\n#\n# The committed Bingham case injects `zoomy_core.model.models.closures.Bingham`\n#\n#     tau = (rho*nu + tau_y/sqrt(gdot^2 + eps^2)) * gdot          (gdot = d_z u)\n#\n# Herschel–Bulkley replaces the Newtonian part `rho*nu` by the power-law\n# consistency term `K |gdot|^{n-1}` (flow index `n`; `n=1` is Bingham):\n#\n#     tau = (K*(gdot^2 + eps^2)^{(n-1)/2} + tau_y/sqrt(gdot^2 + eps^2)) * gdot\n#\n# The SAME eps-regularization is used on BOTH the power-law and the yield term:\n# for `n < 1` the raw `|gdot|^{n-1}` diverges at the (unsheared) plug, so the\n# `(gdot^2+eps^2)^{(n-1)/2}` form (Papanastasiou-style) keeps the apparent\n# viscosity finite there — this is what lets the shear-thinning experimental\n# indices (`n≈0.54` carbopol, `n≈0.25` kaolin) build and linearise without a\n# singular plug.  **`n=1, K_hb = rho*nu, nu=0` reproduces `Bingham` bit-for-bit**\n# (verified in `hb_dispersion.py`: `max|A_HB − A_Bingham| = 0`).\n#\n# CASE-LOCAL — subclasses the core `Bingham` Closure (the memory-confirmed\n# no-core-edit route; cf. `mui_granular/mui_closure.py`, `calibration/`).  Build\n# with `quadrature_order > 0`: the Galerkin projection of the non-polynomial\n# stress is not analytically integrable.\n\n# %%\nimport sympy as sp\n\nfrom zoomy_core.model.models.closures import Bingham\n\n\nclass HerschelBulkley(Bingham):\n    """Regularized Herschel–Bulkley bulk stress (case-local extension of\n    `Bingham`).  Parameters: `K_hb` (consistency), `n_hb` (flow index),\n    `tau_y`, `eps_reg` (shared regularization), plus the inherited `nu`\n    (kept for an optional additive Newtonian floor; set 0 for pure HB)."""\n\n    closes = "bulk"\n    requires = ("u",)\n\n    def register(self, m):\n        m.parameter("nu", 0.0)\n        m.parameter("tau_y", 0.0)\n        m.parameter("eps_reg", 1e-3)\n        m.parameter("K_hb", 1.0)\n        m.parameter("n_hb", 1.0)\n\n    def expression(self, s):\n        gd = s.dz(s.u)\n        e2 = gd ** 2 + s.par.eps_reg ** 2\n        eta = (s.par.rho * s.par.nu\n               + s.par.K_hb * e2 ** ((s.par.n_hb - 1) / 2)\n               + s.par.tau_y / sp.sqrt(e2))\n        return eta * gd\n',
    'hb_visc_analytic': '"""Leading-order (shallow) STREAMWISE-viscous matrix ``V`` for the Herschel–Bulkley\nSME dispersion — the ``O(ε)`` in-plane stress the base SME drops.\n\nMounkaila Noma et al. (2021, *JFM* 922 R2) name the streamwise-viscous term as the\nmissing ingredient for the DISPERSION (short-wave cutoff, phase speed).  The base\nSME derivation (``moment_scaling``) drops it — ``SME(...).system_model.diffusion_matrix\nis None`` — so, exactly as in the μ(I) case (``mui_granular/visc_analytic.py``), we\nadd it as a base-linearised ``−k²V`` operator, reusing the SAME projection recipe.\n\nPhysics (leading-order, Gray & Edwards 2014 §4 for μ(I); the identical thin-layer\nargument for HB).  The thin-layer expansion has ``|∂_z u| ≫ |∂_x u|``, so the second\ninvariant reduces to the vertical shear and the in-plane deviatoric stress is a\nLINEAR streamwise viscous stress evaluated at the vertical shear:\n\n    τ_xx = 2 η(∂_z u) ∂_x u,\n    η(γ̇) = ρν + K (γ̇²+ε²)^{(n−1)/2} + τ_y/√(γ̇²+ε²),   γ̇ = ∂_z u,\n\nwith the SAME apparent viscosity ``η`` as the bulk HB stress ``τ_xz = η·∂_z u``\n(``hb_closure.HerschelBulkley.expression``) and the SAME ε-regularization.  This is\nthe HB analogue of the μ(I) effective viscosity ``μ(I)P/|∂_z u|``: swap the μ(I)\napparent viscosity for the HB one.  **n=1** gives ``η = ρν + τ_y/√(γ̇²+ε²)`` — the\nBingham apparent viscosity.\n\nLinearised about the UNIFORM film (``∂_x u_0 = 0``) the cross term vanishes and\n\n    δτ_xx = ν_eff(ζ) ∂_x δu,   ν_eff(ζ) = 2 η(∂_z u_0(ζ)),\n\nfrozen at the base shear ``∂_z u_0``.  Projected onto shifted-Legendre moment ``k``\nwith the SME recipe (multiply-``h``, ``φ_k``, ζ-integrate, mass-invert ⇒ ``(2k+1)``\nper row).  Unlike the μ(I) NO-SLIP model (Lanczos-tau top-mode slaving,\n``ψ_j=φ_j+(−1)^{N+j}φ_{N+1}``), the committed HB SME uses NAVIER-SLIP + stress-free:\nthe velocity is the PLAIN degree-``N`` expansion ``u=(1/h)Σ_{i=0}^N q_i φ_i`` (state\n``[b,h,q_0…q_N]``, no slaving — verified: ``SME(level=N).system_model.state``), so\n``ψ_j = φ_j`` and\n\n    K̃_kj = ∫_0^1 ν_eff φ_k φ_j dζ                         (j,k = 0..N)\n    V[q_k, q_j] = (2k+1) K̃_kj\n    V[q_k, h]   = −(2k+1)/h · Σ_j K̃_kj q_j                (the u=q/h change of var)\n\nwith all other rows/cols zero.  ``∂_t δq_k`` gains ``−k² Σ_· V[q_k,·] δ(·)``; the\ndispersion is ``σ(k)=maxRe eig(−ikA + B − k²V)`` (A,B unchanged — τ_xx≡0 at ∂_x=0,\nso the base flow / threshold is untouched, V is O(k²)).\n\nReuse: recipe + ``−k²V`` machinery from ``mui_granular/visc_analytic.viscous_V``\n(validated ~1e-4 vs the native derived operator there).  Genuinely new: the HB\napparent-viscosity coefficient ``ν_eff=2η_HB`` and the plain (non-slaved) basis.\n\nCase-local; does NOT edit zoomy_core.\n"""\nimport numpy as np\nimport numpy.polynomial.legendre as npleg\n\n\ndef _phi(i, zq):\n    return npleg.legval(2 * zq - 1, np.eye(1, i + 1, i)[0])\n\n\ndef _dphi(i, zq):\n    # d/dζ P_i(2ζ−1) = 2 P_i\'(2ζ−1)\n    c = np.eye(1, i + 1, i)[0]\n    return 2.0 * npleg.legval(2 * zq - 1, npleg.legder(c))\n\n\ndef nu_eff_hb(dzu, par):\n    """``ν_eff(ζ) = 2 η(∂_z u_0(ζ))`` — the coefficient of ``∂_x δu`` in ``δτ_xx``.\n\n    ``η`` is the SAME regularized Herschel–Bulkley apparent viscosity used by the\n    bulk closure (``hb_closure.HerschelBulkley``): ``ρν + K(γ̇²+ε²)^{(n−1)/2} +\n    τ_y/√(γ̇²+ε²)``.  ``n=1`` ⇒ ``ρν + τ_y/√(γ̇²+ε²)`` (Bingham)."""\n    e2 = dzu ** 2 + par["eps_reg"] ** 2\n    eta = (par["rho"] * par["nu"]\n           + par["K_hb"] * e2 ** ((par["n_hb"] - 1) / 2)\n           + par["tau_y"] / np.sqrt(e2))\n    return 2.0 * eta\n\n\ndef viscous_V(Q, N, par, nz=400, nu_of_zeta=None):\n    """Return the ``(n×n)`` viscous matrix ``V`` over state ``[b,h,q_0..q_N]`` at\n    base ``Q`` (plain shifted-Legendre / Navier-slip basis, ``ψ_j=φ_j``).\n\n    ``nu_of_zeta`` (callable ζ→ν) overrides the HB effective viscosity — used by the\n    constant-ν exactness check in :func:`verify_recipe`.  Default: ``ν_eff=2η_HB``\n    at the base shear ``∂_z u_0``.\n\n    Gauss–Legendre quadrature over the FULL [0,1] (``ν_eff`` is ε-regularized ⇒\n    finite at the plug/surface): trapezoid endpoint-truncation, amplified by the\n    ``(2k+1)`` row factor, breaks the ``K̃=∫ν φ_kφ_j`` Gram matrix\'s positivity."""\n    h0 = float(Q[1])\n    uhat = [float(Q[2 + i]) / h0 for i in range(N + 1)]           # û_i = q_i/h\n    gx, gw = npleg.leggauss(nz)\n    zq = 0.5 * (gx + 1.0)                                         # nodes on [0,1]\n    wq = 0.5 * gw                                                 # weights on [0,1]\n    if nu_of_zeta is not None:\n        nu = np.asarray(nu_of_zeta(zq), float) + 0.0 * zq\n    else:\n        # base shear ∂_z u_0(ζ) = (1/h) Σ û_i φ_i\'(ζ)\n        dzu = sum(uhat[i] * _dphi(i, zq) for i in range(N + 1)) / h0\n        nu = nu_eff_hb(dzu, par)\n    phi = {i: _phi(i, zq) for i in range(N + 1)}\n    Ktil = np.array([[np.sum(wq * nu * phi[k] * phi[j])\n                      for j in range(N + 1)] for k in range(N + 1)])\n    n = 2 + (N + 1)\n    V = np.zeros((n, n))\n    q0 = [float(Q[2 + j]) for j in range(N + 1)]\n    for k in range(N + 1):\n        w = 2 * k + 1\n        for j in range(N + 1):\n            V[2 + k, 2 + j] = w * Ktil[k, j]\n        V[2 + k, 1] = -w / h0 * sum(Ktil[k, j] * q0[j] for j in range(N + 1))\n    return V\n\n\n# ---------------------------------------------------------------------------\n# Independent verification of the projection normalization (no dispersion code).\n# ---------------------------------------------------------------------------\ndef verify_recipe(N=3):\n    """CONSTANT-viscosity closed form: for ``ν_eff(ζ)=ν_c`` the streamwise momentum\n    diffusion must act as ``ν_c ∂_xx(h û_k)`` per mode with UNIT coefficient, i.e.\n    the q-block of ``V`` is ``ν_c·I`` (shifted-Legendre orthogonality\n    ``∫φ_kφ_j=δ_kj/(2k+1)`` cancels the ``(2k+1)`` mass-inversion).  This pins the\n    recipe\'s normalization independently of any μ(I)/HB machinery.\n\n    Also checks the ``h``-column: ``V[q_k,h] = −ν_c q_k/h`` (the u=q/h change of\n    variables), and returns the max error."""\n    nu_c = 0.7\n    h0 = 1.3\n    q = [0.4, -0.15, 0.05, -0.02, 0.008][:N + 1]\n    Q = [0.0, h0] + q\n    V = viscous_V(Q, N, {}, nu_of_zeta=lambda z: nu_c + 0.0 * z)\n    Vqq = V[2:, 2:]\n    err_qq = np.abs(Vqq - nu_c * np.eye(N + 1)).max()\n    err_h = np.abs(np.array([V[2 + k, 1] for k in range(N + 1)])\n                   - np.array([-nu_c * q[k] / h0 for k in range(N + 1)])).max()\n    ok = max(err_qq, err_h) < 1e-6\n    print(f"(recipe) const-ν: max|V_qq−ν·I|={err_qq:.2e}  "\n          f"max|V_qh−(−ν q/h)|={err_h:.2e}  → {\'EXACT\' if ok else \'FAIL\'}")\n    return err_qq, err_h\n\n\ndef verify_n1_bingham(par):\n    """n=1 sanity: ``ν_eff`` collapses to the Bingham apparent viscosity\n    ``2(ρν + K + τ_y/√(γ̇²+ε²))`` — the power-law consistency ``K|γ̇|^{n−1}``\n    becomes a shear-rate-INDEPENDENT Newtonian viscosity ``K`` (that is the whole\n    content of ``n=1``), leaving only the yield term shear-dependent."""\n    p1 = dict(par, n_hb=1.0)\n    g = np.array([0.05, 0.3, 1.0, 2.5])\n    e2 = g ** 2 + p1["eps_reg"] ** 2\n    hb = nu_eff_hb(g, p1)\n    bing = 2.0 * (p1["rho"] * p1["nu"] + p1["K_hb"] + p1["tau_y"] / np.sqrt(e2))\n    err = np.abs(hb - bing).max()\n    # the Newtonian (shear-independent) part must be constant across γ̇\n    newt = hb - 2.0 * p1["tau_y"] / np.sqrt(e2)\n    err_const = np.abs(newt - newt[0]).max()\n    print(f"(a) n=1: ν_eff == 2(ρν+K+τ_y/√(γ̇²+ε²)) max err={err:.2e}; "\n          f"consistency term γ̇-independent max dev={err_const:.2e}  → "\n          f"{\'BINGHAM\' if max(err, err_const) < 1e-12 else \'DIFFER\'}")\n    return err\n\n\nif __name__ == "__main__":\n    verify_recipe(3)\n    verify_recipe(1)\n',
    'hb_dispersion': '# ---\n# jupyter:\n#   jupytext:\n#     text_representation:\n#       extension: .py\n#       format_name: percent\n# ---\n\n# %% [markdown]\n# # Herschel–Bulkley SME linear dispersion vs the Mounkaila Noma 2021 experiment\n#\n# **Question (the reframe).** Mounkaila Noma et al. (2021, *JFM* 922 R2) measure\n# the primary instability of a visco-plastic (Herschel–Bulkley) film down an\n# incline and state explicitly: the pseudo-plug shallow-water model of Balmforth\n# & Liu (2004) captures the stability THRESHOLD, but FAILS on the DISPERSION\n# (growth rates, cutoff frequencies, phase speeds) — *"a more accurate model is\n# needed."*  Does our resolved SME(N) — which makes NO assumed profile — track\n# the experimental dispersion better than B&L, or does it share the same\n# limitation?\n#\n# **Approach.**  We compute the SME linear dispersion (temporal + spatial) for a\n# Herschel–Bulkley film matched to the experiment\'s Fig. 7 case\n# `(Re, Bi, n) = (11.2, 0.29, 0.54)` (carbopol, φ=15.6°), and overlay it on the\n# digitized experiment and B&L curves in the paper\'s rescaled variables\n# `ω̃ = 2πf⟨h⟩/V`, `k̃ = k⟨h⟩`, `c̃ = ω̃/k̃`, `c_b = (1−Bi)^{1/n}`.\n#\n# **Parameter map (paper Eq. 3.1, ρ=⟨h⟩=g_true=1, φ=15.6°).**  Driving is the\n# body force `g·e_x`; hydrostatic uses `g`.  Setting `g=cosφ`, `e_x=tanφ` gives\n# driving `g·e_x = sinφ` and hydrostatic `g cosφ` (the paper\'s pressure scale).\n# Then `τ_y = Bi·sinφ`, `K = [tanφ·sinφ^{(2−n)/n}/Re]^{n/2}`,\n# `V = (sinφ/K)^{1/n}`.  With `g=1` the scaling is EXACTLY self-consistent\n# (`cosφ/Fr² = 1/Re`), so the rescaled dispersion depends only on `(Re, Bi, n)`.\n# Validation: the SME long-wave phase speed converges to `c_b` in N.\n#\n# CASE-LOCAL: the SME is built through `Model → SystemModel` with the case-local\n# `HerschelBulkley` closure; the dispersion reuses the derived system\'s symbolic\n# flux/source/NCP Jacobians (no core edit).\n\n# %%\nimport os\nimport numpy as np\nimport sympy as sp\nfrom scipy.linalg import eig\nfrom scipy.optimize import fsolve, brentq\n\nfrom zoomy_core.model.models import SME\nfrom zoomy_core.model.models.closures import NavierSlip, StressFree\nfrom zoomy_core.systemmodel import SystemModel\nfrom hb_closure import HerschelBulkley\nfrom hb_visc_analytic import viscous_V as viscous_V_hb, verify_recipe, verify_n1_bingham\n\nHERE = os.path.dirname(os.path.abspath(__file__))\nOUT = os.path.join(HERE, "output")\nos.makedirs(OUT, exist_ok=True)\n\nPNAMES = ["g", "rho", "nu", "e_x", "lambda_s", "tau_y", "eps_reg", "K_hb", "n_hb"]\n\n# matched Fig. 7 case (carbopol)\nN_IDX, BI, RE, PHI_DEG = 0.54, 0.29, 11.2, 15.6\nC_B = (1.0 - BI) ** (1.0 / N_IDX)\nLAMBDA_S = 50.0        # Navier slip (case value); no-slip is approached as λ_s→∞\nEPS_FAC = 0.05         # eps_reg = EPS_FAC * (bed shear rate)  (robust: see report)\n\n\n# ---------------------------------------------------------------------------\n# 1. Parameter map (paper Eq. 3.1)\n# ---------------------------------------------------------------------------\ndef phys_params(n, Bi, Re, phi_deg, lam=LAMBDA_S, eps_fac=EPS_FAC):\n    phi = np.radians(phi_deg)\n    sn, cs, tn = np.sin(phi), np.cos(phi), np.tan(phi)\n    K = (tn * sn ** ((2 - n) / n) / Re) ** (n / 2)\n    tau_y = Bi * sn\n    V = (sn / K) ** (1.0 / n)\n    gdot_bed = (sn * (1 - Bi) / K) ** (1.0 / n)\n    par = dict(g=cs, rho=1.0, nu=0.0, e_x=tn, lambda_s=lam,\n               tau_y=tau_y, eps_reg=eps_fac * gdot_bed, K_hb=K, n_hb=n)\n    return par, V\n\n\n# ---------------------------------------------------------------------------\n# 2. Build the SME(N)+HB system and its symbolic Jacobians A(Q), J_S(Q)\n#    A = d(flux+hydrostatic)/dQ + NCP   (the quasilinear ∂_x coefficient)\n#    J_S = d(source)/dQ\n# ---------------------------------------------------------------------------\n_CACHE = {}\n\n\ndef build(N, quad=12):\n    if (N, quad) in _CACHE:\n        return _CACHE[(N, quad)]\n    p0 = {"g": 1., "rho": 1., "nu": 0., "e_x": 0.2, "lambda_s": 50.,\n          "tau_y": 0.05, "eps_reg": 0.05, "K_hb": 0.1, "n_hb": 0.54}\n    sm = SystemModel.from_model(SME(\n        level=N, closures=[HerschelBulkley(), NavierSlip(), StressFree()],\n        quadrature_order=quad, parameters=p0))\n    st = list(sm.state)\n    ne, nst = sm.n_equations, sm.n_state\n    F = sp.Matrix([sp.sympify(sm.flux[i, 0]) for i in range(ne)])\n    P = sp.Matrix([sp.sympify(sm.hydrostatic_pressure[i, 0]) for i in range(ne)])\n    S = sp.Matrix([sp.sympify(sm.source[i, 0]) for i in range(ne)])\n    Bn = sm.nonconservative_matrix\n    Bm = sp.zeros(ne, nst)\n    for i in range(ne):\n        for j in range(nst):\n            Bm[i, j] = sp.sympify(Bn[i, j, 0])\n    A = F.jacobian(st) + P.jacobian(st) + Bm\n    JS = S.jacobian(st)\n    ps = [sp.Symbol(p) for p in PNAMES]\n    fA = sp.lambdify(st + ps, A, "numpy")\n    fJS = sp.lambdify(st + ps, JS, "numpy")\n    fSrc = sp.lambdify(st + ps, list(S), "numpy")\n    _CACHE[(N, quad)] = (sm, st, fA, fJS, fSrc)\n    return _CACHE[(N, quad)]\n\n\ndef _guess(par, N, n_pts=600):\n    K, nn, ty, lam = par["K_hb"], par["n_hb"], par["tau_y"], par["lambda_s"]\n    ad = par["g"] * par["e_x"]\n    zY = 1.0 - ty / ad\n    z = np.linspace(0, 1, n_pts)\n    with np.errstate(invalid="ignore"):\n        gd = np.where(z < zY, np.maximum(ad * (1 - z) - ty, 0.0) / K, 0.0) ** (1.0 / nn)\n    u = np.concatenate([[0.0], np.cumsum(0.5 * (gd[1:] + gd[:-1]) * np.diff(z))])\n    u = u + ad / lam\n    import numpy.polynomial.legendre as npl\n    return np.array([(2 * i + 1) * np.trapezoid(\n        u * npl.legval(2 * z - 1, np.eye(N + 1)[i]), z) for i in range(N + 1)])\n\n\ndef equilibrium(fSrc, par, N):\n    pv = [par[p] for p in PNAMES]\n    rows = list(range(2, 2 + N + 1))\n\n    def res(qm):\n        Sv = np.asarray(fSrc(*([0.0, 1.0] + list(qm) + pv)), float).ravel()\n        return Sv[rows]\n    sol = fsolve(res, _guess(par, N), full_output=True)[0]\n    return sol, np.abs(res(sol)).max()\n\n\ndef matrices(N, par, quad=12):\n    _, st, fA, fJS, fSrc = build(N, quad)\n    Qeq, rmax = equilibrium(fSrc, par, N)\n    pv = [par[p] for p in PNAMES]\n    Q = [0.0, 1.0] + list(Qeq)\n    A = np.asarray(fA(*(Q + pv)), float)\n    JS = np.asarray(fJS(*(Q + pv)), float)\n    dyn = list(range(1, A.shape[0]))          # drop the static bed row/col\n    return A[np.ix_(dyn, dyn)], JS[np.ix_(dyn, dyn)], Qeq, rmax\n\n\ndef V_reduced(N, par, Qeq):\n    """Streamwise-viscous matrix on the DYNAMIC state ``[h,q_0..q_N]`` (bed row/col\n    dropped, matching :func:`matrices`).  ``−k²V`` is the leading-order in-plane\n    HB stress ``τ_xx=2η∂_x u`` projected onto the moments — see\n    ``hb_visc_analytic``.  ``A``/``B`` are untouched (τ_xx≡0 at ∂_x=0)."""\n    Vf = viscous_V_hb([0.0, 1.0] + list(Qeq), N, par)   # over [b,h,q_0..q_N]\n    dyn = list(range(1, Vf.shape[0]))\n    return Vf[np.ix_(dyn, dyn)]\n\n\n# ---------------------------------------------------------------------------\n# 3. Dispersion — spatial (real ω, complex k) with branch tracking,\n#    plus a temporal→Gaster cross-check.\n# ---------------------------------------------------------------------------\ndef spatial(N, par, V, wtil):\n    Ar, JSr, Qeq, rmax = matrices(N, par)\n    nd = Ar.shape[0]\n    wdim = wtil * V\n    allk = np.zeros((len(wtil), nd), complex)\n    for m, w in enumerate(wdim):\n        allk[m] = -1j * eig(1j * w * np.eye(nd) + JSr, Ar, right=False)\n    # start at smallest ω on the mode with Re(k)>0 and phase speed nearest c_b\n    c0 = wdim[0] / allk[0].real\n    b = np.argmin(np.abs(c0 - C_B * V) + 1e3 * (allk[0].real <= 0))\n    kk = np.zeros(len(wtil), complex)\n    kk[0] = allk[0, b]\n    for m in range(1, len(wtil)):\n        j = np.argmin(np.abs(allk[m] - kk[m - 1]))\n        kk[m] = allk[m, j]\n    alpha = -kk.imag                 # spatial growth (⟨h⟩=1 ⇒ α̃=α)\n    ktil = kk.real\n    return alpha, ktil, wtil / ktil, Qeq, rmax\n\n\ndef temporal_gaster(N, par, V, kmax=3.0, nk=1500, Vmat=None):\n    """Temporal dispersion of the kinematic/roll-wave branch (real k, complex\n    ω), parametrized by k — SMOOTH.  Returns the branch mapped to the paper\'s\n    variables: ω̃, k̃, c̃, and the spatial growth α̃ via Gaster\n    (α = σ/c_g, c_g = dω_r/dk).  Spatial and this agree (cross-checked).\n\n    ``Vmat`` (the reduced streamwise-viscous matrix from :func:`V_reduced`) adds\n    the ``−k²V`` diffusion: the eigenproblem becomes ``σ=maxRe eig(−ikA+B−k²V)``,\n    i.e. ``ikA−B+k²V`` in this module\'s ``ω`` sign convention."""\n    Ar, JSr, _, _ = matrices(N, par)\n    nd = Ar.shape[0]\n    kk = np.linspace(1e-3, kmax, nk)\n    om = np.zeros((len(kk), nd), complex)\n    for i, k in enumerate(kk):\n        M = 1j * k * Ar - JSr + (k ** 2) * Vmat if Vmat is not None else 1j * k * Ar - JSr\n        om[i] = -1j * eig(M, right=False)\n    ph = om[3].real / kk[3]\n    b = np.argmin(np.abs(ph - C_B * V))\n    tr = np.zeros(len(kk), complex)\n    tr[3] = om[3, b]\n    for i in range(4, len(kk)):\n        tr[i] = om[i, np.argmin(np.abs(om[i] - tr[i - 1]))]\n    for i in range(2, -1, -1):\n        tr[i] = om[i, np.argmin(np.abs(om[i] - tr[i + 1]))]\n    wr, sig = tr.real, tr.imag\n    cg = np.gradient(wr, kk)\n    return dict(wtil=wr / V, ktil=kk, ctil=wr / kk / V,\n                alpha=sig / cg, sigma=sig)\n\n\ndef cutoff_wtil(branch):\n    """Rescaled cutoff frequency ω̃_c — the first ω̃ where the temporal growth σ\n    crosses from positive to negative on the tracked branch (``nan`` if σ>0\n    throughout, i.e. NO cutoff — the inviscid SME / B&L defect)."""\n    s = branch["sigma"]\n    zc = np.where((s[:-1] > 0) & (s[1:] <= 0))[0]\n    return float(branch["wtil"][zc[0]]) if len(zc) else np.nan\n\n\ndef sme_Re_c(N, Bi=BI, n=N_IDX, phi=PHI_DEG, lo=2.5, hi=11.0, visc=False):\n    """SME neutral Reynolds: max_k temporal growth crosses zero.  With ``visc`` the\n    ``−k²V`` streamwise diffusion is included — it should leave ``Re_c`` UNCHANGED,\n    because the onset is a LONG-WAVE (k→0) instability where ``−k²V→0`` (verify a)."""\n    def maxgrow(Re):\n        par, V = phys_params(n, Bi, Re, phi)\n        Ar, JSr, Qeq, _ = matrices(N, par)\n        Vmat = V_reduced(N, par, Qeq) if visc else None\n        kk = np.linspace(1e-3, 4.0, 400)\n        return max(np.max((-1j * eig(\n            1j * k * Ar - JSr + (k ** 2) * Vmat if Vmat is not None\n            else 1j * k * Ar - JSr, right=False)).imag) for k in kk)\n    try:\n        return brentq(maxgrow, lo, hi, xtol=0.03)\n    except ValueError:\n        return np.nan\n\n\n# ---------------------------------------------------------------------------\n# 4. Analytic thresholds (α=B=Bi, β=Re; all in the paper\'s convention)\n# ---------------------------------------------------------------------------\ndef Re_c_BL_n(Bi, n):\n    """Refined B&L / Mounkaila Noma Eq. 1.2 critical Reynolds (HB index n)."""\n    num = ((1 + n + 2 * n * Bi * (1 + n * Bi)) * (1 + n) * (2 + n)\n           * (2 + 3 * n) * (1 - Bi) ** (-2.0 / n))\n    den = (2 * (2 + n) * (1 + n) ** 2 + n * (2 + n) * (7 + 9 * n) * Bi\n           + (11 + 19 * n + 6 * n ** 2) * (2 + n * Bi) * n ** 2 * Bi ** 2)\n    return num / den\n\n\ndef Re_c_simple(Bi, n):\n    """Paper Eq. 4.1 practical fit  Re_c ≈ (1+3n/4)(1−Bi)^{−2/n}."""\n    return (1 + 0.75 * n) * (1 - Bi) ** (-2.0 / n)\n\n\n# ---------------------------------------------------------------------------\n# 5. Digitized experiment + B&L curves from Fig. 7 (carbopol, Re=11.2, Bi=0.29,\n#    n=0.54).  Read off the panel images; uncertainty ~±0.01 in ω̃, ~±0.005 in\n#    α̃, ~±0.02 in k̃c_b.  Panel (a) c̃/c_b for the matched case is derived from\n#    panel (b) (c̃/c_b = ω̃/(k̃c_b)) — internally consistent with the same case.\n# ---------------------------------------------------------------------------\n# Panel (b): dispersion  k̃·c_b(ω̃)\nEXP_W_KB = np.array([0.04, 0.08, 0.12, 0.16, 0.20, 0.24, 0.28, 0.32, 0.36, 0.40])\nEXP_KB = np.array([0.040, 0.080, 0.115, 0.150, 0.190, 0.225, 0.255, 0.285, 0.320, 0.355])\nBL_W_KB = np.array([0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40])\nBL_KB = np.array([0.055, 0.115, 0.185, 0.260, 0.340, 0.420, 0.500, 0.585])\n# Panel (c): growth rate  α̃(ω̃)\nEXP_W_A = np.array([0.05, 0.10, 0.15, 0.20, 0.24, 0.28, 0.32, 0.36, 0.40, 0.44,\n                    0.48, 0.52, 0.55])\nEXP_A = np.array([0.006, 0.013, 0.018, 0.021, 0.022, 0.020, 0.016, 0.011,\n                  0.004, -0.001, -0.005, -0.008, -0.009])\nBL_W_A = np.array([0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50,\n                   0.55, 0.60])\nBL_A = np.array([0.004, 0.011, 0.019, 0.027, 0.034, 0.041, 0.046, 0.051,\n                 0.055, 0.058, 0.060, 0.062])\nEXP_W_CUTOFF = 0.42     # experimental cutoff frequency (α̃ → 0), Fig. 7(c)\n\n\n# ---------------------------------------------------------------------------\n# 6. Compute everything and cache to npz\n# ---------------------------------------------------------------------------\ndef compute(levels=(1, 2, 3), recompute=False):\n    cache = os.path.join(OUT, "hb_dispersion.npz")\n    if os.path.exists(cache) and not recompute:\n        d = np.load(cache, allow_pickle=True)\n        return {k: d[k] for k in d.files}\n\n    par, V = phys_params(N_IDX, BI, RE, PHI_DEG)\n    print(f"matched case: (Re,Bi,n)=({RE},{BI},{N_IDX})  φ={PHI_DEG}°")\n    print(f"  V={V:.4f}  c_b={C_B:.4f}  "\n          f"K={par[\'K_hb\']:.4f}  τ_y={par[\'tau_y\']:.4f}  eps_reg={par[\'eps_reg\']:.4f}")\n    wtil = np.linspace(0.01, 0.65, 130)\n    res = {"wtil": wtil, "V": V, "c_b": C_B, "levels": np.array(levels),\n           "EXP_W_KB": EXP_W_KB, "EXP_KB": EXP_KB, "BL_W_KB": BL_W_KB, "BL_KB": BL_KB,\n           "EXP_W_A": EXP_W_A, "EXP_A": EXP_A, "BL_W_A": BL_W_A, "BL_A": BL_A,\n           "EXP_W_CUTOFF": EXP_W_CUTOFF, "RE": RE, "BI": BI, "N_IDX": N_IDX}\n    for N in levels:\n        # spatial (real ω) — the cross-check + branch summary\n        al, kt, ct, Qeq, rmax = spatial(N, par, V, wtil)\n        Vmat = V_reduced(N, par, Qeq)\n        # temporal branch parametrized by k — SMOOTH curves for the figure\n        T = temporal_gaster(N, par, V)                      # inviscid\n        Tv = temporal_gaster(N, par, V, Vmat=Vmat)          # + streamwise-viscous\n        res[f"tw_{N}"] = T["wtil"]\n        res[f"tk_{N}"] = T["ktil"]\n        res[f"tc_{N}"] = T["ctil"]\n        res[f"ta_{N}"] = T["alpha"]\n        res[f"ts_{N}"] = T["sigma"]\n        # viscous branch (streamwise O(ε) stress added)\n        res[f"tw_v_{N}"] = Tv["wtil"]\n        res[f"tk_v_{N}"] = Tv["ktil"]\n        res[f"tc_v_{N}"] = Tv["ctil"]\n        res[f"ta_v_{N}"] = Tv["alpha"]\n        res[f"ts_v_{N}"] = Tv["sigma"]\n        res[f"sp_alpha_{N}"] = al          # spatial growth (validation)\n        res[f"sp_wtil_{N}"] = wtil\n        res[f"clw_{N}"] = T["ctil"][3]\n        wc = cutoff_wtil(Tv)\n        res[f"wcut_v_{N}"] = wc\n        # depth-averaged streamwise viscosity ν_eff (= V[q_0,q_0])\n        res[f"nu_eff_avg_{N}"] = float(Vmat[1, 1])\n        agmax = np.nanmax(al)\n        print(f"  N={N}: eq_resmax={rmax:.1e}  c̃(lw)/c_b={T[\'ctil\'][3]/C_B:.3f}  "\n              f"⟨ν_eff⟩={Vmat[1,1]:.3f}  "\n              f"INVISCID max σ={T[\'sigma\'].max():+.4f} (no cutoff)  "\n              f"VISCOUS max σ={Tv[\'sigma\'].max():+.4f} → cutoff ω̃_c="\n              f"{wc:.3f} (exp≈{EXP_W_CUTOFF})")\n    # thresholds — verify V leaves them unchanged (long-wave onset, −k²V→0)\n    res["Re_c_BL"] = Re_c_BL_n(BI, N_IDX)\n    res["Re_c_simple"] = Re_c_simple(BI, N_IDX)\n    for N in levels:\n        res[f"Re_c_SME_{N}"] = sme_Re_c(N)\n        res[f"Re_c_SME_v_{N}"] = sme_Re_c(N, visc=True)\n    print(f"  thresholds: B&L refined Re_c={res[\'Re_c_BL\']:.2f}  "\n          f"(exp matches refined); SME "\n          + ", ".join(f"N{N}={res[f\'Re_c_SME_{N}\']:.2f}(v {res[f\'Re_c_SME_v_{N}\']:.2f})"\n                      for N in levels))\n    # ε-regularization sensitivity of the cutoff (N=3)\n    eps_facs = np.array([0.02, 0.05, 0.10, 0.20, 0.40])\n    wcuts = []\n    for ef in eps_facs:\n        pe, Ve = phys_params(N_IDX, BI, RE, PHI_DEG, eps_fac=ef)\n        _, _, Qe, _ = matrices(3, pe)\n        Te = temporal_gaster(3, pe, Ve, Vmat=V_reduced(3, pe, Qe))\n        wcuts.append(cutoff_wtil(Te))\n    res["eps_facs"] = eps_facs\n    res["eps_wcuts"] = np.array(wcuts)\n    print("  ε-sensitivity of cutoff ω̃_c (N=3): "\n          + ", ".join(f"fac={ef:.2f}→{wc:.3f}" for ef, wc in zip(eps_facs, wcuts)))\n    np.savez(cache, **res)\n    return res\n\n\n# ---------------------------------------------------------------------------\n# 7. Verify (a): HB at n=1, K_hb=rho*nu reduces to the committed Bingham closure\n#    — proven by identical flux+source Jacobians (⇒ identical steady profile and\n#    threshold), the strongest form of the reduction check.\n# ---------------------------------------------------------------------------\ndef verify_n1_reduction(N=2, quad=10):\n    from zoomy_core.model.models.closures import Bingham\n\n    def jac_funcs(cls, pnames):\n        p0 = {p: 0.1 for p in pnames}; p0["rho"] = 1.0\n        if "n_hb" in pnames:\n            p0["n_hb"] = 0.6\n        sm = SystemModel.from_model(SME(\n            level=N, closures=[cls(), NavierSlip(), StressFree()],\n            quadrature_order=quad, parameters=p0))\n        st = list(sm.state)\n        ne = sm.n_equations\n        S = sp.Matrix([sp.sympify(sm.source[i, 0]) for i in range(ne)])\n        Fp = sp.Matrix([sp.sympify(sm.flux[i, 0]\n                        + sm.hydrostatic_pressure[i, 0]) for i in range(ne)])\n        ps = [sp.Symbol(p) for p in pnames]\n        return (st, sp.lambdify(st + ps, Fp.jacobian(st), "numpy"),\n                sp.lambdify(st + ps, S.jacobian(st), "numpy"))\n\n    pB = ["g", "rho", "nu", "e_x", "lambda_s", "tau_y", "eps_reg"]\n    pH = pB + ["K_hb", "n_hb"]\n    stB, fAB, fJSB = jac_funcs(Bingham, pB)\n    _, fAH, fJSH = jac_funcs(HerschelBulkley, pH)\n    Q = [0.0, 1.0] + [0.3, -0.05, 0.01, -0.002][:N + 1]\n    vB = {"g": .9, "rho": 1., "nu": .13, "e_x": .1, "lambda_s": 50.,\n          "tau_y": .08, "eps_reg": .05}\n    vH = dict(vB, nu=0.0, K_hb=vB["rho"] * .13, n_hb=1.0)  # K_hb = rho*nu\n    aB = Q + [vB[p] for p in pB]; aH = Q + [vH[p] for p in pH]\n    dA = np.abs(np.asarray(fAH(*aH), float) - np.asarray(fAB(*aB), float)).max()\n    dS = np.abs(np.asarray(fJSH(*aH), float) - np.asarray(fJSB(*aB), float)).max()\n    print(f"(a) n=1 reduction  max|A_HB−A_Bingham|={dA:.2e}  "\n          f"max|J_S,HB−J_S,Bingham|={dS:.2e}  "\n          f"→ {\'IDENTICAL\' if max(dA, dS) < 1e-9 else \'DIFFER\'}")\n    return dA, dS\n\n\nif __name__ == "__main__":\n    import sys\n    verify_n1_reduction()\n    verify_recipe(3)                       # streamwise-viscous recipe: const-ν exact\n    par0, _ = phys_params(N_IDX, BI, RE, PHI_DEG)\n    verify_n1_bingham(par0)                # (a) n=1 in-plane ν_eff == Bingham\n    compute(recompute="--recompute" in sys.argv)\n',
}
for _n, _s in _SIBS.items():
    _p = os.path.join(_CASE_DIR, _n + ".py")
    if not os.path.exists(_p):
        open(_p, "w").write(_s)
if _CASE_DIR not in sys.path:
    sys.path.insert(0, _CASE_DIR)


"""Bingham analytics (numpy) — GUI folder-case ``visualize.py`` (REQ-150).

Regenerates the ANALYTICAL figures from the ``run.py`` stores (no time-stepping):

  * ``output/fig_bingham_hb_dispersion.png`` — SME(N)+HB linear dispersion vs the
    Mounkaila Noma 2021 experiment vs Balmforth & Liu 2004, in the paper's
    rescaled variables (phase speed ``c/c_b``, dispersion ``k*c_b``, growth rate
    ``alpha``);  reads ``output/hb_dispersion.npz``;
  * ``output/fig_bingham_hb_dispersion_visc.png`` — the O(eps) streamwise-viscous
    test (``figures.viscous``);
  * ``output/fig_bingham_threshold.png`` — the Liu & Mei ``beta_c(alpha)``
    threshold curve with the bracket points (beta = 3 / 6.35 / 12 at alpha=0.5)
    and the SME ``Re_c`` convergence onto the refined/experimental value;  reads
    ``output/bingham_analytics.npz``.

Headless (Agg).  Acceptance: SME(3) ``Re_c ~ 5.36`` ~ refined 5.33 ~ experiment;
SME shares B&L's missing cutoff (``omega_c`` present only with the O(eps) term,
~4x below the experimental 0.42).
"""

import json
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from zoomy_core.postprocessing import style
import hb_dispersion as HB

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
             if "__file__" in globals() else os.getcwd())
OUT = os.path.join(CASE_DIR, "output")

#: Full analytics settings (the case's settings.json), used whenever the sibling
#: settings.json is absent (notebook) or GUI-generic (no "dispersion" key).
_CASE_SETTINGS = {'name': 'bingham_analytics',
 'backend': 'numpy',
 'analysis': 'linear',
 'model': {'type': 'SME',
           'rheology': 'herschel_bulkley',
           'g': 9.81,
           's': 0.1,
           'H0': 1.0},
 'threshold': {'alpha': 0.5, 'beta_ref': 6.35, 'betas': [3.0, 6.35, 12.0]},
 'dispersion': {'Re': 11.2,
                'Bi': 0.29,
                'n': 0.54,
                'phi_deg': 15.6,
                'lambda_s': 50.0,
                'eps_fac': 0.05,
                'quadrature_order': 12,
                'levels': [1, 2, 3, 4]},
 'figures': {'viscous': True}}


def load_settings(path=None):
    p = path or os.path.join(CASE_DIR, "settings.json")
    s = json.load(open(p)) if os.path.exists(p) else {}
    if "dispersion" not in s:                     # GUI-generic or missing
        s = json.loads(json.dumps(_CASE_SETTINGS))
    return s
style.use("screen")

C_EXP = "#d62728"     # experiment (red circles)
C_BL = "#2ca02c"      # Balmforth & Liu 2004 (green)
C_LW = "0.25"         # long-wave reference (black)
C_SME = {2: style.CYCLE[0], 3: style.CYCLE[1]}
C_INV = style.CYCLE[1]
C_VIS = style.CYCLE[3]
C_ASSUM = "#7f7f7f"        # assumed-profile / Liu&Mei-like threshold (grey)
RE_C_ASSUMED = 6.56        # assumed-profile threshold (== resolved SME N=2)


# --------------------------------------------------------------------------- #
# 1. dispersion figure (SME vs experiment vs B&L) — 3 panels
# --------------------------------------------------------------------------- #
def fig_dispersion(d):
    c_b = float(d["c_b"])
    w_cut = float(d["EXP_W_CUTOFF"])
    wt = np.linspace(0.0, 0.66, 200)

    def win(N, key, hi=0.66):
        w = d[f"tw_{N}"]
        m = w <= hi
        return w[m], d[f"{key}_{N}"][m]

    fig, (axC, axK, axA) = plt.subplots(1, 3, figsize=(15.5, 5.0))

    # A: phase speed c/c_b
    axC.axhline(1.0, color=C_LW, lw=1.2, ls="--", label=r"long-wave $c_b$")
    axC.plot(d["EXP_W_KB"], d["EXP_W_KB"] / d["EXP_KB"], "o", color=C_EXP,
             ms=7, mec="k", mew=0.5, label="experiment (Fig. 7)")
    axC.plot(d["BL_W_KB"], d["BL_W_KB"] / d["BL_KB"], "-", color=C_BL, lw=2.6,
             label="Balmforth & Liu 2004")
    for N in (2, 3):
        w, tc = win(N, "tc")
        axC.plot(w, tc / c_b, color=C_SME[N], lw=2.4, label=f"SME(N={N}) resolved")
    axC.set(xlabel=r"$\tilde\omega$", ylabel=r"$\tilde c / c_b$",
            xlim=(0, 0.6), ylim=(0.4, 1.7))
    axC.set_title("Phase speed")
    axC.grid(alpha=0.3)
    axC.legend(fontsize=8.5, loc="upper right")

    # B: dispersion k*c_b
    axK.plot(wt, wt, color=C_LW, lw=1.6, ls="--",
             label=r"long-wave $\tilde k c_b=\tilde\omega$")
    axK.plot(d["EXP_W_KB"], d["EXP_KB"], "o", color=C_EXP, ms=7, mec="k",
             mew=0.5, label="experiment")
    axK.plot(d["BL_W_KB"], d["BL_KB"], "-", color=C_BL, lw=2.6,
             label="Balmforth & Liu 2004")
    for N in (2, 3):
        w, tk = win(N, "tk")
        axK.plot(w, tk * c_b, color=C_SME[N], lw=2.4, label=f"SME(N={N})")
    axK.set(xlabel=r"$\tilde\omega$", ylabel=r"$\tilde k\, c_b$",
            xlim=(0, 0.45), ylim=(0, 0.6))
    axK.set_title("Dispersion relation")
    axK.grid(alpha=0.3)
    axK.legend(fontsize=8.5, loc="upper left")

    # C: growth rate alpha
    axA.axhline(0.0, color="k", lw=0.8)
    axA.plot(d["BL_W_A"], d["BL_A"], "-", color=C_BL, lw=2.6,
             label="Balmforth & Liu 2004")
    axA.plot(d["EXP_W_A"], d["EXP_A"], "o", color=C_EXP, ms=7, mec="k",
             mew=0.5, label="experiment")
    for N in (2, 3):
        w, ta = win(N, "ta")
        axA.plot(w, ta, color=C_SME[N], lw=2.4, label=f"SME(N={N})")
    axA.axvline(w_cut, color=C_EXP, ls=":", lw=1.6)
    axA.annotate("experimental\ncutoff " r"$\tilde\omega_c\!\approx\!0.42$",
                 xy=(w_cut, 0.0), xytext=(0.45, 0.03), color=C_EXP, fontsize=9,
                 arrowprops=dict(arrowstyle="->", color=C_EXP, lw=1.2))
    axA.set(xlabel=r"$\tilde\omega$", ylabel=r"$\tilde\alpha$  (spatial growth)",
            xlim=(0, 0.65), ylim=(-0.02, 0.07))
    axA.set_title("Growth rate")
    axA.grid(alpha=0.3)
    axA.legend(fontsize=8.5, loc="lower left")

    Rc_bl, Rc3 = float(d["Re_c_BL"]), float(d["Re_c_SME_3"])
    fig.suptitle(
        "Herschel-Bulkley film (Re=11.2, Bi=0.29, n=0.54): resolved SME vs "
        "Mounkaila Noma 2021 experiment vs Balmforth & Liu 2004\n"
        f"threshold OK (SME N=3 $Re_c$={Rc3:.2f} ~ refined {Rc_bl:.2f} ~ "
        "experiment) — but dispersion NOT captured: SME shares B&L's missing "
        "cutoff", fontsize=11.5)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    out = os.path.join(OUT, "fig_bingham_hb_dispersion.png")
    fig.savefig(out, dpi=190)
    plt.close(fig)
    return out


# --------------------------------------------------------------------------- #
# 2. viscous test figure (streamwise O(eps) stress supplies a cutoff)
# --------------------------------------------------------------------------- #
def _cg_valid(w, k):
    cg = np.gradient(w, k)
    good = cg > 0
    stop = np.argmax(~good) if not good.all() else len(good)
    return slice(0, stop if stop > 0 else len(good))


def fig_dispersion_visc(d):
    c_b = float(d["c_b"])
    w_cut = float(d["EXP_W_CUTOFF"])
    N = 3
    wcut_v = float(d[f"wcut_v_{N}"])
    Rc, Rcv = float(d[f"Re_c_SME_{N}"]), float(d[f"Re_c_SME_v_{N}"])
    Rc_bl = float(d["Re_c_BL"])

    wv, kv, cv, av = (d[f"tw_v_{N}"], d[f"tk_v_{N}"], d[f"tc_v_{N}"], d[f"ta_v_{N}"])
    sl = _cg_valid(wv * float(d["V"]), kv)
    wvc, kvc, cvc, avc = wv[sl], kv[sl], cv[sl], av[sl]
    mAB = wvc <= wcut_v + 0.03
    wAB, kAB, cAB = wvc[mAB], kvc[mAB], cvc[mAB]
    wi, ki, ci, ai = (d[f"tw_{N}"], d[f"tk_{N}"], d[f"tc_{N}"], d[f"ta_{N}"])
    mi = wi <= 0.66

    fig, (axC, axK, axA) = plt.subplots(1, 3, figsize=(15.5, 5.0))

    axC.axhline(1.0, color=C_LW, lw=1.2, ls="--", label=r"long-wave $c_b$")
    axC.plot(d["EXP_W_KB"], d["EXP_W_KB"] / d["EXP_KB"], "o", color=C_EXP,
             ms=7, mec="k", mew=0.5, label="experiment (Fig. 7)")
    axC.plot(d["BL_W_KB"], d["BL_W_KB"] / d["BL_KB"], "-", color=C_BL, lw=2.4,
             label="Balmforth & Liu 2004")
    axC.plot(wi[mi], ci[mi] / c_b, color=C_INV, lw=2.4, label="SME(3) inviscid")
    axC.plot(wAB, cAB / c_b, color=C_VIS, lw=2.6,
             label=r"SME(3) + $\partial_x\tau_{xx}$")
    axC.set(xlabel=r"$\tilde\omega$", ylabel=r"$\tilde c / c_b$",
            xlim=(0, 0.45), ylim=(0.4, 1.7))
    axC.set_title("Phase speed — viscosity does NOT lift it")
    axC.grid(alpha=0.3)
    axC.legend(fontsize=8.5, loc="upper right")

    wt = np.linspace(0.0, 0.66, 200)
    axK.plot(wt, wt, color=C_LW, lw=1.4, ls="--", label=r"$\tilde k c_b=\tilde\omega$")
    axK.plot(d["EXP_W_KB"], d["EXP_KB"], "o", color=C_EXP, ms=7, mec="k",
             mew=0.5, label="experiment")
    axK.plot(d["BL_W_KB"], d["BL_KB"], "-", color=C_BL, lw=2.4,
             label="Balmforth & Liu 2004")
    axK.plot(wi[mi], ki[mi] * c_b, color=C_INV, lw=2.4, label="SME(3) inviscid")
    axK.plot(wAB, kAB * c_b, color=C_VIS, lw=2.6, label=r"SME(3) + $\partial_x\tau_{xx}$")
    axK.set(xlabel=r"$\tilde\omega$", ylabel=r"$\tilde k\, c_b$",
            xlim=(0, 0.45), ylim=(0, 0.6))
    axK.set_title("Dispersion relation")
    axK.grid(alpha=0.3)
    axK.legend(fontsize=8.5, loc="upper left")

    axA.axhline(0.0, color="k", lw=0.8)
    axA.plot(d["BL_W_A"], d["BL_A"], "-", color=C_BL, lw=2.4,
             label="Balmforth & Liu 2004")
    axA.plot(d["EXP_W_A"], d["EXP_A"], "o", color=C_EXP, ms=7, mec="k",
             mew=0.5, label="experiment")
    axA.plot(wi[mi], ai[mi], color=C_INV, lw=2.4, label="SME(3) inviscid (no cutoff)")
    axA.plot(wvc, avc, color=C_VIS, lw=2.6,
             label=r"SME(3) + $\partial_x\tau_{xx}$ (cutoff)")
    axA.axvline(w_cut, color=C_EXP, ls=":", lw=1.6)
    axA.annotate(r"exp cutoff $\tilde\omega_c\!\approx\!0.42$",
                 xy=(w_cut, 0.0), xytext=(0.44, 0.045), color=C_EXP, fontsize=9,
                 arrowprops=dict(arrowstyle="->", color=C_EXP, lw=1.2))
    axA.axvline(wcut_v, color=C_VIS, ls=":", lw=1.6)
    axA.annotate("SME-visc cutoff\n" r"$\tilde\omega_c$" f"$\\approx${wcut_v:.2f}"
                 "\n(4x too low)",
                 xy=(wcut_v, 0.0), xytext=(0.16, -0.015), color=C_VIS, fontsize=9,
                 arrowprops=dict(arrowstyle="->", color=C_VIS, lw=1.2))
    axA.set(xlabel=r"$\tilde\omega$", ylabel=r"$\tilde\alpha$  (spatial growth)",
            xlim=(0, 0.65), ylim=(-0.04, 0.07))
    axA.set_title("Growth rate — viscosity SUPPLIES a cutoff (over-damped)")
    axA.grid(alpha=0.3)
    axA.legend(fontsize=8.5, loc="upper right")

    efs, ewc = d["eps_facs"], d["eps_wcuts"]
    eps_note = ", ".join(f"{f:.2f}:{w:.2f}" for f, w in zip(efs, ewc))
    fig.suptitle(
        "Herschel-Bulkley film (Re=11.2, Bi=0.29, n=0.54): adding the O(eps) "
        r"streamwise-viscous stress $\tau_{xx}=2\eta\,\partial_x u$ to the SME"
        "\n"
        f"cutoff APPEARS ($\\tilde\\omega_c$~{wcut_v:.2f}, was none) but 4x below "
        f"exp 0.42 & phase speed still < $c_b$;  threshold unchanged "
        f"($Re_c$={Rc:.2f}->{Rcv:.2f}, ref {Rc_bl:.2f});  "
        f"eps-sens omega_c(eps_fac): {eps_note}", fontsize=10.5)
    fig.tight_layout(rect=(0, 0, 1, 0.90))
    out = os.path.join(OUT, "fig_bingham_hb_dispersion_visc.png")
    fig.savefig(out, dpi=190)
    plt.close(fig)
    return out


# --------------------------------------------------------------------------- #
# 3. threshold-bracket figure — the Liu & Mei beta_c(alpha) + Re_c convergence
# --------------------------------------------------------------------------- #
_VCOLOR = {"stable": C_BL, "marginal": "#ff7f0e", "unstable": C_EXP}


def fig_threshold(s):
    ac, bcc = s["alpha_curve"], s["beta_c_curve"]
    alpha = float(s["alpha"])
    bc = float(s["beta_c"])
    betas, verdicts = s["betas"], s["verdicts"]
    levels = s["levels"]
    Re_sme, Re_bl = s["Re_c_SME"], float(s["Re_c_BL"])

    fig, (axT, axR) = plt.subplots(1, 2, figsize=(12.5, 5.0))

    # (a) Liu & Mei threshold curve + the alpha=0.5 bracket
    axT.plot(ac, bcc, color=C_LW, lw=2.4,
             label=r"Liu & Mei $\beta_c(\alpha)$ (Eq. 47)")
    axT.axvline(alpha, color="0.6", lw=1.0, ls="--")
    for beta, v in zip(betas, verdicts):
        v = str(v)
        axT.plot([alpha], [beta], "o", ms=11, color=_VCOLOR[v], mec="k", mew=0.6,
                 zorder=5)
        axT.annotate(f"$\\beta$={beta:g}\n{v}", xy=(alpha, beta),
                     xytext=(alpha + 0.05, beta), fontsize=9, color=_VCOLOR[v],
                     va="center")
    axT.annotate(rf"$\beta_c({alpha})={bc:.2f}$", xy=(alpha, bc),
                 xytext=(0.06, 9.5), fontsize=10,
                 arrowprops=dict(arrowstyle="->", lw=1.0))
    axT.set(xlabel=r"yield parameter $\alpha=\tau_y/(\rho g H\sin\theta)$",
            ylabel=r"Reynolds-like $\beta$", xlim=(0, 0.8), ylim=(0, 14))
    axT.set_title("Linear instability threshold (uniform film)\n"
                  r"below $\beta_c$ stable · above $\beta_c$ roll waves")
    axT.grid(alpha=0.3)
    axT.legend(fontsize=9, loc="upper left")

    # (b) SME Re_c convergence: refined/exp line + assumed-profile 6.56 line,
    #     with the N=1 'no finite threshold' case marked distinctly
    #     (parity with fig_bingham_hb_Rec_convergence.png).
    lev = np.asarray(levels, float)
    Rc = np.asarray(Re_sme, float)
    finite = np.isfinite(Rc)
    axR.axhline(Re_bl, color=C_BL, lw=2.4, ls="-.",
                label=rf"refined B&L / exp  $Re_c\approx{Re_bl:.2f}$")
    axR.axhspan(Re_bl - 0.15, Re_bl + 0.15, color=C_BL, alpha=0.15)
    axR.axhline(RE_C_ASSUMED, color=C_ASSUM, lw=2.2, ls="--",
                label=f"assumed-profile / L&M-like ≈ {RE_C_ASSUMED:.2f}")
    axR.plot(lev[finite], Rc[finite], "-o", color=C_SME[3], lw=2.4, ms=11,
             mec="k", mew=0.6, zorder=6, label=r"SME($N$) resolved $Re_c$")
    for N, rc in zip(lev[finite], Rc[finite]):
        axR.annotate(f"{rc:.2f}", xy=(N, rc), xytext=(0, 12),
                     textcoords="offset points", ha="center", fontsize=10,
                     color=C_SME[3], fontweight="bold")
    # N=1: no finite threshold (stable across the physical band) — up-arrow
    if (~finite).any():
        n1 = lev[~finite][0]
        axR.annotate("", xy=(n1, RE_C_ASSUMED + 1.1), xytext=(n1, RE_C_ASSUMED - 0.2),
                     arrowprops=dict(arrowstyle="-|>", color=C_SME[3], lw=2.2))
        axR.plot([n1], [RE_C_ASSUMED - 0.2], "o", color="white", mec=C_SME[3],
                 mew=2.0, ms=11, zorder=6)
        axR.annotate(r"N=1: NO threshold" "\n" r"($Re_c\!\to\!\infty$)",
                     xy=(n1, RE_C_ASSUMED + 0.85), xytext=(n1 + 0.1, RE_C_ASSUMED + 0.85),
                     fontsize=9, color=C_SME[3], va="center")
    axR.set(xlabel="moment level $N$", ylabel=r"critical Reynolds $Re_c$",
            xlim=(min(levels) - 0.5, max(levels) + 0.5), ylim=(4.6, 8.0))
    axR.set_xticks(list(levels))
    axR.set_title("Carbopol case (Bi=0.29, n=0.54):\n"
                  r"SME $Re_c$: N=2 assumed (6.56) → N=3,4 refined & holds")
    axR.grid(alpha=0.3)
    axR.legend(fontsize=8.5, loc="upper right")

    fig.suptitle("Bingham / Herschel-Bulkley roll-wave analytics — "
                 "linear threshold bracket & critical Reynolds", fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    out = os.path.join(OUT, "fig_bingham_threshold.png")
    fig.savefig(out, dpi=190)
    plt.close(fig)
    return out


# --------------------------------------------------------------------------- #
# 4. linear phase-speed convergence vs moment level N
# --------------------------------------------------------------------------- #
K_OBS = 0.2   # observable wavenumber (mid experiment band, Fig. 7)


def fig_speed_convergence(d, levels):
    """Linear phase speed c/c_b vs moment level (parity with
    ``fig_bingham_hb_speed_convergence.png``).

    Reads the per-level temporal branches already in ``hb_dispersion.npz``
    (``clw_N`` = long-wave k→0 phase speed, ``tk_N``/``tc_N`` = the k-parametrised
    dispersion/phase-speed branch): the long-wave speed ``c̃_lw/c_b`` must → 1
    (kinematic ``c_b``) and the finite-k speed at the observable band ``k̃=0.2``.
    """
    c_b = float(d["c_b"])
    lev = np.asarray(levels, float)
    c_lw = np.array([float(d[f"clw_{int(N)}"]) / c_b for N in lev])
    c_obs = []
    for N in lev:
        tk, tc = d[f"tk_{int(N)}"], d[f"tc_{int(N)}"]
        c_obs.append(float(tc[np.argmin(np.abs(tk - K_OBS))]) / c_b)
    c_obs = np.array(c_obs)

    C_LW = style.CYCLE[0]
    C_OBS = style.CYCLE[1]
    C_CB = style.CYCLE[2]

    fig, ax = plt.subplots(figsize=(8.2, 5.6))
    ax.axhline(1.0, color=C_CB, lw=2.6,
               label=r"kinematic $c_b=(1-Bi)^{1/n}$  (long-wave target)")
    ax.axhspan(0.97, 1.03, color=C_CB, alpha=0.15)
    ax.plot(lev, c_lw, "-o", color=C_LW, lw=2.4, ms=11, mec="k", mew=0.7,
            zorder=6, label=r"long-wave $\tilde c_\mathrm{lw}/c_b$  ($k\!\to\!0$)")
    ax.plot(lev, c_obs, "-s", color=C_OBS, lw=2.4, ms=10, mec="k", mew=0.7,
            zorder=6, label=rf"finite-$k$ $\tilde c/c_b$  ($\tilde k={K_OBS:.1f}$, obs. band)")
    for x, y in zip(lev, c_lw):
        ax.annotate(f"{y:.3f}", xy=(x, y), xytext=(0, 11),
                    textcoords="offset points", ha="center", fontsize=10,
                    color=C_LW, fontweight="bold")
    for x, y in zip(lev, c_obs):
        ax.annotate(f"{y:.3f}", xy=(x, y), xytext=(0, -16),
                    textcoords="offset points", ha="center", fontsize=10, color=C_OBS)
    if lev.size >= 3:
        ax.annotate("N=3,4 hold (Δ<0.01)\n— converged, no drift",
                    xy=(lev[-1], c_lw[2:].mean()), xytext=(2.55, 0.55),
                    fontsize=10, color=C_LW,
                    arrowprops=dict(arrowstyle="->", color=C_LW, lw=1.2))
    ax.annotate("N=1: kinematic\nspeed collapses\n(no unstable branch)",
                xy=(lev[0], c_lw[0]), xytext=(lev[0] + 0.15, 0.42), fontsize=9.5,
                color="0.3", arrowprops=dict(arrowstyle="->", color="0.3", lw=1.0))
    ax.set(xlabel="moment level  N", ylabel=r"linear phase speed  $\tilde c / c_b$",
           xlim=(min(lev) - 0.4, max(lev) + 0.4), ylim=(0.30, 1.15))
    ax.set_xticks(list(int(N) for N in lev))
    ax.grid(alpha=0.3)
    ax.legend(fontsize=9.5, loc="lower right")
    ax.set_title(
        "HB roll-wave LINEAR phase speed vs moment level  (carbopol Bi=0.29, n=0.54)\n"
        "converges to $c_b$ by N=3 and HOLDS — no drift  "
        "(nonlinear shock speed: separate benchmark)", fontsize=11.0)
    fig.tight_layout()
    out = os.path.join(OUT, "fig_bingham_hb_speed_convergence.png")
    fig.savefig(out, dpi=190)
    plt.close(fig)
    return out


def visualize(settings=None):
    if settings is None:
        settings = load_settings()

    # dispersion store (cached by run.py -> output/hb_dispersion.npz)
    d = HB.compute(levels=tuple(settings["dispersion"].get("levels", (1, 2, 3))),
                   recompute=False)
    # threshold summary store
    sp = os.path.join(OUT, settings.get("name", "bingham_analytics") + ".npz")
    if not os.path.exists(sp):
        raise SystemExit(f"no analytics store at {sp} — run.py first")
    s = dict(np.load(sp, allow_pickle=True))

    print("\n=== Bingham analytics (linear threshold + dispersion) ===")
    print(f"Liu&Mei beta_c(alpha={float(s['alpha'])}) = {float(s['beta_c']):.3f}")
    for beta, v in zip(s["betas"], s["verdicts"]):
        print(f"  beta={float(beta):>6.2f} -> {str(v).upper()}")
    print(f"refined Re_c (B&L) = {float(s['Re_c_BL']):.2f}")
    for N, rc, wc in zip(s["levels"], s["Re_c_SME"], s["wcut_v"]):
        print(f"  SME(N={int(N)}): Re_c={float(rc):.2f}  "
              f"cutoff omega_c(visc)={float(wc):.3f} (exp {float(s['EXP_W_CUTOFF'])})")

    levels = list(settings["dispersion"].get("levels", (1, 2, 3)))
    outs = [fig_dispersion(d), fig_threshold(s),
            fig_speed_convergence(d, levels)]
    if settings.get("figures", {}).get("viscous", True):
        outs.append(fig_dispersion_visc(d))
    for o in outs:
        print("->", o)
    return outs


visualize()
