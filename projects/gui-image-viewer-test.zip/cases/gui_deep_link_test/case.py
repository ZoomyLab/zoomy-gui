# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
# ---

# %% [markdown] zoomy={"role": "meta", "title": "GUI deep-link + image-viewer smoke test", "description": "Fixture case for the #/open deep link and the PNG/GIF image viewer (see outputs/). Not a real simulation -- part of the Test: case data GitHub release."}
# # GUI deep-link + image-viewer smoke test
#
# This case exists only so `outputs/` is a real case folder the GUI can open
# via `#/open?project=<this zip>&path=cases/gui_deep_link_test/outputs/...`.
# The PNG and GIF in `outputs/` are copied from an existing thesis deliverable
# and an MMS-topography study -- they are not produced by running this case.

# %% [markdown] zoomy={"role": "heading", "section": "model"}
# ## Model

# %% zoomy={"role": "model"}
# No model -- this fixture is not meant to be run.

# %% [markdown] zoomy={"role": "heading", "section": "mesh"}
# ## Mesh

# %% zoomy={"role": "mesh"}
# (none)

# %% [markdown] zoomy={"role": "heading", "section": "settings"}
# ## Solver settings

# %% zoomy={"role": "settings", "settings": {}}
settings = {}

# %% [markdown] zoomy={"role": "heading", "section": "visualization"}
# ## Visualization

# %% zoomy={"role": "visualization"}
# See outputs/simulation.png and outputs/mms_topography.gif
