"""Steffler 270 degree bend -- GUI folder-case ``model.py``.

Shallow Moment Equations on the Ghamry and Steffler (2005) 270 degree flume,
Steffler (1984) run 1. ``dimension=3`` is the TOTAL spatial dimension including
the vertical, so the bend's two horizontal directions give the grouped state
``[b, h, q_x_0..q_x_L, q_y_0..q_y_L]``.

Closures are the paper's set, all stock zoomy_core pieces: Elder algebraic eddy
viscosity in the bulk, a rough-wall quadratic drag at the bed whose reference
height is chosen so C_f = 1/C*^2 reproduces the paper's Chezy coefficient, and a
stress-free surface. No empirical secondary-flow constant, which is the point
Ghamry and Steffler make about their own model.

The bed is sampled from the mesh node z, which is where the .geo encodes the
0.00083 longitudinal slope. Nearest neighbour on a plain numpy distance, so the
card needs neither meshio nor scipy and runs under Pyodide.
"""
import math
import os
import re

import numpy as np

import zoomy_core.model.initial_conditions as IC
from zoomy_core.model.boundary_conditions import Dirichlet, Wall
from zoomy_core.model.models import SME
from zoomy_core.model.models.closures import ElderViscosity, RoughWall, StressFree
from zoomy_core.numerics import NumericalSystemModel
from zoomy_core.numerics.numerical_system_model import ReconstructionSpec
from zoomy_core.systemmodel.system_model import SystemModel

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())

#: Steffler (1984) run 1, as tabulated by Ghamry and Steffler (2005) section 6.
STEFFLER = {"g": 9.81, "Q": 0.0235, "width": 1.07, "h_out": 0.061,
            "U": 0.36, "Cstar": 16.0, "ks": 0.0013, "kappa": 0.41}


def _params():
    """Chezy-matched rough wall plus the Elder friction velocity.

    RoughWall is tau_b = rho C_f u|u| with C_f = (kappa/ln(z_p/z0))^2 and
    z0 = k_s/30. Taking z_p = z0 exp(kappa C*) makes ln(z_p/z0) = kappa C*, so
    C_f = 1/C*^2 = 1/256, which is the paper's quadratic Chezy drag.
    """
    z0 = STEFFLER["ks"] / 30.0
    return {"g": STEFFLER["g"],
            "kappa": STEFFLER["kappa"],
            "k_s": STEFFLER["ks"],
            "z_p": z0 * math.exp(STEFFLER["kappa"] * STEFFLER["Cstar"]),
            "u_star": STEFFLER["U"] / STEFFLER["Cstar"]}


def _bcs(level):
    """Per-field boundary conditions, resolved BY NAME against the state.

    inflow prescribes the specific discharge on the mean streamwise mode and
    zeroes every other momentum mode, which is the paper's u_i = v_i = 0.
    outflow prescribes the depth. Walls reflect the normal momentum while the
    depth extrapolates.
    """
    q_spec = STEFFLER["Q"] / STEFFLER["width"]
    mom = ([f"q_x_{j}" for j in range(level + 1)]
           + [f"q_y_{j}" for j in range(level + 1)])
    bcs = [Wall("wall", on="momentum")]
    for f in mom:
        bcs.append(Dirichlet("inflow", on=f,
                             value=(-q_spec if f == "q_x_0" else 0.0)))
    bcs.append(Dirichlet("outflow", on="h", value=STEFFLER["h_out"]))
    return bcs


def _bed_sampler(mesh_file, n_state, h0):
    """Bed from the mesh node z, nearest neighbour, numpy only."""
    txt = open(mesh_file).read()
    m = re.search(r"\$Nodes\s*\n(\d+)\s*\n(.*?)\$EndNodes", txt, re.S)
    rows = [ln.split() for ln in m.group(2).strip().split("\n")]
    pts = np.array([[float(r[1]), float(r[2]), float(r[3])] for r in rows])
    xy, z = pts[:, :2], pts[:, 2]

    def ic(xv):
        d = (xy[:, 0] - float(xv[0])) ** 2 + (xy[:, 1] - float(xv[1])) ** 2
        return np.array([float(z[int(np.argmin(d))]), float(h0)]
                        + [0.0] * (n_state - 2))
    return ic, (float(z.min()), float(z.max()))


def build_model(settings, mesh, case_dir=None):
    case_dir = case_dir or CASE_DIR
    mcfg = settings.get("model") or {}
    level = int(mcfg.get("level", 1))
    order = int((settings.get("numerics") or {}).get("order", 1))

    model = SME(level=level, dimension=3,
                closures=[ElderViscosity(), RoughWall(), StressFree()],
                parameters=_params(), boundary_conditions=_bcs(level))
    sm = SystemModel.from_model(model)

    mesh_name = (settings.get("mesh") or {}).get(
        "file", "curved_curved_open_channel_mesh_v2.msh")
    ic, (zmin, zmax) = _bed_sampler(os.path.join(case_dir, mesh_name),
                                    len(sm.state), STEFFLER["h_out"])
    sm.initial_conditions = IC.UserFunction(function=ic)
    sm.aux_initial_conditions = IC.Constant(constants=lambda n: np.zeros(n))

    print(f"model: SME(level={level}, dimension=3) state="
          f"{[str(s) for s in sm.state]}; bed z in [{zmin:.4f}, {zmax:.4f}]",
          flush=True)
    nsm = NumericalSystemModel.from_system_model(
        sm, reconstruction=ReconstructionSpec(order=order))
    return {"nsm": nsm, "sm": sm}
