"""Steffler 270 degree bend -- GUI folder-case ``mesh.py``.

Loads the curved open-channel mesh from the deployed mesh catalog. The name
carries a ``_v2`` because the catalog's default export is gmsh 4.1 BINARY, which
writes one block PER ENTITY: this surface is 14 transfinite patches and
``LSQMesh.from_msh`` reads only the FIRST block, so the 4.1 file silently loads
a fragment of the bend (14 cells for __coarse, 143 for the base, against 710
here). The ``_v2`` files are flat gmsh 2.2 and carry the whole surface.
"""
import os

from zoomy_core.mesh import LSQMesh

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())

MESH_CATALOG = "https://zoomylab.github.io/meshes/meshes/"
MESH_NAME = "curved_curved_open_channel_mesh_v2.msh"


def _ensure_mesh(fname, case_dir=None):
    p = os.path.join(case_dir or CASE_DIR, fname)
    if not os.path.exists(p):
        import urllib.request
        print("fetching mesh:", MESH_CATALOG + fname, flush=True)
        urllib.request.urlretrieve(MESH_CATALOG + fname, p)
    return p


def build_mesh(settings, case_dir=None):
    name = (settings.get("mesh") or {}).get("file", MESH_NAME)
    mesh = LSQMesh.from_msh(_ensure_mesh(name, case_dir or CASE_DIR))
    print(f"mesh: {name} -> {mesh.n_cells} cells", flush=True)
    return mesh
