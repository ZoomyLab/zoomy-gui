"""sme_vof_triple — GUI REPLAY of the recorded SME(1)|VOF|SME(1) triple run.

The REAL solver invocation is the case's own run.py (thesis/notebooks/coupling/
cases/sme_vof_triple): three preCICE participants (two zoomyFoam_L1 SME channels
+ a stock incompressibleVoF box) coupled inside the openfoam container — an
environment the pullable backend images do not carry. Rerun it in the case
folder with:

    python run.py --level 1 --snap gui_triple

This card materializes that recorded run (raw foam time dirs + h5 stores, VTK/
logs stripped) so the Visualization card recomposes the case's real five-station
figure + mass audit from the actual participant outputs. Replayed data, clearly
labeled — no simulation happens here.
"""
import io
import os
import shutil
import tarfile
import urllib.request

PAYLOAD = ("https://github.com/ZoomyLab/Zoomy/releases/download/"
           "case-data-v1/sme_vof_snap_gui_triple.tar.gz")
RUN = "snap_gui_triple"

if not os.path.isdir(RUN):
    print("fetching recorded triple run:", PAYLOAD, flush=True)
    with urllib.request.urlopen(PAYLOAD, timeout=300) as r:
        _buf = io.BytesIO(r.read())
    with tarfile.open(fileobj=_buf, mode="r:gz") as t:
        t.extractall(".")
    print("extracted ->", RUN)
else:
    print("recorded run already present ->", RUN)

shutil.copy(os.path.join(RUN, "outputs", "swe_case.h5"), "simulation.h5")
print("artifact -> simulation.h5 (SME participant store; VOF store at "
      + RUN + "/outputs/vof_case.h5, second SME at " + RUN + "/outputs/swe2_case.h5)")
