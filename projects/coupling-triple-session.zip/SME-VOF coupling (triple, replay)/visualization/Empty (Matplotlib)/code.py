import os as _os
_HERE = (_os.path.dirname(_os.path.abspath(__file__))
         if "__file__" in globals() else _os.getcwd())
_os.makedirs(_os.path.join(_HERE, "analysis"), exist_ok=True)
_tma = _os.path.join(_HERE, "analysis", "total_mass_audit.py")
if not _os.path.exists(_tma):
    open(_tma, "w").write('"""Total water mass of a CLOSED twoway run (wall at the SME outer boundary,\nwalls around the VOF except the coupled inlet and the top atmosphere, which\nwater never reaches).  M(t) = ∫h dx (SME) + ∫α dA (VOF).  Any drift is\ncoupling-interface loss, measured to field-output precision.\n\nUsage: total_mass_audit.py RUNDIR [label] [NZ]\n       (NZ>1: 3D VOF, mass per unit width = sum(alpha)*dx*dy/NZ)\n"""\nimport sys\nfrom pathlib import Path\nimport numpy as np\n\nfrom zoomy_core.postprocessing.column_plots import (\n    read_of_field as rd, read_of_frames)\n\nSWE_N, dxs = 120, 0.005\nNX, NY, dxv, dyv = 120, 40, 0.0125, 0.01\n\n\ndef mass_series(run, nz=1):\n    """Matched-time closed-run mass series ``(ts, Ms, Mv)``:\n    ``Ms`` = ∫h dx (SME), ``Mv`` = ∫α dA (VOF), on the VOF frame times.\n\n    MATCHED-TIME evaluation: the two solvers\' write times drift by up to half a\n    write interval; index pairing aliases ``|dM/dt|*dt_offset`` (~1e-4 here) into\n    a phantom drift.  Evaluate M_SME at the VOF frame times by interpolation\n    (M(t) is smooth; the interpolation error is O(d2M/dt2 * dT^2) ~ 1e-7).\n    ``nz>1``: 3D VOF, mass per unit width = sum(alpha)*dx*dy/nz."""\n    run = Path(run)\n    sw = read_of_frames(run / "swe_case", "Q1")\n    vf = read_of_frames(run / "vof_case", "alpha.water")\n    tS = np.array([x[0] for x in sw])\n    MS = np.array([rd(d / "Q1", SWE_N).sum() * dxs for _, d in sw])\n    # triple mode: a second 1-D SME participant shares the same closed box\n    # (swe2_case, [1.5, 2.1], same SWE_N/dxs) -> add its ∫h dx at swe_case times.\n    sw2 = run / "swe2_case"\n    if sw2.is_dir():\n        s2 = read_of_frames(sw2, "Q1")\n        t2 = np.array([x[0] for x in s2])\n        M2 = np.array([rd(d / "Q1", SWE_N).sum() * dxs for _, d in s2])\n        MS = MS + np.interp(tS, t2, M2)\n    ts = np.array([x[0] for x in vf])\n    Mv = np.array([rd(d / "alpha.water", NX * NY * nz).sum() * dxv * dyv / nz\n                   for _, d in vf])\n    keep = (ts >= tS[0]) & (ts <= tS[-1])\n    ts, Mv = ts[keep], Mv[keep]\n    Ms = np.interp(ts, tS, MS)\n    return ts, Ms, Mv\n\n\ndef _report(run, label, nz):\n    ts, Ms, Mv = mass_series(run, nz)\n    M = Ms + Mv\n    n = len(ts)\n    print(f"== {label}: {n} frames, t in [{ts[0]}, {ts[-1]}]")\n    print(f"   M(0) = {M[0]:.8f} m^2   (SME {Ms[0]:.6f} + VOF {Mv[0]:.6f})")\n    print(f"   M(T) = {M[-1]:.8f} m^2  drift {M[-1]-M[0]:+.3e}  "\n          f"({(M[-1]-M[0])/M[0]*100:+.4f}%)")\n    print(f"   max |M(t)-M(0)| over run: {np.abs(M-M[0]).max():.3e}")\n    i = np.argmax(np.abs(np.diff(M)))\n    print(f"   largest single-frame jump: {np.diff(M)[i]:+.3e} at t={ts[i+1]:.2f}")\n    np.save(f"/tmp/total_mass_{label}.npy", np.column_stack([ts, Ms, Mv]))\n\n\nif __name__ == "__main__":\n    RUN = Path(sys.argv[1])\n    LBL = sys.argv[2] if len(sys.argv) > 2 else RUN.name\n    NZ = int(sys.argv[3]) if len(sys.argv) > 3 else 1\n    _report(RUN, LBL, NZ)\n')

"""sme_vof_triple — GUI folder-case `visualize.py`: recompose the TRIPLE view.

Reads the three-participant foam run tree (swe_case | vof_case | swe2_case,
closed box) written by run.py and composes the five-station SME|VOF|SME
picture — mid SME | intf L | mid VOF | intf R | mid SME2 — as a final-time
PNG + GIF plus the closed-box mass audit, in the same styling family as the
sme_vof pair figures (`sme_vof_sme_triple.gif`). Column tools are the shared
`zoomy_core.postprocessing.column_plots` layer (as the pair's visualize.py).

Usage: visualize.py [RUNDIR] [--level N] [--no-gif]
"""
import argparse
import json
from pathlib import Path

import numpy as np

import os
HERE = (Path(__file__).resolve().parent
        if "__file__" in globals() else Path(os.getcwd()))
_SJ = HERE / "settings.json"
#: embedded copy of the case settings; a sibling settings.json is used only
#: when it is the CASE file ("level" key) — the GUI writes a generic one.
S = (json.loads(_SJ.read_text()) if _SJ.exists() else {})
if "level" not in S:
    S = {'name': 'sme_vof_triple',
 'title': 'SME(level) | VOF | SME(level) three-participant coupled dam break '
          '(preCICE)',
 'level': 1,
 'window': 0.002,
 'scheme': 'parallel-explicit',
 'ghost': 'characteristic',
 'outer': 'wall',
 'frozen': 'auto',
 'ledger': 20,
 'closure': 'newtonian',
 'nu': 0.005,
 'lambda_s': 0.1,
 'notes': 'triple sibling of sme_vof: SME|VOF|SME closed box '
          '(coupling-scheme:multi, MODE=triple in generate.py driven by '
          'run.sh). Same production coupling scheme as the pair '
          '(characteristic ghost + qstarMode=rp mass row). run.py routes '
          'run.sh (three participants: swe_case, swe2_case, vof_case); '
          'outputs replayed by visualize.py.'}


def main():
    class a:                     # GUI replay card: fixed args
        rundir = "snap_gui_triple"   # materialized by the Run section
        level = S["level"]
        no_gif = False
    run = Path(a.rundir)

    from zoomy_core.model.models import SME
    from zoomy_core.systemmodel import SystemModel
    from zoomy_core.model.boundary_conditions import (
        BoundaryConditions, Coupled, FromModel)
    from zoomy_core.postprocessing import style
    style.use("screen")
    from zoomy_core.postprocessing.column_plots import (
        read_zoomyfoam, read_vof_raw, plot_water_columns, plot_water_vof,
        plot_profiles, mark_stations, frame_color, animate)
    import matplotlib.pyplot as plt

    bcs = BoundaryConditions([FromModel(tag="outer", definition="wall"),
                              Coupled(tag="coupled", mesh_name="interface")])
    sm = SystemModel.from_model(SME(level=a.level, boundary_conditions=bcs))
    x1 = np.linspace(-0.6, 0, 121); x1 = 0.5 * (x1[:-1] + x1[1:])
    x2 = np.linspace(1.5, 2.1, 121); x2 = 0.5 * (x2[:-1] + x2[1:])

    sme1 = read_zoomyfoam(str(run / "swe_case"), sm, 120, x1, K=40, label="SME")
    sme2 = read_zoomyfoam(str(run / "swe2_case"), sm, 120, x2, K=40, label="SME")
    raw, vmid = read_vof_raw(str(run / "vof_case"), nx=120, ny=40, lx=1.5,
                             ly=0.4, stations=[0.75], label="VOF")

    panels = [("mid SME", -0.30, [sme1], "tab:blue"),
              ("intf L", 0.00, [sme1, vmid], "tab:purple"),
              ("mid VOF", 0.75, [vmid], "tab:green"),
              ("intf R", 1.50, [sme2, vmid], "tab:orange"),
              ("mid SME2", 1.80, [sme2], "tab:red")]

    def draw(fig, t):
        gs = fig.add_gridspec(2, len(panels), height_ratios=[1.2, 1.0],
                              hspace=0.45, wspace=0.45)
        ax = fig.add_subplot(gs[0, :])
        plot_water_vof(ax, raw, t, color=style.COLORS["water"])
        plot_water_columns(ax, sme1, t, style="fill",
                           color=style.COLORS["water"])
        plot_water_columns(ax, sme2, t, style="fill",
                           color=style.COLORS["water"])
        for xi in (0.0, 1.5):
            ax.axvline(xi, color=style.COLORS["interface"], lw=1.6)
        mark_stations(ax, [s for _, s, _, _ in panels],
                      [c for _, _, _, c in panels],
                      labels=[n for n, _, _, _ in panels])
        ax.set_xlim(-0.6, 2.1); ax.set_ylim(0, 0.22)
        ax.set_title(f"SME({a.level}) | VOF | SME({a.level})   t = {t:5.2f} s")
        for k, (name, xq, src, color) in enumerate(panels):
            aa = fig.add_subplot(gs[1, k])
            plot_profiles(aa, src, xq, t,
                          colors=[style.COLORS["reduced"],
                                  style.COLORS["resolved"]][:len(src)])
            aa.set_title(name); aa.set_xlim(-0.6, 0.6); frame_color(aa, color)
        style.figure_legend(fig, extra=[
            ("interface", style.line("interface")),
            ("water", style.line("water", lw=5))])

    # final-time snapshot PNG
    fig = plt.figure(figsize=(13, 6.5))
    draw(fig, float(sme1.t[-1]))
    png = run / f"sme_vof_L{a.level}_triple_final.png"
    fig.savefig(png, dpi=130); plt.close(fig)
    print("->", png)

    # --- closed-box mass audit: SME1 + SME2 + VOF (total_mass_audit sums the
    #     second SME participant automatically when swe2_case is present) ------
    import sys as _sys
    _sys.path.insert(0, str(HERE / "analysis"))
    try:
        from total_mass_audit import mass_series
        ts, Ms, Mv = mass_series(run)
        M = Ms + Mv
        figm, axm = plt.subplots(figsize=(8, 4))
        axm.plot(ts, (M - M[0]) * 1e3, "k-", lw=1.6, label="total M(t)−M(0)")
        axm.plot(ts, (Ms - Ms[0]) * 1e3, "tab:blue", lw=1.0, ls="--",
                 label="SME ∫h dx (both)")
        axm.plot(ts, (Mv - Mv[0]) * 1e3, "tab:green", lw=1.0, ls="--",
                 label="VOF ∫α dA")
        axm.axhline(0.0, color="0.6", lw=0.8)
        axm.set(xlabel="t [s]", ylabel="mass change [$10^{-3}$ m$^2$]",
                title=f"closed triple-run mass audit  "
                      f"drift={M[-1]-M[0]:+.2e} m² "
                      f"({(M[-1]-M[0])/M[0]*100:+.3f}%)")
        axm.grid(alpha=0.3); axm.legend(fontsize=9); figm.tight_layout()
        pmass = run / f"sme_vof_L{a.level}_triple_mass_audit.png"
        figm.savefig(pmass, dpi=130); plt.close(figm)
        print("->", pmass)
    except Exception as e:                                   # pragma: no cover
        print("mass audit skipped:", e)

    if not a.no_gif:
        gif = run / f"sme_vof_L{a.level}_triple.gif"
        animate(draw, list(sme1.t), str(gif), figsize=(13, 6.5), fps=8)
        print("->", gif)


main()
