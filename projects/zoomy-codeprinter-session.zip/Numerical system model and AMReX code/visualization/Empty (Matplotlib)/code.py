import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt

try:
    from zoomy_plotting.plot import style as zstyle
    zstyle.use("thesis")
except Exception:
    mpl.rcParams.update({"font.size": 9, "font.family": "serif",
                         "figure.dpi": 130, "savefig.dpi": 130})

with open("flux_excerpt.txt") as f:
    excerpt = f.read().rstrip("\n")

lines = excerpt.split("\n")
fig = plt.figure(figsize=(7.2, 0.20 * len(lines) + 0.8))
fig.text(0.01, 0.97, "AMReX flux kernel, printed from the numerical system model",
         va="top", fontsize=9)
fig.text(0.01, 0.90, excerpt, va="top", family="monospace", fontsize=6.2)
plt.axis("off")
fig.savefig("amrex_flux.png", dpi=150, bbox_inches="tight")
print("figure -> amrex_flux.png", flush=True)
plt.show()
