from zoomy_core.numerics import NumericalSystemModel, ReconstructionSpec
from zoomy_core.systemmodel import SystemModel
from zoomy_core.systemmodel.operations import desingularize_hinv
from zoomy_core.transformation.to_amrex import AmrexModel

sm = SystemModel.from_model(model)
display(sm.describe())

sm.apply(desingularize_hinv())
nsm = NumericalSystemModel.from_system_model(
    sm, reconstruction=ReconstructionSpec(order=1), depth_regularization="none")
display(nsm.describe())

code = AmrexModel(nsm).create_code()
open("model_amrex.H", "w").write(code)
print(code)
