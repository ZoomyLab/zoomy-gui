"""Zoomy pipeline, example 3 of 3 -- GUI folder-case ``run.py``.

From the model to AMReX source, in three moves.

  1. ``SystemModel.from_model`` freezes the operators.
  2. ``NumericalSystemModel.from_system_model`` takes over everything that is a
     numerical decision rather than a modelling one. Here that is the
     desingularisation of 1/h into a regularised auxiliary symbol, and the
     choice of the reconstruction and the Riemann solver. Both are attached to
     the numerical system model, so no backend has to implement them.
  3. The printer translates the frozen operators into backend syntax. It is
     syntax only. The equations were fixed two steps earlier and the printer
     does not change them.

The emitted header is written next to the case as ``model_amrex.H``.
"""
import os

from zoomy_core.numerics import NumericalSystemModel, ReconstructionSpec
from zoomy_core.systemmodel import SystemModel
from zoomy_core.systemmodel.operations import desingularize_hinv
from zoomy_core.transformation.to_amrex import AmrexModel

try:
    build_model  # noqa: B018
except NameError:
    from model import build_model

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())

bundle = globals().get("bundle") or build_model()
m = bundle["model"]

# ---- 1. model -> system model ---------------------------------------------
sm = SystemModel.from_model(m)
print("\nsystem model state :", [str(s) for s in sm.state], flush=True)
print("flux               :", sm.flux, flush=True)

# ---- 2. system model -> numerical system model -----------------------------
sm.apply(desingularize_hinv())
nsm = NumericalSystemModel.from_system_model(
    sm, reconstruction=ReconstructionSpec(order=1),
    depth_regularization="none")
print("aux after desingularize_hinv:", [str(s) for s in sm.aux_state],
      flush=True)
print("Riemann solver     :", type(nsm.build_numerics()).__name__, flush=True)

# ---- 3. code printing ------------------------------------------------------
if nsm.position is None:
    nsm.position = nsm._position_struct()
code = AmrexModel(nsm).create_code()
path = os.path.join(CASE_DIR, "model_amrex.H")
with open(path, "w") as f:
    f.write(code)
lines = code.splitlines()
print(f"\nAMReX header: {len(lines)} lines -> model_amrex.H", flush=True)

# The flux kernel is the piece worth reading: Qaux(0) is the regularised 1/h
# and Q(2) is the discharge, so the second row is the advective flux and the
# hydrostatic pressure the model tagged for the separate slot.
start = next(i for i, line in enumerate(lines) if "flux_x" in line)
excerpt = "\n".join(lines[start:start + 20])
print("\n===== the printed flux kernel =====", flush=True)
print(excerpt, flush=True)
with open(os.path.join(CASE_DIR, "flux_excerpt.txt"), "w") as f:
    f.write(excerpt + "\n")
print("\nartifact -> model_amrex.H, flux_excerpt.txt", flush=True)
