"""Zoomy pipeline, example 3 of 3 -- GUI folder-case ``mesh.py``.

Code printing turns the frozen operators into backend source. No grid is
involved, so this card exists only to keep the four-card shape of a session.
"""
from zoomy_core.mesh import BaseMesh


def build_mesh(settings=None, case_dir=None):
    return BaseMesh.create_1d(domain=(0.0, 1.0), n_inner_cells=10)


mesh = build_mesh()
print("mesh: not used, this example is symbolic")
