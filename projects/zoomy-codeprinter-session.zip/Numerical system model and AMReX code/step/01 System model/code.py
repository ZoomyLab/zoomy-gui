from zoomy_core.systemmodel import SystemModel
from zoomy_core.systemmodel.operations import symbolic_spectrum

sm = SystemModel.from_model(model, Q=[b, h, q0]).apply(symbolic_spectrum())
