from zoomy_core.transformation.to_amrex import AmrexModel

code = AmrexModel(nsm).create_code()
open("model_amrex.H", "w").write(code)
print(code)
