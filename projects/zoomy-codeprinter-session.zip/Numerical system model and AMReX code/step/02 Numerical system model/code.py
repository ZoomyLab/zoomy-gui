from zoomy_core.numerics import NumericalSystemModel, ReconstructionSpec
from zoomy_core.systemmodel.operations import desingularize_hinv

sm.apply(desingularize_hinv())
nsm = NumericalSystemModel.from_system_model(
    sm, reconstruction=ReconstructionSpec(order=1), depth_regularization="none")
nsm.describe()
