"""sme_vof — GUI folder-case `model.py`: the SME participant's model with
IC/BC baked, emitted to the zoomy_foam build tree.

This case's PDE side is the SME(level) hierarchy with the Newtonian +
NavierSlip + StressFree closure set and the coupling boundary pair
(outer wall | preCICE-coupled interface) — exactly what
`library/zoomy_foam/create_model.py --bcs coupling --closure newtonian`
bakes.  The VOF participant is stock OpenFOAM `incompressibleVoF`
(no emission).  Compile after emission: `bash compile.sh <level>`.

Usage: model.py [--level N] [--out DIR]   (defaults from settings.json)
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

import os
HERE = (Path(__file__).resolve().parent
        if "__file__" in globals() else Path(os.getcwd()))
FOAM_ROOT = Path("/Users/adam-obbpb5az1dhsjzf/git/Zoomy/library/zoomy_foam")
_SJ = HERE / "settings.json"
#: embedded copy of the case settings; a sibling settings.json is used only
#: when it is the CASE file ("level" key) — the GUI writes a generic one.
SETTINGS = (json.loads(_SJ.read_text()) if _SJ.exists() else {})
if "level" not in SETTINGS:
    SETTINGS = {'name': 'sme_vof_triple',
 'title': 'SME(level) | VOF | SME(level) three-participant coupled dam break '
          '(preCICE)',
 'level': 1,
 'window': 0.002,
 'scheme': 'parallel-explicit',
 'ghost': 'characteristic',
 'outer': 'wall',
 'frozen': 'auto',
 'ledger': 20,
 'closure': 'newtonian',
 'nu': 0.005,
 'lambda_s': 0.1,
 'notes': 'triple sibling of sme_vof: SME|VOF|SME closed box '
          '(coupling-scheme:multi, MODE=triple in generate.py driven by '
          'run.sh). Same production coupling scheme as the pair '
          '(characteristic ghost + qstarMode=rp mass row). run.py routes '
          'run.sh (three participants: swe_case, swe2_case, vof_case); '
          'outputs replayed by visualize.py.'}


def emit(level, out):
    cmd = [sys.executable, str(FOAM_ROOT / "create_model.py"),
           "--level", str(level),
           "--closure", SETTINGS["closure"],
           "--bcs", "coupling",
           "--outer", SETTINGS["outer"],
           "--out", str(out)]
    print("+", " ".join(cmd))
    subprocess.run(cmd, check=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--level", type=int, default=SETTINGS["level"])
    ap.add_argument("--out", type=Path, default=FOAM_ROOT)
    a = ap.parse_args()
    emit(a.level, a.out)
