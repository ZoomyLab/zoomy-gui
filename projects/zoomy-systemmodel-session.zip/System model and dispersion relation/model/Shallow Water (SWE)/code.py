from zoomy_core.model.models import SWE

model = SWE(dimension=1)
model.describe()
