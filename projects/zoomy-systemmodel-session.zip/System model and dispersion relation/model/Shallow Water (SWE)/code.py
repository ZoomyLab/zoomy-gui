from zoomy_core.model.models.swe import SWE


def build_model(settings=None, mesh=None, case_dir=None):
    m = SWE(dimension=1)
    print("model     :", type(m).__name__, flush=True)
    print("state     :", [str(v) for v in m.variables.get_list()], flush=True)
    print("aux state :", [str(v) for v in m.aux_variables.get_list()], flush=True)
    return {"model": m}


bundle = build_model()
