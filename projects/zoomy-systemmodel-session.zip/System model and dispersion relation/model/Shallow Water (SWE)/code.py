import sympy as sp

from zoomy_core import coords as C
import zoomy_core.derivatives as d
from zoomy_core.model.derivation import (
    Model, PDETransformation, Simplify, ResolveIntegral,
    Consolidate, InvertMassMatrix, ChangeOfVariables, FoldConservative)
from zoomy_core.model.derivation.projection import Integrate
from zoomy_core.model.derivation.system_extract import HydrostaticPressure
from zoomy_core.model.operations import Multiply, ProductRule, KinematicBC
from zoomy_core.model.operations import Integrate as IntegrateZ
from zoomy_core.model.models.equations import Mass, Momentum, moment_scaling

t, x, z = C.t, C.x, C.z
zeta = sp.Symbol("zeta", real=True)

model = Model(coords=(t, x, z), parameters={"g": 9.81, "rho": 1.0})
g = model.parameters.g
h = sp.Function("h", positive=True)(t, x)
b = sp.Function("b", real=True)(t, x)

model.declare_state(h)
model.add_equation("bottom", d.t(b))
model.add_equation(Mass(model))
momentum = Momentum(model)
model.add_equation(momentum)
moment_scaling(model, momentum)
u, w, p = momentum.uvel[0], momentum.w, momentum.p
model.move_to_aux(b)
model.add_equation("kbc_top", KinematicBC(w=w, u=u, interface=b + h))
model.add_equation("kbc_bot", KinematicBC(w=w, u=u, interface=b))

model.apply({model.functions.tau_xz.expr: 0})

mz = model.momentum.z
mz.apply({d.t(w): 0, d.z(w * w): 0, d.x(u * w): 0})
mz.apply(IntegrateZ(z, z, b + h, method="analytical"))
mz.apply({p.subs(z, b + h): 0})
pressure = mz.solve_for(p)
model.momentum.x.apply(pressure)
mz.remove()
model.momentum.x.apply(Simplify())

model.apply(PDETransformation({z: (zeta, sp.Eq(z, b + h * zeta))}))

ubar = sp.Function(r"\bar{u}", real=True)(t, x)
utilde = model.functions.u.head
for eq in model._equations.values():
    eq.expr = eq.expr.replace(utilde, lambda *a: ubar)
for a in model._assumptions.values():
    a._as_relation = {k.replace(utilde, lambda *aa: ubar):
                      v.replace(utilde, lambda *aa: ubar)
                      for k, v in a._as_relation.items()}
model.redeclare_unknown(utilde, ubar, rename_key=True)

for e in (model.mass, model.momentum.x):
    e.apply(Multiply(h))
    e.apply(ProductRule(variables=[zeta]))
    e.apply(Integrate(zeta, bounds=(0, 1)))
    e.apply(ResolveIntegral())
    e.apply(model.kbc_bot)
    e.apply(model.kbc_top)
    e.apply({sp.Derivative(b, t): 0})
    e.apply(Simplify())

h_eq = model.mass.solve_for(sp.Derivative(h, t))
model.momentum.x.apply(h_eq)
model.momentum.x.apply(Consolidate())
model.apply(ChangeOfVariables(r"\bar{u}", "q_0", lambda q: q / h))
model.apply(InvertMassMatrix())
q0 = sp.Function("q_0", real=True)(t, x)
model.momentum.x.apply(FoldConservative([q0], h=h, b=b, x=x, gravity=g))

P_hydro = g * h**2 / 2
model.momentum.x.expr = model.momentum.x.expr.replace(
    lambda e: isinstance(e, sp.Derivative) and e.args[0] == P_hydro,
    lambda e: sp.Derivative(HydrostaticPressure(P_hydro), *e.args[1:],
                            evaluate=False))
