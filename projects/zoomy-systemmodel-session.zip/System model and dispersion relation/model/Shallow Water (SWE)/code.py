"""Zoomy pipeline, example 2 of 3 -- GUI folder-case ``model.py``.

The shallow water equations as a shipped model. Example 1 of this set derives
them from the general balances step by step. Here we start from the finished
model, because what is on show is the next stage of the pipeline: freezing a
model into a system model, and what the system model can then answer.
"""
from zoomy_core.model.models.swe import SWE


def build_model(settings=None, mesh=None, case_dir=None):
    m = SWE(dimension=1)
    print("model     :", type(m).__name__, flush=True)
    print("state     :", [str(v) for v in m.variables.get_list()], flush=True)
    print("aux state :", [str(v) for v in m.aux_variables.get_list()], flush=True)
    return {"model": m}


bundle = build_model()
