"""Zoomy pipeline, example 2 of 3 -- GUI folder-case ``visualize.py``.

The two dispersion branches, and the phase speed they imply. Both branches are
straight through the origin and both phase speeds are flat, which is the
statement that the shallow water equations carry no dispersion.
"""
import numpy as np
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt

try:
    from zoomy_plotting.plot import style as zstyle
    zstyle.use("thesis")
except Exception:
    mpl.rcParams.update({"font.size": 9, "font.family": "serif",
                         "figure.dpi": 130, "savefig.dpi": 130})

d = np.load("dispersion.npz", allow_pickle=True)
k, omega = d["k"], d["omega"]
h0, u0, g = float(d["h0"]), float(d["u0"]), float(d["g"])
c_ref = (u0 + (g * h0) ** 0.5, u0 - (g * h0) ** 0.5)

fig, (a0, a1) = plt.subplots(1, 2, figsize=(7.0, 2.6))
for i, w in enumerate(omega):
    a0.plot(k, w, lw=1.4, marker="", label=f"branch {i + 1}")
a0.set_xlabel("$k_x$ [m$^{-1}$]")
a0.set_ylabel(r"$\omega$ [s$^{-1}$]")
a0.set_title("(a) dispersion relation")

with np.errstate(divide="ignore", invalid="ignore"):
    c = np.where(k > 0, omega / np.where(k > 0, k, 1.0), np.nan)
for i, ci in enumerate(c):
    a1.plot(k, ci, lw=1.4, marker="", label=f"branch {i + 1}")
for cr in c_ref:
    a1.axhline(cr, color="0.4", lw=0.8, ls=":")
a1.set_xlabel("$k_x$ [m$^{-1}$]")
a1.set_ylabel(r"$\omega / k_x$ [m s$^{-1}$]")
a1.set_title("(b) phase speed")

for a in (a0, a1):
    a.grid(True, alpha=0.3)
    a.legend(frameon=False)
fig.suptitle(rf"$h_0 = {h0:g}$ m, $u_0 = {u0:g}$ m s$^{{-1}}$, "
             rf"dotted: $u_0 \pm \sqrt{{g h_0}}$", y=1.04, fontsize=9)
fig.tight_layout()
fig.savefig("dispersion.png", dpi=150, bbox_inches="tight")
print("figure -> dispersion.png", flush=True)
plt.show()
