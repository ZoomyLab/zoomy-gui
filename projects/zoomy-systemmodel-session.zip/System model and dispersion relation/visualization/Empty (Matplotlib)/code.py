import numpy as np
import sympy as sp
import matplotlib.pyplot as plt
import zoomy_plotting as zp

values = {h0: 1.0, u0: 0.5, model.parameters.g: 9.81}
k = np.linspace(0.0, 20.0, 201)
k_x = next(s for s in omega[0].free_symbols if s.name == "k_x")

with zp.apply_style():
    fig, (ax_w, ax_c) = plt.subplots(1, 2, figsize=(7.0, 2.6))
    for i, w in enumerate(omega):
        w_k = sp.lambdify(k_x, w.subs(values), "numpy")(k)
        ax_w.plot(k, w_k, marker="None", label=f"branch {i + 1}")
        ax_c.plot(k[1:], w_k[1:] / k[1:], marker="None", label=f"branch {i + 1}")
    ax_w.set(xlabel="$k_x$ [m$^{-1}$]", ylabel=r"$\omega$ [s$^{-1}$]", title="(a) dispersion relation")
    ax_c.set(xlabel="$k_x$ [m$^{-1}$]", ylabel=r"$\omega / k_x$ [m s$^{-1}$]", title="(b) phase speed")
    zp.figure_legend(fig)
fig
