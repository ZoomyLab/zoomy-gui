import numpy as np
import sympy as sp

from zoomy_core.model.analysis import ModelAnalyser
from zoomy_core.systemmodel import SystemModel

try:
    build_model
except NameError:
    from model import build_model

bundle = globals().get("bundle") or build_model()
m = bundle["model"]


sm = SystemModel.from_model(m)
print("\n===== the system model =====", flush=True)
print("state      :", [str(s) for s in sm.state], flush=True)
print("aux state  :", [str(s) for s in sm.aux_state], flush=True)
print("flux       :", sm.flux, flush=True)
print("eigenvalues:", sm.eigenvalues, flush=True)


an = ModelAnalyser(m)
eps = an.get_eps()
h0 = sp.Symbol("h_0", positive=True)
u0 = sp.Symbol("u_0", real=True)
fh, fq = an.create_functions_from_list(["h", "q"])


q = sp.Matrix([sp.Integer(0), h0 + eps * fh, h0 * u0 + eps * fq])
lin = an.linearize_system(q, sp.zeros(0, 1))
print("\n===== linearised about the uniform state =====", flush=True)
for i, e in enumerate(lin):
    print(f"  row {i}: {e}", flush=True)


an.delete_equations([i for i, e in enumerate(lin) if e is sp.true])
an.insert_plane_wave_ansatz([fh, fq])
an.remove_exponential()
branches = an.solve_for_dispersion_relation()
print("\n===== dispersion relation =====", flush=True)
for w in branches:
    print("  omega =", sp.simplify(w), flush=True)


H0, U0, G = 1.0, 0.5, 9.81
VALUES = {"h_0": H0, "u_0": U0, "g": G}


def by_name(expr, values):
    return expr.subs({sym: values[sym.name] for sym in expr.free_symbols
                      if sym.name in values})


k = np.linspace(0.0, 20.0, 201)
omega = np.empty((len(branches), len(k)))
for i, w in enumerate(branches):
    fixed = by_name(sp.simplify(w), VALUES)
    kx = next(sym for sym in fixed.free_symbols if sym.name == "k_x")
    f = sp.lambdify(kx, sp.re(fixed), "numpy")
    omega[i] = np.asarray(f(k), dtype=float)
np.savez("dispersion.npz", k=k, omega=omega, h0=H0, u0=U0, g=G,
         labels=np.array([sp.srepr(w) for w in branches], dtype=object),
         pretty=np.array([str(sp.simplify(w)) for w in branches], dtype=object))
print("\nartifact -> dispersion.npz", flush=True)
print(f"reference speeds: u_0 +- sqrt(g h_0) = "
      f"{U0 + (G * H0) ** 0.5:.4f} and {U0 - (G * H0) ** 0.5:.4f} m/s",
      flush=True)
