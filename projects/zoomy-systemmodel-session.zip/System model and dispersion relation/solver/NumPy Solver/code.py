import sympy as sp

from zoomy_core.model.analysis import ModelAnalyser
from zoomy_core.systemmodel import SystemModel

sm = SystemModel.from_model(model)
display(sm.describe())

analyser = ModelAnalyser(model)
eps = analyser.get_eps()
h0, u0 = sp.Symbol("h_0", positive=True), sp.Symbol("u_0", real=True)
fh, fq = analyser.create_functions_from_list(["h", "q"])
linear = analyser.linearize_system(
    sp.Matrix([0, h0 + eps * fh, h0 * u0 + eps * fq]), sp.zeros(0, 1))
analyser.delete_equations([i for i, e in enumerate(linear) if e is sp.true])
analyser.insert_plane_wave_ansatz([fh, fq])
analyser.remove_exponential()
omega = [sp.simplify(w) for w in analyser.solve_for_dispersion_relation()]
for w in omega:
    display(sp.Eq(sp.Symbol("omega"), w))
