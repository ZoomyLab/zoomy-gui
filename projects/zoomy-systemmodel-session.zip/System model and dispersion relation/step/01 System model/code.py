from zoomy_core.systemmodel import SystemModel

sm = SystemModel.from_model(model, Q=[b, h, q0])
sm.describe()
