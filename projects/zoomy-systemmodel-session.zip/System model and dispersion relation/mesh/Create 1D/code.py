"""Zoomy pipeline, example 2 of 3 -- GUI folder-case ``mesh.py``.

The dispersion relation is a property of the equations, not of a grid, so this
card exists only to keep the four-card shape of a session. The wavenumbers the
visualization sweeps are set in the solver card.
"""
from zoomy_core.mesh import BaseMesh


def build_mesh(settings=None, case_dir=None):
    return BaseMesh.create_1d(domain=(0.0, 1.0), n_inner_cells=10)


mesh = build_mesh()
print("mesh: not used, this example is symbolic")
