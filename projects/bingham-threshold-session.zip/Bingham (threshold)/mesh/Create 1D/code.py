"""Bingham threshold sweep (numpy) — GUI folder-case ``mesh.py``.

The Liu & Mei (1994) linear-roll-wave threshold study runs on a LONG, OPEN
incline (not the single periodic wavelength of ``../transient``): a train of
long waves is seeded and its amplitude is tracked as it advects downstream.
The geometry is a plain 1-D interval ``(0, xmax)`` with ``n_inner_cells`` cells;
the incline itself is carried by the sloped bed + linear-bed ``Lambda`` ghosts
(see ``model.py``), so this module owns only the 1-D interval, sized from
``settings['mesh']``.
"""

import os

from zoomy_core.mesh import BaseMesh

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
             if "__file__" in globals() else os.getcwd())


def build_mesh(settings, case_dir=None):
    """Build the open 1-D incline mesh sized from ``settings['mesh']``."""
    mcfg = settings["mesh"]
    xmax = float(mcfg["xmax"])
    nc = int(mcfg["n_inner_cells"])
    return BaseMesh.create_1d(domain=(0.0, xmax), n_inner_cells=nc)
