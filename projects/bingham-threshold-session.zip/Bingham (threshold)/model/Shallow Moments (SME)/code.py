"""Bingham threshold sweep (numpy) — GUI folder-case ``model.py``.

The Liu & Mei (1994) linear roll-wave THRESHOLD study: a uniform Bingham film
down an incline is linearly unstable when the Reynolds-like parameter

    beta = rho^2 g sin(theta) H^3 tan(theta) / mu^2

exceeds the momentum-integral threshold (Liu & Mei, Phys. Fluids 6 (1994),
Eq. 47)

    beta_c(alpha) = 12 (1 + alpha + alpha^2)
                    / [(1 - alpha)^2 (4 + 9 alpha + 15 alpha^2 + 8 alpha^3)],

with alpha = tau_y / (rho g H sin(theta)) the yield/plug parameter.  For
alpha = 1/2, beta_c = 6.34; long waves then grow into a roll-wave train.

Unlike ``../transient`` (single periodic wavelength + ``e_x`` body force + the
case-local Herschel-Bulkley closure), the threshold study is the exact setup of
``../bingham_rollwaves.py``: the incline is carried by a SLOPED BED with linear
``Lambda`` ghosts, the film is the CORE ``Bingham`` bulk closure (n = 1), and a
long-wave sinusoidal seed advects down an OPEN domain.  ``beta`` is swept by
``run.py`` (three back-to-back solves) and injected into ``build_model``; every
other number is driven by ``settings.json``.

Exposes ``build_model(settings, mesh, beta)``, ``build_ic(...)``,
``build_bc(...)``, ``scales(...)`` mirroring ``../transient/model.py``.
"""

import os

import numpy as np
import numpy.polynomial.legendre as npleg

import zoomy_core.model.initial_conditions as IC
from zoomy_core.model.models import SME
from zoomy_core.model.models.closures import Bingham, NavierSlip, StressFree
from zoomy_core.model.boundary_conditions import BoundaryConditions, Lambda
from zoomy_core.systemmodel import SystemModel
from zoomy_core.numerics import NumericalSystemModel, ReconstructionSpec

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
             if "__file__" in globals() else os.getcwd())


def liu_mei_beta_c(alpha):
    """Liu & Mei (1994) Eq. 47 momentum-integral threshold beta_c(alpha)."""
    return 12.0 * (1 + alpha + alpha**2) / (
        (1 - alpha) ** 2 * (4 + 9 * alpha + 15 * alpha**2 + 8 * alpha**3))


def scales(settings, beta):
    """Liu & Mei physical constants + the derived scales for one ``beta``.

    Returns a dict with the viscosity ``nu`` (set BY beta), yield stress
    ``tau_y``, regularization ``eps_reg``, the kinematic wave speed ``c_kin``
    and the slope ``s`` / depth ``H0`` — the single source of the parameter
    algebra used by the IC, the timestep cap, and the transit-window
    growth-rate fit.
    """
    m = settings["model"]
    g, s, h0 = m["g"], m["s"], m["H0"]
    alpha = settings["sweep"]["alpha"]
    lam_s = m["lambda_s"]
    a = g * s                                          # gravity along the slope
    tau_y = alpha * a * h0
    # beta = g s^2 H^3 / nu^2  (rho = 1, mu = rho nu, tan ~ sin ~ s)
    nu = float(np.sqrt(g * s**2 * h0**3 / beta))
    gd_scale = a * (h0 - tau_y / a) / nu               # characteristic bed shear rate
    eps_reg = 0.05 * gd_scale                          # ~5 % of bed shear rate
    c_kin = (1 - alpha) * a * h0**2 / nu               # kinematic wave speed
    return dict(g=g, s=s, h0=h0, a=a, alpha=alpha, beta=beta, tau_y=tau_y,
                nu=nu, lam_s=lam_s, eps_reg=eps_reg, c_kin=c_kin)


def _analytic_profile(zeta, sc):
    """Liu & Mei steady base velocity u(zeta) (slip + plug-over-parabola)."""
    h0, a, nu, lam_s, tau_y = sc["h0"], sc["a"], sc["nu"], sc["lam_s"], sc["tau_y"]
    zc = h0 - tau_y / a
    u_slip = a * h0 / lam_s
    zz = zeta * h0
    return u_slip + (a / nu) * np.where(zz <= zc, zc * zz - zz**2 / 2, zc**2 / 2)


def _modal_base(level, sc):
    """Legendre-moment coefficients q_i of the steady base profile."""
    zf = np.linspace(0, 1, 400)
    u = _analytic_profile(zf, sc)
    qs = []
    for i in range(level + 1):
        c = np.zeros(i + 1); c[i] = 1.0
        qs.append((2 * i + 1) * sc["h0"]
                  * np.trapezoid(u * npleg.legval(2 * zf - 1, c), zf))
    return qs


def build_bc(settings):
    """Linear-bed ``Lambda`` ghosts carrying the constant incline slope out of
    both open ends (bed elevation extrapolated as ``b - s * 2 dX * n_x``)."""
    s = settings["model"]["s"]

    def _bed_ghost(t_, X_, dX_, Q_, Aux_, p_, n_):
        return Q_[0] - s * 2.0 * dX_ * n_[0]

    return BoundaryConditions([
        Lambda(tag="left", prescribe_fields={0: _bed_ghost}),
        Lambda(tag="right", prescribe_fields={0: _bed_ghost})])


def build_ic(settings, sm, sc):
    """IC = steady base moments * (1 + seed*sin(2 pi x / lambda_seed)) on a bed
    that descends at the constant slope ``s`` (b = -s x)."""
    m, icfg = settings["model"], settings["ic"]
    level = m["level"]
    s, h0 = m["s"], sc["h0"]
    seed = icfg["seed_amplitude"]
    lam_seed = icfg["seed_wavelength"]
    names = [str(s_) for s_ in sm.state]
    qs0 = _modal_base(level, sc)

    def ic(xv):
        xx = float(xv[0])
        out = np.zeros(len(names))
        bump = 1.0 + seed * np.sin(2 * np.pi * xx / lam_seed)
        out[0] = -s * xx                               # sloped bed = the incline
        out[1] = h0 * bump
        for i in range(level + 1):
            out[2 + i] = qs0[i] * bump
        return out
    return ic


def dt_cap(settings, sc):
    """Explicit source-stiffness timestep cap (bulk + bed-slip), the canonical
    ``bingham_rollwaves.py`` stability bound."""
    m, num = settings["model"], settings["numerics"]
    level, h0, lam_s = m["level"], sc["h0"], sc["lam_s"]
    nu_eff = sc["nu"] + sc["tau_y"] / sc["eps_reg"]
    rate_bulk = (2 * level + 1) * nu_eff * 12.0 / h0**2
    rate_slip = (level + 1) ** 2 * lam_s / h0
    return num.get("dt_cap_safety", 0.4) / max(rate_bulk, rate_slip)


def build_model(settings, mesh, beta, case_dir=None):
    """Build the SME(level) + core ``Bingham`` NSM for one ``beta``, IC/BC baked.

    Returns ``{nsm, sm, sc, dt_cap, names}``: ``sc`` (the Liu & Mei scales for
    this beta) and ``dt_cap`` are what ``run.py`` needs to set the adaptive-dt
    bound and the transit-window growth-rate fit.
    """
    m, num = settings["model"], settings["numerics"]
    sc = scales(settings, beta)

    par = {"nu": sc["nu"], "lambda_s": sc["lam_s"], "tau_y": sc["tau_y"],
           "eps_reg": sc["eps_reg"]}

    # Model -> SystemModel via the single REQ-143 entry point
    # (SystemModel.from_model); the old ``.system_model`` accessor was removed.
    model = SME(level=m["level"], quadrature_order=m.get("quadrature_order", 12),
                closures=[Bingham(), NavierSlip(), StressFree()],
                parameters=par, boundary_conditions=build_bc(settings))
    sm = SystemModel.from_model(model)

    sm.initial_conditions = IC.UserFunction(function=build_ic(settings, sm, sc))
    sm.aux_initial_conditions = IC.Constant(constants=lambda n: np.zeros(n))

    nsm = NumericalSystemModel.from_system_model(
        sm, reconstruction=ReconstructionSpec(order=num.get("order", 1)))
    return {"nsm": nsm, "sm": sm, "sc": sc, "dt_cap": dt_cap(settings, sc),
            "names": [str(s_) for s_ in sm.state]}
