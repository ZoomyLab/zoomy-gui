"""Bingham threshold sweep (numpy) — GUI folder-case ``visualize.py``.

Renders the MEASURED linear-threshold deliverable from
``output/bingham_threshold.npz`` (parity with ``../make_figures.py`` fig 2,
``fig_threshold``), as a two-panel figure:

  (a) crest-amplitude history ``max|h - H0|(t)`` for beta = 3 / 6.35 / 12, each
      labeled by its transit-window growth rate and STABLE/MARGINAL/UNSTABLE
      verdict;
  (b) the measured growth rate vs beta with the rate = 0 neutral line and the
      analytic Liu & Mei threshold ``beta_c(alpha=0.5) = 6.34`` reference line
      — the three points bracket the threshold, reproducing the verdicts.

Growth rates are re-fitted here from the amplitude series (self-contained),
so the figure stands on the npz alone.  Writes
``output/fig_bingham_threshold_measured.png``.  Standalone: ``python visualize.py``.
"""

import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from zoomy_core.postprocessing import style

style.use("print")                          # publication profile (serif, Okabe-Ito)

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
             if "__file__" in globals() else os.getcwd())
VCOL = {"STABLE": style.CYCLE[0], "MARGINAL": style.CYCLE[1],
        "UNSTABLE": style.CYCLE[2]}
REF_C = "black"


def _fit_rate(times, amp, c_kin, xmax):
    """Transit-window log-amplitude slope (1/s); matches ``run.growth_rate``."""
    t_exit = 0.8 * xmax / c_kin
    mask = (times > 5.0) & (times < t_exit)
    if mask.sum() < 2:
        mask = times > 0.0
    return float(np.polyfit(times[mask], np.log(amp[mask] + 1e-12), 1)[0]), t_exit


def _verdict(beta, beta_c, rate, growth_tol, band):
    """Threshold bracket confirmed by the measured rate (see run.verdict)."""
    if rate > growth_tol:
        return "UNSTABLE"
    if abs(beta - beta_c) <= band * beta_c:
        return "MARGINAL"
    return "STABLE" if beta < beta_c else "UNSTABLE"


def visualize(src=None):
    src = src or os.path.join(CASE_DIR, "output")
    d = np.load(os.path.join(src, "bingham_threshold.npz"), allow_pickle=True)
    t = d["times"]
    betas = d["betas"]
    alpha, beta_c = float(d["alpha"]), float(d["beta_c"])
    g, s, h0 = float(d["g"]), float(d["s"]), float(d["H0"])
    xmax = float(d["xmax"])
    growth_tol = float(d["growth_tol"]) if "growth_tol" in d.files else 0.005
    band = float(d["marginal_band"]) if "marginal_band" in d.files else 0.15

    fig, (axA, axB) = plt.subplots(1, 2, figsize=(11.0, 4.6))

    rates, vds = [], []
    for i, beta in enumerate(betas):
        amp = d[f"amp_{i}"]
        nu = float(np.sqrt(g * s**2 * h0**3 / beta))
        c_kin = (1 - alpha) * g * s * h0**2 / nu
        rate, t_exit = _fit_rate(t[:len(amp)], amp, c_kin, xmax)
        vd = _verdict(beta, beta_c, rate, growth_tol, band)
        rates.append(rate); vds.append(vd)
        c = VCOL[vd]
        axA.semilogy(t[:len(amp)], amp, color=c, lw=2.0, marker="",
                     label=rf"$\beta={beta:g}$ [{vd}]: {rate:+.3f} 1/s")
        print(f"threshold beta={beta:<6}: rate {rate:+.4f} 1/s -> {vd}")
    axA.set(xlabel=r"$t$ [s]", ylabel=r"$\max|h-H_0|$")
    axA.set_title(rf"(a) crest-amplitude history ($\alpha={alpha:g}$)")
    axA.grid(alpha=0.3)
    axA.legend(fontsize=8, loc="best")

    # (b) measured growth rate vs beta: rate=0 neutral line, the analytic Liu&Mei
    # threshold beta_c and the marginal beta-band around it — the three measured
    # points bracket beta_c (rate crosses zero between the marginal and unstable
    # runs), reproducing the verdicts.
    rates = np.array(rates)
    axB.axvspan(beta_c * (1 - band), beta_c * (1 + band),
                color=VCOL["MARGINAL"], alpha=0.12,
                label=rf"marginal band ($\pm{band:g}\,\beta_c$)")
    axB.axhline(0.0, color="0.6", lw=1.0, ls="-")
    axB.axhline(growth_tol, color="0.6", lw=0.8, ls=":")
    axB.axvline(beta_c, color=REF_C, ls="--", lw=1.6,
                label=rf"Liu&Mei $\beta_c({alpha:g})={beta_c:.2f}$")
    axB.plot(betas, rates, color="0.5", lw=1.0, ls=":", zorder=1)
    for beta, rate, vd in zip(betas, rates, vds):
        axB.plot(beta, rate, "o", ms=11, color=VCOL[vd], zorder=5)
        axB.annotate(vd, (beta, rate), textcoords="offset points",
                     xytext=(0, 11 if rate >= 0 else -17), ha="center",
                     fontsize=8, color=VCOL[vd])
    axB.set(xlabel=r"$\beta$", ylabel=r"growth rate [1/s]")
    axB.set_title(r"(b) measured rate vs $\beta$ brackets $\beta_c$")
    axB.grid(alpha=0.3)
    axB.legend(fontsize=8, loc="best")

    fig.suptitle("Bingham roll waves — measured linear threshold "
                 rf"($\beta_c(\alpha{{=}}{alpha:g})={beta_c:.2f}$)")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    out = os.path.join(CASE_DIR, "output", "fig_bingham_threshold_measured.png")
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print("wrote", out)
    return out


visualize()
