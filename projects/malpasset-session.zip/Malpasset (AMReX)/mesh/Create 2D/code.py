"""Malpasset (AMReX backend) — GUI folder-case ``mesh.py`` (REQ-138).

AMReX is a *structured* (block-rectangular) framework, so the "mesh" the solver
consumes is the case-shipped real Malpasset triangular ``.msh``
(``geo_malpasset-small.msh``, ~2.6 MB, carries the ``B``/``H``/``U``/``V`` survey
node data): ``zoomy_amrex.solvers`` takes the axis-aligned bounding box of the
triangulation as the rectangular AMReX domain, and ``run_case`` rasterises the
node data (bathymetry + reservoir-full depth) onto the cell centres.

``settings['mesh']`` names the file (relative to the case dir), so the folder
case is self-contained.  The structured RESOLUTION lives in
``settings['numerics']['n_cells']`` (never in the ``.msh``).
"""

import os

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())


MESH_CATALOG = "https://zoomylab.github.io/meshes/meshes/"


def _ensure_mesh(fname, case_dir=None):
    """Case-shipped mesh if present, else fetch from the deployed catalog."""
    p = os.path.join(case_dir or CASE_DIR, fname)
    if not os.path.exists(p):
        import urllib.request
        print("mesh not found locally; fetching", MESH_CATALOG + fname, flush=True)
        urllib.request.urlretrieve(MESH_CATALOG + fname, p)
    return p


def build_mesh(settings, case_dir=None):
    """Return the absolute path to the case ``.msh`` named in ``settings['mesh']``.

    For AMReX the ``mesh`` argument handed to ``solver.solve(model, mesh, settings)``
    is this path — the solver derives the structured domain from its node bbox and
    rasterises the ``$NodeData`` IC."""
    case_dir = case_dir or CASE_DIR
    return _ensure_mesh(settings["mesh"], case_dir)
