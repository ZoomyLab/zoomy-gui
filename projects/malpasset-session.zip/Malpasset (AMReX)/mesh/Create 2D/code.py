"""Malpasset (AMReX backend) — GUI folder-case ``mesh.py``.

AMReX is a *structured* (block-rectangular) framework, so the "mesh" the run card
consumes is the case-shipped real Malpasset triangular ``.msh``
(``geo_malpasset-small.msh``, ~2.6 MB, carries the ``B``/``H``/``U``/``V`` survey
node data): the run card takes the axis-aligned bounding box of the triangulation
as the rectangular AMReX domain and rasterises the node data (bathymetry +
reservoir-full depth) onto the cell centres (``zoomy_amrex.malpasset``).

``settings['mesh']`` names the file (relative to the case dir), so the folder
case is self-contained.  The structured RESOLUTION lives in
``settings['numerics']['n_cells']`` (never in the ``.msh``).
"""

import os

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())


MESH_URL = 'https://raw.githubusercontent.com/ZoomyLab/data/f46bdde4d5c66c18e597afcfef8a9ffce171fd05/malpasset/'


def _ensure_mesh(fname, case_dir=None):
    """Case-shipped mesh if present, else fetch it from the Zoomy data repository."""
    p = os.path.join(case_dir or CASE_DIR, fname)
    if not os.path.exists(p):
        import urllib.request
        print("mesh not found locally; fetching", MESH_URL + fname, flush=True)
        urllib.request.urlretrieve(MESH_URL + fname, p)
    return p


def build_mesh(settings, case_dir=None):
    """Return the absolute path to the case ``.msh`` named in ``settings['mesh']``.

    For AMReX the ``mesh`` argument handed to ``solver.solve(model, mesh, settings)``
    is this path — the solver derives the structured domain from its node bbox and
    rasterises the ``$NodeData`` IC."""
    case_dir = case_dir or CASE_DIR
    return _ensure_mesh(settings["mesh"], case_dir)
