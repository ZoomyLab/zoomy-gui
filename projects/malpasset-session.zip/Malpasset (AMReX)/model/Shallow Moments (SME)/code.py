"""Malpasset (AMReX backend) — GUI folder-case ``model.py`` (REQ-138).

The model incl. BCs baked, driven by ``settings.json``.  The physics is the
canonical wet/dry SWE variant :class:`~zoomy_core.model.models.malpasset.MalpassetSWE`
(state ``[b, h, hu, hv]`` + aux ``[hinv]``); KP-desingularised ``hinv`` + gated
eigenvalues carry the wetting/drying, so the AMReX driver never floors ``h``.

The basin is closed by a reflective **Wall BC on every structured face** —
West=x-lo, East=x-hi, South=y-lo, North=y-hi.  The AmrCore driver dispatches the
model's same-named face BCs (no raster wall ring, no ``--malpasset`` flag): each
Wall mirrors ``h`` + bed and negates the normal momentum ``[hu, hv]``, giving
exactly zero mass flux at the wall face (mass conserved to machine precision on a
single level).

The **initial condition is data, not code** here: the reservoir bathymetry ``B``
and the reservoir-full depth ``H`` ride the case ``.msh`` as gmsh ``$NodeData``,
and ``zoomy_amrex.run_case`` rasterises them onto the structured grid (bed → state
comp 0, depth → state comp 1; momentum rows start at rest).  So this module only
supplies the model + its wall BCs; the mesh (``mesh.py``) carries the IC.
"""

from zoomy_core.model.boundary_conditions import BoundaryConditions, Wall
from zoomy_core.model.models.malpasset import MalpassetSWE

# SWE state layout [b, h, hu, hv] → the depth-averaged momentum [hu, hv] is one
# reflect group (indices 2, 3) on every wall face.
MOMENTUM_GROUP = [[2, 3]]

# Constructor knobs MalpassetSWE accepts (all optional; defaults = the deck).
_MODEL_KWARGS = ("g", "n", "nu", "eps")


def wall_bcs():
    """Reflective walls on every structured face (closed basin)."""
    return BoundaryConditions([
        Wall(tag="West",  momentum_field_indices=MOMENTUM_GROUP),
        Wall(tag="East",  momentum_field_indices=MOMENTUM_GROUP),
        Wall(tag="South", momentum_field_indices=MOMENTUM_GROUP),
        Wall(tag="North", momentum_field_indices=MOMENTUM_GROUP),
    ])


def build_model(settings=None):
    """Build the closed-basin :class:`MalpassetSWE` with wall BCs baked.

    ``settings['model']`` may override the physical parameters ``g / n / nu /
    eps``; anything absent falls back to the ``MalpassetSWE`` defaults (the deck:
    ``g=9.81``, Manning ``n=0.033``, ``nu=1.0``, ``eps=1e-2``)."""
    m = (settings or {}).get("model", {})
    kw = {k: m[k] for k in _MODEL_KWARGS if k in m}
    return MalpassetSWE(boundary_conditions=wall_bcs(), **kw)
