"""Malpasset (AMReX backend) — GUI folder-case ``run.py`` (REQ-138).

Reads ``settings.json``, builds the mesh (real ``.msh``) + model (wall BCs baked),
constructs the REAL AMReX engine — ``zoomy_amrex.solvers.HyperbolicSolver`` with
the exact deck kwargs (CFL, order, well-balanced) — does ONE continuous run, and
writes ``output/<name>.h5`` (the shared zoomy store).  The server executes this
file as-is in the AMReX backend container.

AMReX emits a ParaView VTK series (``output/simulation.pvd`` + ``.vtu``); the h5
store is obtained from the shared ``zoomy_prepost.vtk_to_hdf5`` on that VTK (the
same bridge numpy/jax/foam feed), so ``visualize.py`` reads one uniform store.
The final store is also copied to ``./simulation.h5`` (the standard artifact name).

Standalone: ``python run.py`` — run it in the AMReX backend container (needs
``zoomy_amrex`` + ``AMREX_HOME``; ``zoomy_amrex`` code-gens + compiles the driver
on demand).  Set ``ZOOMY_T_END`` to override ``t_end`` (smoke runs).
Reproduces ``thesis/cases/amrex/malpasset.py`` (the old-era single script).
"""

import json
import os
import shutil

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())


#: Full benchmark settings (the canonical case's settings.json), used whenever
#: the sibling settings.json is absent (notebook) or GUI-generic (no "numerics").
_CASE_SETTINGS = {'name': 'malpasset_amrex',
 'backend': 'amrex',
 'mesh': 'geo_malpasset-small.msh',
 'model': {'type': 'MalpassetSWE'},
 'numerics': {'order': 2,
              'cfl': 0.4,
              'well_balanced': True,
              'n_cells': [180, 96],
              'max_level': 0},
 'run': {'t_end': 100.0, 'snapshots': 10}}


def load_settings(path=None):
    p = path or os.path.join(CASE_DIR, "settings.json")
    s = json.load(open(p)) if os.path.exists(p) else {}
    if "numerics" not in s:                       # GUI-generic or missing
        gui = s or (globals().get("settings")
                    if isinstance(globals().get("settings"), dict) else None) or {}
        s = json.loads(json.dumps(_CASE_SETTINGS))
        if gui.get("time_end") is not None:       # GUI knob = t_end [s]
            s["run"] = dict(s["run"], t_end=float(gui["time_end"]))
    return s


def run(settings=None):
    """Build + solve from ``settings`` (dict or None → settings.json).  Returns
    the output ``.h5`` path."""
    if settings is None:
        settings = load_settings()
    name = settings.get("name", "malpasset_amrex")
    num, run_cfg = settings["numerics"], settings["run"]
    t_end = float(os.environ.get("ZOOMY_T_END", run_cfg["t_end"]))

    from zoomy_amrex.solvers import HyperbolicSolver
    # Case modules: defined by the Model/Mesh cells in notebook form;
    # imported from the sibling files in a materialized case folder.
    try:
        build_mesh, build_model  # noqa: B018  (probe the notebook namespace)
    except NameError:
        from mesh import build_mesh
        from model import build_model

    mesh_path = build_mesh(settings, CASE_DIR)     # .msh path (structured bbox + IC)
    model = build_model(settings)                  # MalpassetSWE + wall BCs

    out_dir = os.path.join(CASE_DIR, "output")
    solver = HyperbolicSolver(
        CFL=num.get("cfl", 0.4),
        order=num.get("order", 2),
        well_balanced=num.get("well_balanced", True))
    solver_settings = {
        "time_end": t_end,
        "mesh": {"n_cells": num.get("n_cells", [180, 96])},
        "max_level": num.get("max_level", 0),
        "output": {"directory": out_dir, "snapshots": run_cfg.get("snapshots", 10)},
    }

    print(f"[{name}] mesh={os.path.basename(mesh_path)} "
          f"n_cells={solver_settings['mesh']['n_cells']} "
          f"max_level={solver_settings['max_level']}; "
          f"solving t_end={t_end}s (CFL={solver.CFL}, order={solver.order}, "
          f"well_balanced={solver.well_balanced}) ...", flush=True)
    pvd = solver.solve(model, mesh_path, solver_settings)

    # VTK series → the shared zoomy store HDF5 (the GUI/viz bridge), then the
    # standard artifact name at the case root.
    from zoomy_prepost.vtk import vtk_to_hdf5
    h5 = os.path.join(out_dir, name + ".h5")
    vtk_to_hdf5(pvd, h5)
    shutil.copy2(h5, os.path.join(CASE_DIR, "simulation.h5"))
    print(f"[{name}] done -> {h5}  (+ {os.path.join(CASE_DIR, 'simulation.h5')})",
          flush=True)
    return h5


run()
