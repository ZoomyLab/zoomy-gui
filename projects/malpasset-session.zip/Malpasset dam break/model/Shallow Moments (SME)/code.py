"""Malpasset (jax backend) — GUI folder-case ``model.py`` (REQ-137).

The model incl. IC/BC baked, driven by ``settings.json``.  The physics model
itself lives once in :mod:`sme_malpasset_model` (``MalpassetSME``); this module
is the case's model+IC+BC BINDING — the single source of the momentum layout,
the mesh-point-data IC, and the wall BCs (``malpasset_sme_jax.py`` imports them
from here, so there is no second copy).

IC-from-mesh is carried in the ``.msh`` (B/H/U/V survey node data).  The read +
node→cell interpolation + field→state assembly is done ONCE by the core
generalisation :func:`zoomy_core.mesh.initial_conditions_from_mesh` (REQ-134);
this module only supplies the case-specific ``field_map`` (the B/H/U/V→state
recipe) and ships the mesh.  The old hand-rolled meshio+cKDTree reader is retired.
"""

import os

import numpy as np

import zoomy_core.model.initial_conditions as IC
from zoomy_core.mesh import initial_conditions_from_mesh
from zoomy_core.model.boundary_conditions import BoundaryConditions, Wall
from zoomy_core.numerics import NumericalSystemModel, ReconstructionSpec
from zoomy_core.fvm.riemann_solvers import (
    PositiveNonconservativeHLL, PositiveNonconservativeRusanov)

# sme_malpasset_model: inlined below (GUI card is self-contained)

# --- inlined case module: sme_malpasset_model.py ----------------
"""``MalpassetSME`` — the Malpasset model on the canonical, dimension-general
``SME`` (Shallow Moment Equations) from ``zoomy_core.model.models``.

Now that the official ``SME`` is dimension-agnostic (``dimension=2`` → 1-D
``[b, h, q_0, q_1, …]``; ``dimension=3`` → 2-D map ``[b, h, q_x_0, q_x_1,
q_y_0, q_y_1, …]``) and consumes **composable closures** (the old
``MaterialModel`` was deleted), this class is a thin wrapper:

  SME(level, dimension, closures=[Newtonian(), NavierSlip(), StressFree()])

plus the Malpasset-specific NUMERICS this case needs on the real wet/dry mesh:

  * a KP-desingularized ``hinv`` aux (``update_aux_variables``) so the raw
    ``1/h`` in the conservative flux stays finite at the shoreline,
  * the closed-form normal-projected HSWME eigenvalue spectrum,
  * a per-cell momentum cap (``update_variables``) — h never floored.

``level=0`` ≡ SWE.  Eigenvalues (Koellermeier & Rominger 2020, rotational
invariance): ``u_n = (Σ_d q_{d,0}·n_d)·hinv``, ``α₁ₙ = −(Σ_d q_{d,1}·n_d)·hinv``,
``λ ∈ {0, u_n∓√(g·h+α₁ₙ²), u_n + c_i·α₁ₙ (leggauss roots), u_n (tangential)}``.
"""

import numpy as np
import sympy as sp

from zoomy_core.model.models import SME
from zoomy_core.model.models.closures import (
    Closure, Newtonian, NavierSlip, StressFree, ElderViscosity, RoughWall,
    WallFunctionBed)
from zoomy_core.misc.misc import ZArray
from zoomy_core.systemmodel import SystemModel


def malpasset_closures():
    """Viscous Newtonian bulk + Navier-slip bed + stress-free surface — the
    composable closures replacing the deleted ``MaterialModel``.  ``nu`` and
    ``lambda_s`` are set via the model parameters (defaults below)."""
    return [Newtonian(), NavierSlip(), StressFree()]


def _zeta_p(s, cap=0.5):
    """Near-wall reference height ζ_p = z_p/h, CLAMPED to [·, cap].  Without the
    cap, a thin cell (h < z_p) gives ζ_p > 1, so ``velocity_at(ζ_p)`` EXTRAPOLATES
    the modal velocity profile far outside [0,1] (φ₁(ζ_p)=2ζ_p−1 grows without
    bound) → a garbage friction velocity and over-excited moments at the shoreline
    (seen as |α₁|/|u| p90~2, max~22 even when the run stays finite).  Cap < 1 keeps
    the reference a genuine near-bed height for any depth."""
    return sp.Min(s.par.z_p / s.depth, sp.Float(cap))


class WallFunctionElder(Closure):
    """Wall-function Elder eddy viscosity — the *moment-stable* turbulent bulk
    closure (case-local; the proper replacement for plain ``ElderViscosity``).

    Plain Elder ``ν_t = κ·u_star·h·ζ(1−ζ)`` makes the SME first moment RUN AWAY
    in deep water for two reasons, both fixed here:

    1. **u_⋆ is a constant parameter, decoupled from the bed law.** A constant
       ``u_star`` cannot track the flow, so the moment-damping it provides is an
       arbitrary number rather than the real bed stress (this is REQ-12 done
       case-side).  Here ``u_⋆`` is COMPUTED from the wall function, the SAME
       friction velocity the bed drag uses (pair with :class:`WallFunctionBed`)::

           C_f = (κ / ln(z_p/z_0))²,   z_0 = k_s/30,
           U_p = u(ζ_p),  ζ_p = z_p/h   (the near-wall reference velocity, NOT
                                         the bed trace u(0), which collapses in a
                                         truncated moment expansion),
           u_⋆ = √(C_f) |U_p|.

    2. **Plain Elder ν_t VANISHES at the wall (ζ=0).** The moment damping lives
       where the shear is — at the bed — so a ν_t that → 0 there cannot damp the
       growing first moment.  We add the offset log-layer mixing length
       ``ℓ = κ(z + z_p)`` (Nezu–Nakagawa), giving::

           ν_t = κ u_⋆ (1−ζ)(h ζ + z_p)
               = κ u_⋆ z_p   at the bed (ζ=0)   → finite near-wall damping,
               = 0           at the surface (ζ=1) → stress-free consistent,
               ≈ κ u_⋆ h ζ(1−ζ)  in the bulk    → the Elder parabola.

    Result: both the bed momentum sink (``WallFunctionBed``: ρu_⋆²) and the bulk
    damping (∝ κ u_⋆ z_p at the wall) are set by the SAME computed u_⋆ and stay
    finite regardless of the moment amplitude, so the equilibrium shear
    ``α₁/u ≈ √(C_f)/κ`` is bounded and depth-INDEPENDENT (no runaway).  See
    ``equilibrium_check.py`` for the symbolic equilibrium-vs-depth proof."""
    closes = "bulk"; requires = ("u",)

    def register(self, m):
        m.parameter("kappa", 0.41)
        m.parameter("k_s", 1e-3)
        m.parameter("z_p", 0.1)
        m.parameter("nu", 0.0)        # molecular floor; ν_t dominates
        m.parameter("u_eps", 1e-3)    # speed-regularization (finite IMEX Jacobian)

    def _ustar(self, s):
        """Computed wall-function friction velocity ``u_⋆ = √(C_f)·√(U_p²+u_eps²)``
        with the near-wall reference velocity ``U_p = u(ζ_p)`` (alias-safe: slot 0
        of ``velocity_at`` is THIS axis' velocity in the diagonal bulk call).  The
        ``u_eps`` floor under the root keeps ∂u_⋆/∂U finite at U=0 — a bare
        ``|U_p|`` has a singular derivative there, which NaNs the IMPLICIT (IMEX)
        cell-wise Newton on the at-rest initial condition."""
        Cf = (s.par.kappa / sp.log(s.par.z_p / (s.par.k_s / 30))) ** 2
        Up = s.velocity_at(_zeta_p(s))[0]
        return sp.sqrt(Cf) * sp.sqrt(Up ** 2 + s.par.u_eps ** 2)

    def expression(self, s):
        z = s.depth * s.zeta
        nu_t = s.par.kappa * self._ustar(s) * (1 - s.zeta) * (z + s.par.z_p)
        return s.par.rho * (s.par.nu + nu_t) * s.dz(s.u)


class SmoothWallFunctionBed(WallFunctionBed):
    """``WallFunctionBed`` with a REGULARIZED slip-speed magnitude so the implicit
    (IMEX) source Jacobian is finite at rest.  Core ``WallFunctionBed`` forms the
    drag from a bare ``√(ΣU²)`` whose ∂/∂U is singular at U=0 — the cell-wise
    Newton then NaNs on the at-rest initial condition (the whole reservoir is
    motionless at t=0).  Here ``|U| → √(ΣU² + u_eps²)`` (the same trick
    ``ManningFriction`` uses with its ``1e-12`` floor), leaving the drag itself
    unchanged for any moving flow."""

    def register(self, m):
        super().register(m)
        m.parameter("u_eps", 1e-3)

    def traction(self, s):
        Cf = self._Cf(s)
        ut = s.u_tangent_at(_zeta_p(s))
        speed = sp.sqrt(sum(u ** 2 for u in ut) + s.par.u_eps ** 2)
        return {"normal": None,
                "tangent": [s.par.rho * Cf * speed * u for u in ut]}

    def expression(self, s):
        Up = s.velocity_at(_zeta_p(s))[0]
        return (s.par.rho * self._Cf(s) * Up
                * sp.sqrt(Up ** 2 + s.par.u_eps ** 2))


def malpasset_elder_closures():
    """Moment-STABLE turbulent closure set: :class:`WallFunctionElder` bulk eddy
    viscosity + :class:`WallFunctionBed` rough-wall log-law bed drag + stress-
    free surface.  Both build their friction velocity from the SAME wall function
    (``u_⋆=√(C_f)|u(ζ_p)|``) evaluated at the near-wall reference height ζ_p —
    NOT at the bed trace ``u(0)`` (which collapses as the first moment grows and
    lets the flow accelerate without bound).  This is the fair, non-runaway
    closure for asking whether SME moments (level ≥ 1) buy anything on Malpasset.
    ``k_s`` (Nikuradse roughness) and ``z_p`` (reference height) are the knobs.

    (The plain ``[ElderViscosity(), RoughWall(), StressFree()]`` set is kept in
    :func:`malpasset_elder_closures_naive` for the runaway comparison.)"""
    return [WallFunctionElder(), SmoothWallFunctionBed(), StressFree()]


def malpasset_elder_closures_naive():
    """The ORIGINAL Elder set that RUNS AWAY — plain parabolic ``ElderViscosity``
    (constant ``u_star``, ν_t→0 at the wall) + ``RoughWall`` (bed drag from the
    collapsing trace ``u(0)``).  Kept only as the negative control in
    ``equilibrium_check.py``; do not use it for production runs."""
    return [ElderViscosity(), RoughWall(), StressFree()]


# ── Malpasset-matched parameters ────────────────────────────────────────────
# Newtonian/Navier-slip set: g, viscosity nu, Navier-slip lambda_s.
MALPASSET_SME_PARAMS = {"g": 9.81, "rho": 1.0, "nu": 1.0, "lambda_s": 0.5}
# Wall-function Elder/Bed set: kappa (von Karman), k_s (Nikuradse roughness),
# z_p (near-wall reference height). NO u_star — the friction velocity u_⋆ is
# COMPUTED from the wall function (u_⋆=√(C_f)|u(ζ_p)|), shared by bulk and bed.
MALPASSET_ELDER_PARAMS = {"g": 9.81, "rho": 1.0, "kappa": 0.41,
                          "k_s": 1e-3, "z_p": 0.1,
                          "nu": 1e-6,    # molecular floor; ν_t dominates
                          "u_eps": 1e-3}  # speed reg. → finite IMEX Jacobian


class MalpassetSME:
    """Malpasset Shallow Moment model = canonical ``SME`` + wet/dry numerics.

    Parameters
    ----------
    level : int
        Moment truncation ``N_u`` (0 ≡ SWE, 1 = first moment, …).
    dimension : int
        ``2`` = 1 horizontal (1-D), ``3`` = 2 horizontals (the 2-D map).
    closures : list | None
        Composable stress closures; defaults to Newtonian + NavierSlip +
        StressFree (:func:`malpasset_closures`).
    parameters : dict
        Physical parameter values (g, rho, nu, lambda_s).
    """

    def __init__(self, *, level: int = 1, dimension: int = 3,
                 closures=None, parameters: dict | None = None,
                 eps: float = 1e-2, u_max: float = 30.0, clamp: bool = False,
                 desingularize: bool = True,
                 boundary_conditions=None, initial_conditions=None,
                 aux_initial_conditions=None):
        self.level = int(level)
        self.dimension = int(dimension)
        self._nh = self.dimension - 1                # number of horizontals
        self.eps = float(eps)            # wet/dry threshold for the wavespeed gate
        self.u_max = float(u_max)        # velocity cap for the momentum clamp
        self.clamp = bool(clamp)         # per-cell momentum cap on/off
        self.desingularize = bool(desingularize)  # hinv-aux KP 1/h regularization
        self._hinv_sym = None
        self._hinv_update = None
        self.closures = list(closures) if closures is not None else malpasset_closures()
        self.values = dict(MALPASSET_SME_PARAMS)
        if parameters:
            self.values.update({k: float(v) for k, v in parameters.items()})
        # REQ-48: expose the wet/dry threshold as the canonical model parameter
        # ``wet_dry_eps`` (the single source of truth the FVM riemann solver and
        # the jax reconstruction read) instead of baking ``self.eps`` as a sympy
        # literal.  Default from ``eps``; an explicit parameter override wins.
        self.values.setdefault("wet_dry_eps", self.eps)
        self.eps = float(self.values["wet_dry_eps"])   # keep the attr in sync
        self.boundary_conditions = boundary_conditions
        self.initial_conditions = initial_conditions
        self.aux_initial_conditions = aux_initial_conditions
        # The canonical, dimension-general SME does the derivation + closure.
        self._sme = SME(level=self.level, dimension=self.dimension,
                        closures=self.closures, parameters=self.values)

    # ── runtime SystemModel ─────────────────────────────────────────────────
    @property
    def system_model(self) -> SystemModel:
        sm = self._sme.system_model
        # NO hand-rolled regularization here (REQ-63): the 1/h desingularization
        # (`hinv` aux) AND the dry eigenvalue gate are now the NSM's job — applied
        # automatically by NumericalSystemModel.from_system_model via its
        # default_operations `[desingularize_hinv(), gate_eigenvalues_dry()]` for
        # any transport system carrying an `h` state.  The canonical SME also
        # provides its own Koellermeier-Rominger eigenvalues, so the former
        # `_register_hinv_aux` / `_register_spectrum` are gone (they double-
        # desingularized on top of the NSM default → ~45x per-step slowdown).
        if self.clamp:
            self._register_state_clamp(sm)
        if self.boundary_conditions is not None:
            sm.attach_boundary_conditions(
                self.boundary_conditions,
                aux_bcs=getattr(self, "aux_boundary_conditions", None))
        return sm

    # ── momentum naming (dimension-agnostic) ────────────────────────────────
    def _mom_name(self, d, m):
        """Name of the (direction ``d``, mode ``m``) momentum state: ``q_<m>``
        for 1 horizontal (1-D), ``q_<x|y>_<m>`` for 2 horizontals (2-D)."""
        return f"q_{m}" if self._nh == 1 else f"q_{('x', 'y')[d]}_{m}"

    # KP-desingularized inverse depth (the regularization the model carries as
    # a proper ``hinv`` aux; recomputed each step from h by the solver's
    # update_qaux — now a uniform framework hook, not a driver subclass).
    @staticmethod
    def kp_hinv(h, eps):
        """``hinv = √2·h/√(h⁴ + max(h,eps)⁴)`` — equals ``1/h`` for ``h ≥ eps``
        but → 0 (not ``1/eps``) as ``h → 0``, so ``u = q·hinv → 0`` at the
        shoreline.  Evaluates symbolically (sympy) or numerically (numpy/jax)."""
        import sympy as _sp
        Max = _sp.Max if isinstance(h, _sp.Basic) else max
        sqrt = _sp.sqrt if isinstance(h, _sp.Basic) else (lambda x: x ** 0.5)
        # UNSIGNED numerator (Max(h,0)): honours the Symbol("hinv", positive=True)
        # this aux declares. A RAW signed `h` lets a transient negative-h cell flip
        # hinv negative → u=q·hinv wrong-sign → wrong-sign HLL eigenvalues →
        # anti-dissipative wet/dry-front wavespeed runaway → NaN (jax REQ-13 audit).
        return sqrt(2) * Max(h, 0) / sqrt(h ** 4 + Max(h, eps) ** 4)

    def _register_hinv_aux(self, sm):
        """Register ``hinv`` as a proper auxiliary field — the model-supplied
        ``1/h`` regularization layer.

        The SME flux/source carry RAW ``1/h`` (and ``1/h²``) from the
        conservative change of variables ``u = q/h``.  In near-dry cells
        ``q/h`` blows up the velocity → ``dt → 0``.  Instead of dividing by
        ``h`` we carry a desingularized inverse depth as a named aux ``hinv``
        and replace every ``h^{-n}`` in the operators by ``hinv^{n}``.  The aux
        is refreshed each step from the current ``h`` by the solver's
        ``update_qaux`` via :attr:`update_aux_variables` (KP :meth:`kp_hinv`).
        Naming it ``hinv`` also lets the Audusse Riemann solver re-regularize it
        at the hydrostatically reconstructed faces (``riemann_solvers``)."""
        import itertools
        hs = next(s for s in sm.state if str(s) == "h")
        eps = sm.parameters.wet_dry_eps                # REQ-48 canonical parameter
        hinv = sp.Symbol("hinv", positive=True)        # the aux field symbol
        self._hinv_sym = hinv
        self._hinv_update = self.kp_hinv(hs, eps)       # symbolic KP(h)

        def _hfactor(s):
            """For a negative power ``base^n`` (n<0) in which ``h`` is an EXACT
            divisor of ``base`` (so ``base = h·R`` with R h-free), return the
            desingularized ``hinv^{-n}·R^n`` — i.e. pull the ``h`` out and turn
            ``1/h`` into the bounded aux ``hinv``.  Covers a bare ``h`` (R=1), a
            product ``(h·B)^n``, AND — crucially — an ADD denominator where h is a
            common factor, e.g. the wall-function projection's
            ``1/(h·ln(z_p/z_0)²)`` whose base sympy stores as
            ``-h·log(k_s)²+2h·log(k_s)log(z_p)+…`` (an Add).  That last form keeps
            a RAW 1/h that the bare-``h``/``Mul`` matchers miss; at a dry cell h=0
            the base→0 so 1/base→inf and (0·inf)→NaN in the moment source, which
            poisons the implicit solve and kills the 2-D moments."""
            R = sp.cancel(s.base / hs)         # base / h
            return hinv ** (-s.exp) * R ** s.exp

        def sub(e):
            if not isinstance(e, sp.Basic):
                return e
            return e.replace(
                lambda s: (isinstance(s, sp.Pow) and s.exp.is_number
                           and s.exp.is_negative and s.base.has(hs)
                           and not sp.cancel(s.base / hs).has(hs)),
                _hfactor)

        def map_array(M):
            if M is None:
                return None
            if isinstance(M, sp.MatrixBase):
                return M.applyfunc(sub)
            flat = [sub(M[idx]) for idx in
                    itertools.product(*[range(s) for s in M.shape])]
            return (ZArray(flat, M.shape) if isinstance(M, ZArray)
                    else sp.Array(flat).reshape(*M.shape))

        sm.flux = map_array(sm.flux)
        sm.source = map_array(sm.source)
        sm.nonconservative_matrix = map_array(sm.nonconservative_matrix)
        sm.hydrostatic_pressure = map_array(sm.hydrostatic_pressure)
        for nm in ("diffusion_matrix", "diffusion_matrix_explicit"):
            if getattr(sm, nm, None) is not None:
                setattr(sm, nm, map_array(getattr(sm, nm)))
        sm.aux_state = list(sm.aux_state) + [hinv]
        # update_aux_variables MUST be a FULL-length aux vector. The JAX
        # `update_qaux` writes it as a PREFIX slice `Qaux[:len(update)]` and then
        # overwrites the LSQ derivative-aux rows. A 1-row `[hinv_update]` lands
        # hinv in aux row 0 (a derivative slot) where the LSQ walk clobbers it,
        # leaving hinv's real (last) slot ≡ 0 — which silently zeroes the ENTIRE
        # SME moment source (every term is ∝ hinv) AND the SME bed friction, so
        # SME(level≥1) degenerates to inviscid SWE. Emit passthrough on every
        # existing aux row and the KP formula in hinv's own slot, so the prefix
        # write covers all rows and only hinv survives the derivative walk.
        # [Proper fix = library `update_qaux` honouring aux indices: REQ-09/0017.]
        upd = list(sm.aux_state)          # passthrough: row i -> its aux symbol
        upd[-1] = self._hinv_update       # hinv slot -> KP(h)
        sm.update_aux_variables = ZArray(upd)
        sm.refresh_derived_operators(eigenvalues=False)

    def _register_spectrum(self, sm):
        """Normal-projected HSWME spectrum (dimension-agnostic).

        Velocity ``u_n = q_n · inv`` with ``inv`` = the KP-desingularized
        ``hinv`` (when ``desingularize``; dry speeds stay bounded, no gate) or a
        floored ``1/max(h, eps)`` + a ``h ≤ eps`` gate (the legacy clamp path)."""
        Nu = self.level
        eps = sm.parameters.wet_dry_eps                # REQ-48 canonical parameter
        by = {str(s_): s_ for s_ in sm.state}
        h_s = by["h"]
        h_safe = sp.Max(h_s, eps)
        nrm = sm.normal
        if self.desingularize:
            inv = self._hinv_sym if self._hinv_sym is not None else self.kp_hinv(h_s, eps)
        else:
            inv = 1 / h_safe
        u_n = sum(by[self._mom_name(d, 0)] * nrm[d] for d in range(self._nh)) * inv
        if Nu >= 1:
            a1_n = -sum(by[self._mom_name(d, 1)] * nrm[d]
                        for d in range(self._nh)) * inv
        else:
            a1_n = sp.S.Zero
        c_wave = sp.sqrt(sm.parameters.g * h_safe + a1_n ** 2)
        lams = [sp.S.Zero, u_n - c_wave, u_n + c_wave]
        if Nu >= 1:
            roots = np.polynomial.legendre.leggauss(Nu)[0]   # roots of P_Nu
            lams += [u_n + sp.Float(float(cc)) * a1_n for cc in roots]
        while len(lams) < sm.n_equations:        # tangential moments advect at u_n
            lams.append(u_n)
        assert len(lams) == sm.n_equations, (len(lams), sm.n_equations)
        if not self.desingularize:               # KP keeps dry speeds bounded;
            cond = sp.Function("conditional")    # gate only needed on the clamp path
            lams = [cond(h_s > eps, lam, sp.S.Zero) for lam in lams]
        sm.eigenvalues = sp.Matrix(sm.n_equations, 1, lams)

    def _register_state_clamp(self, sm):
        """Per-cell ``update_variables`` momentum cap — the SME analogue of
        :meth:`MalpassetSWE.update_variables`: cap each momentum/moment to
        ``|q| ≤ h_wet·u_max`` (``h_wet = max(h-eps, 0)``) so the bounded
        velocity ``u = q·hinv ≤ u_max`` keeps the CFL wave-speed finite at the
        wet/dry front.  ``h`` is NEVER touched (no h-floor → mass conserved)."""
        eps = sp.Float(self.eps)
        u_max = sp.Float(self.u_max)
        h_s = sm.state[list(map(str, sm.state)).index("h")]
        h_wet = sp.Max(h_s - eps, sp.S.Zero)
        cap_lim = h_wet * u_max

        def cap(q):
            return sp.Max(-cap_lim, sp.Min(q, cap_lim))

        new = []
        for s_ in sm.state:
            nm = str(s_)
            if nm.startswith("q_"):
                new.append(cap(s_))
            else:                                # depth h and bed b — unchanged
                new.append(s_)
        sm.update_variables = ZArray(new)
# ------------------------------------------------------------------

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())
# Default mesh = the case-shipped copy (self-contained folder case).  The
# advanced CLI (malpasset_sme_jax.py) overrides with an explicit path.
DEFAULT_MESH_PATH = os.path.join(CASE_DIR, "geo_malpasset-small.msh")

_RIEMANN = {"hr": PositiveNonconservativeHLL,
            "rusanov": PositiveNonconservativeRusanov}


def momentum_layout(idx):
    """Name-aware (x0, y0, wall_groups) for the depth-averaged momentum.

    SWE state ``[b,h,hu,hv]`` → x0=hu, y0=hv, one reflect group.
    SME state ``[b,h,q_x_0,q_x_1,q_y_0,q_y_1,…]`` → x0=q_x_0, y0=q_y_0,
    and the mode-0 + mode-1 momenta each form a reflect group."""
    if "hu" in idx:                                   # SWE / MalpassetSWE
        return "hu", "hv", [[idx["hu"], idx["hv"]]]
    if "q_x_0" not in idx:                             # SME 1-D (dimension=2)
        groups = [[idx["q_0"]]] + ([[idx["q_1"]]] if "q_1" in idx else [])
        return "q_0", None, groups
    x0, y0 = "q_x_0", "q_y_0"
    groups = [[idx[x0], idx[y0]]]
    if "q_x_1" in idx and "q_y_1" in idx:
        groups.append([idx["q_x_1"], idx["q_y_1"]])
    return x0, y0, groups


def mesh_ic_field_map(idx):
    """The case-specific B/H/U/V (mesh node data) → state recipe, by name.

    The only IC datum that stays case-side: bathymetry ``b←B``, depth ``h←H``,
    and depth-averaged momentum ``h·u←H·U`` / ``h·v←H·V`` on the mode-0 slots
    (higher moments default to 0).  Everything mechanical — the ``$NodeData``
    read, the node→cell nearest interpolation, the assembly into the state
    layout — is core's :func:`initial_conditions_from_mesh`."""
    x0, y0, _ = momentum_layout(idx)
    fmap = {"b": "B", "h": "H",
            x0: (lambda f: f["H"] * f["U"])}       # h·u
    if y0 is not None:
        fmap[y0] = (lambda f: f["H"] * f["V"])    # h·v (2-D map)
    return fmap


class MeshDataIC(IC.InitialConditions):
    """Array-form IC: core reads the ``.msh`` node data and assembles the
    per-cell state ONCE.  ``method="nearest"`` = the retired hand-rolled reader
    (each cell takes its nearest survey node).  NO h floor — dry cells start at
    exactly h=0 (the ``.msh`` H is ≥0); the only 1/h regularization is the
    ``hinv`` aux, which never alters h itself.

    ``apply(X, Q)`` is handed the solver's inner-cell centres as ``X`` (columns
    aligned to ``Q``); we pass them straight through as core's ``query_points``
    so the assembled array lines up with ``Q`` regardless of mesh ordering."""

    def __init__(self, mesh_path, field_map, state_names, method="nearest", **p):
        super().__init__(**p)
        self._mesh_path = mesh_path
        self._field_map = field_map
        self._state_names = list(state_names)
        self._method = method

    def apply(self, X, Q):
        """Apply."""
        arr = initial_conditions_from_mesh(
            self._mesh_path, self._field_map, state_names=self._state_names,
            method=self._method,
            query_points=np.asarray(X, dtype=float).T)
        Q[...] = np.asarray(arr, dtype=Q.dtype)
        return Q


def build_ic(sm, mesh_path=None):
    """IC from the mesh point-data, mapped onto the state by name (SWE or SME),
    via core's :func:`initial_conditions_from_mesh`.  Returns ``(ic, idx)`` where
    ``ic`` is an :class:`InitialConditions` (set it as ``sm.initial_conditions``
    directly — no ``UserFunction`` wrapper)."""
    names = [str(s) for s in sm.state]
    idx = {n: k for k, n in enumerate(names)}
    fmap = mesh_ic_field_map(idx)
    ic = MeshDataIC(mesh_path or DEFAULT_MESH_PATH, fmap, names)
    return ic, idx


def wall_bcs(sm, idx, mesh):
    """Solid walls: reflect the momentum vectors on every physical boundary tag."""
    _, _, mom_groups = momentum_layout(idx)
    tags = list(getattr(mesh, "boundary_conditions_sorted_names", []) or ["tag_0"])
    return BoundaryConditions([
        Wall(tag=tg, momentum_field_indices=mom_groups,
             permeability=0.0, wall_slip=1.0) for tg in tags
    ]), tags


def build_model(settings, mesh, case_dir=None):
    """Build the Malpasset ``MalpassetSME`` NSM with IC/BC baked, from
    ``settings.json``.  Returns a dict ::

        {nsm, sm, idx, fs_kwargs, tags}

    ``fs_kwargs`` are the free-surface / wet-dry reconstruction knobs the
    solver (``run.py``) needs; kept here so the model + its wet-dry recipe stay
    together.  Mirrors ``malpasset_sme_jax.py`` main() exactly (level-1 default
    = the deck run).
    """
    case_dir = case_dir or CASE_DIR
    m = settings["model"]
    num = settings["numerics"]

    # ── closures + params (navier | elder) ──────────────────────────────
    if m.get("closure", "navier") == "elder":
        closures = malpasset_elder_closures()
        params = dict(MALPASSET_ELDER_PARAMS)
        if m.get("k_s") is not None:
            params["k_s"] = m["k_s"]
    else:
        closures = malpasset_closures()
        params = {"nu": m.get("nu", 1.0), "lambda_s": m.get("lambda_s", 0.5)}
    # wet/dry threshold is the NSM-owned model parameter (jax REQ-48).
    params["wet_dry_eps"] = m.get("wet_dry_eps", 1e-3)

    sme = MalpassetSME(
        level=m.get("level", 1), dimension=m.get("dimension", 3),
        closures=closures, desingularize=m.get("desingularize", True),
        clamp=m.get("clamp", True), parameters=params)
    sm = sme.system_model

    # ── IC (mesh point-data) + wall BCs ─────────────────────────────────
    mesh_path = os.path.join(case_dir, settings["mesh"])
    ic, idx = build_ic(sm, mesh_path=mesh_path)
    bcs, tags = wall_bcs(sm, idx, mesh)
    sm.attach_boundary_conditions(bcs)
    sm.initial_conditions = ic                     # array-form MeshDataIC
    sm.aux_initial_conditions = IC.Constant(constants=lambda n: np.zeros(n))

    # ── numerics: NSM + free-surface wet/dry reconstruction knobs ───────
    riemann = _RIEMANN.get(num.get("riemann", "hr"))
    rkw = {"riemann": riemann} if riemann is not None else {}
    nsm = NumericalSystemModel.from_system_model(
        sm, reconstruction=ReconstructionSpec(order=num.get("order", 1)), **rkw)

    _, _, groups = momentum_layout(idx)
    mom_idx = sorted(i for g in groups for i in g)
    fs_kwargs = dict(
        free_surface_h_index=idx["h"],
        free_surface_b_index=idx["b"],
        free_surface_momentum_indices=mom_idx,
        reconstruction_variables=num.get("reconstruction_variables", "eta"),
        positivity_method=("" if num.get("positivity_method", "zhang_shu") == "none"
                           else num.get("positivity_method", "zhang_shu")),
    )
    return {"nsm": nsm, "sm": sm, "idx": idx, "fs_kwargs": fs_kwargs, "tags": tags}
