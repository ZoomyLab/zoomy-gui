"""Malpasset (jax backend) — GUI folder-case ``mesh.py`` (REQ-137).

Loads the case-shipped real Malpasset triangular mesh
(``geo_malpasset-small.msh``, ~2.6 MB, carries the B/H/U/V survey point data the
IC reads) as an ``LSQMesh``.  ``settings["mesh"]`` names the file (relative to
the case dir), so the folder case is self-contained.
"""

import os

from zoomy_core.mesh import LSQMesh

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())


MESH_URL = 'https://raw.githubusercontent.com/ZoomyLab/data/f46bdde4d5c66c18e597afcfef8a9ffce171fd05/malpasset/'


def _ensure_mesh(fname, case_dir=None):
    """Case-shipped mesh if present, else fetch it from the Zoomy data repository."""
    p = os.path.join(case_dir or CASE_DIR, fname)
    if not os.path.exists(p):
        import urllib.request
        print("mesh not found locally; fetching", MESH_URL + fname, flush=True)
        urllib.request.urlretrieve(MESH_URL + fname, p)
    return p


def build_mesh(settings, case_dir=None):
    """Load the case mesh named in ``settings['mesh']``."""
    case_dir = case_dir or CASE_DIR
    return LSQMesh.from_msh(_ensure_mesh(settings["mesh"], case_dir))
