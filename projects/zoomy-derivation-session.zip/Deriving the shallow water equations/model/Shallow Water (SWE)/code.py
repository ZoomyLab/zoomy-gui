import sympy as sp

from zoomy_core import coords as C
import zoomy_core.derivatives as d
from zoomy_core.model.derivation import (
    Model, PDETransformation, Simplify, ResolveIntegral,
    Consolidate, InvertMassMatrix, ChangeOfVariables, FoldConservative)
from zoomy_core.model.derivation.projection import Integrate
from zoomy_core.model.derivation.system_extract import HydrostaticPressure
from zoomy_core.model.operations import Multiply, ProductRule, KinematicBC
from zoomy_core.model.operations import Integrate as IntegrateZ
from zoomy_core.model.models.equations import Mass, Momentum, moment_scaling

t, x, z = C.t, C.x, C.z
zeta = sp.Symbol("zeta", real=True)


def show(m, label, simplify=True):
    print(f"===== {label} =====", flush=True)
    for name, eq in m._equations.items():
        e = sp.simplify(eq.expr) if simplify else eq.expr
        print(f"  {name}:  {e}", flush=True)


def build_model(settings=None, mesh=None, case_dir=None):

    m = Model(coords=(t, x, z), parameters={"g": 9.81, "rho": 1.0})
    g = m.parameters.g
    h = sp.Function("h", positive=True)(t, x)
    b = sp.Function("b", real=True)(t, x)

    m.declare_state(h)
    m.add_equation("bottom", d.t(b))
    m.add_equation(Mass(m))
    mom = Momentum(m)
    m.add_equation(mom)
    moment_scaling(m, mom)
    u, w, p = mom.uvel[0], mom.w, mom.p
    m.move_to_aux(b)
    m.add_equation("kbc_top", KinematicBC(w=w, u=u, interface=b + h))
    m.add_equation("kbc_bot", KinematicBC(w=w, u=u, interface=b))
    show(m, "1. incompressible Navier-Stokes balances")


    m.apply({m.functions.tau_xz.expr: 0})


    mz = m.momentum.z
    mz.apply({d.t(w): 0, d.z(w * w): 0, d.x(u * w): 0})
    mz.apply(IntegrateZ(z, z, b + h, method="analytical"))
    mz.apply({p.subs(z, b + h): 0})
    psol = mz.solve_for(p)
    print("p(z) =", psol._as_relation[p], flush=True)
    m.momentum.x.apply(psol)
    mz.remove()
    m.momentum.x.apply(Simplify())
    show(m, "2. hydrostatic: the pressure unknown is gone")


    m.apply(PDETransformation({z: (zeta, sp.Eq(z, b + h * zeta))}))
    show(m, "3. mapped onto zeta in [0, 1]")


    ubar = sp.Function(r"\bar{u}", real=True)(t, x)
    utilde = m.functions.u.head
    for eq in m._equations.values():
        eq.expr = eq.expr.replace(utilde, lambda *a: ubar)
    for a in m._assumptions.values():
        a._as_relation = {k.replace(utilde, lambda *aa: ubar):
                          v.replace(utilde, lambda *aa: ubar)
                          for k, v in a._as_relation.items()}
    m.redeclare_unknown(utilde, ubar, rename_key=True)
    show(m, "4. the velocity is uniform over the depth")


    for e in (m.mass, m.momentum.x):
        e.apply(Multiply(h))
        e.apply(ProductRule(variables=[zeta]))
        e.apply(Integrate(zeta, bounds=(0, 1)))
        e.apply(ResolveIntegral())
        e.apply(m.kbc_bot)
        e.apply(m.kbc_top)
        e.apply({sp.Derivative(b, t): 0})
        e.apply(Simplify())
    show(m, "5. depth-averaged, the vertical velocity is eliminated")


    h_eq = m.mass.solve_for(sp.Derivative(h, t))
    m.momentum.x.apply(h_eq)
    m.momentum.x.apply(Consolidate())
    m.apply(ChangeOfVariables(r"\bar{u}", "q_0", lambda q: q / h))
    m.apply(InvertMassMatrix())
    q0 = sp.Function("q_0", real=True)(t, x)
    m.momentum.x.apply(FoldConservative([q0], h=h, b=b, x=x, gravity=g))
    show(m, "6. THE SHALLOW WATER EQUATIONS", simplify=False)


    P_hydro = g * h**2 / 2
    m.momentum.x.expr = m.momentum.x.expr.replace(
        lambda e: isinstance(e, sp.Derivative) and e.args[0] == P_hydro,
        lambda e: sp.Derivative(HydrostaticPressure(P_hydro), *e.args[1:],
                                evaluate=False))
    print(f"tagged  d_x({P_hydro})  ->  hydrostatic-pressure slot", flush=True)
    print("state:", list(m.Q.keys()), " aux:", list(m.Qaux.keys()), flush=True)
    return {"model": m, "b": b, "h": h, "q0": q0}


bundle = build_model()
