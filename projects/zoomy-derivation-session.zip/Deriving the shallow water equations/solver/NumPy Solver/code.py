import numpy as np

import zoomy_core.model.boundary_conditions as BC
import zoomy_core.model.initial_conditions as IC
from zoomy_core.fvm import timestepping
from zoomy_core.fvm.solver_numpy import HyperbolicSolver
from zoomy_core.numerics import NumericalSystemModel, ReconstructionSpec
from zoomy_core.systemmodel import SystemModel
from zoomy_core.systemmodel.operations import desingularize_hinv

sm = SystemModel.from_model(model, Q=[b, h, q0])
display(sm.describe())

sm.apply(desingularize_hinv())
nsm = NumericalSystemModel.from_system_model(
    sm, reconstruction=ReconstructionSpec(order=1), depth_regularization="none")
nsm.attach_boundary_conditions(BC.BoundaryConditions([
    BC.Wall(tag="left", momentum_field_indices=[[2]]),
    BC.Wall(tag="right", momentum_field_indices=[[2]])]))
nsm.initial_conditions = IC.RP(
    high=lambda n: np.array([0.0, 2.0, 0.0]),
    low=lambda n: np.array([0.0, 1.0, 0.0]),
    jump_position_x=5.0)
nsm.aux_initial_conditions = IC.Constant(constants=lambda n: np.zeros(n))
display(nsm.describe())

solver = HyperbolicSolver(time_end=settings["time_end"],
                          compute_dt=timestepping.adaptive(CFL=0.9))
solver.settings.output.snapshots = 40
Q, Qaux = solver.solve(mesh, nsm)
