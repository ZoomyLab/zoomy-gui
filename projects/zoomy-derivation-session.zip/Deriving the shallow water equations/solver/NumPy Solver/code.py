import os

import numpy as np

import zoomy_core.model.boundary_conditions as BC
import zoomy_core.model.initial_conditions as IC
from zoomy_core.fvm import timestepping
from zoomy_core.fvm.solver_numpy import HyperbolicSolver
from zoomy_core.numerics import NumericalSystemModel, ReconstructionSpec
from zoomy_core.systemmodel import SystemModel
from zoomy_core.systemmodel.operations import desingularize_hinv

try:
    build_mesh, build_model
except NameError:
    from mesh import build_mesh
    from model import build_model

CASE_DIR = (os.path.dirname(os.path.abspath(__file__))
            if "__file__" in globals() else os.getcwd())

_SETTINGS = {"name": "swe_dambreak", "run": {"time_end": 0.5, "snapshots": 40}}


def load_settings():
    gui = globals().get("settings")
    s = dict(_SETTINGS)
    if isinstance(gui, dict) and gui.get("time_end") is not None:
        s["run"] = dict(s["run"], time_end=float(gui["time_end"]))
    return s


def run(settings=None):
    settings = settings or load_settings()
    name, rc = settings["name"], settings["run"]

    mesh = globals().get("mesh") or build_mesh(settings, CASE_DIR)
    bundle = globals().get("bundle") or build_model(settings, mesh, CASE_DIR)
    m, b, h, q0 = bundle["model"], bundle["b"], bundle["h"], bundle["q0"]

    sm = SystemModel.from_model(m, Q=[b, h, q0])
    print("system model state:", [str(s) for s in sm.state], flush=True)


    sm.apply(desingularize_hinv())
    nsm = NumericalSystemModel.from_system_model(
        sm, reconstruction=ReconstructionSpec(order=1),
        depth_regularization="none")
    print("aux after desingularize_hinv:", [str(s) for s in sm.aux_state],
          flush=True)
    print("Riemann solver:", type(nsm.build_numerics()).__name__, flush=True)


    wall = dict(momentum_field_indices=[[2]])
    nsm.attach_boundary_conditions(BC.BoundaryConditions(
        [BC.Wall(tag="left", **wall), BC.Wall(tag="right", **wall)]))
    nsm.initial_conditions = IC.RP(
        high=lambda n: np.array([0.0, 2.0] + [0.0] * (n - 2)),
        low=lambda n: np.array([0.0, 1.0] + [0.0] * (n - 2)),
        jump_position_x=5.0)
    nsm.aux_initial_conditions = IC.Constant(constants=lambda n: np.zeros(n))

    outdir = os.path.join(CASE_DIR, "output")
    os.makedirs(outdir, exist_ok=True)
    solver = HyperbolicSolver(time_end=float(rc["time_end"]),
                              compute_dt=timestepping.adaptive(CFL=0.9))
    solver.settings.output.directory = outdir
    solver.settings.output.filename = name
    solver.settings.output.snapshots = int(rc.get("snapshots", 40))
    print(f"[{name}] solving a 2:1 dam break to t={rc['time_end']} s on "
          f"{mesh.n_inner_cells} cells ...", flush=True)
    Q, _ = solver.solve(mesh, nsm, write_output=True)

    Q = np.asarray(Q[:, :mesh.n_inner_cells], dtype=float)
    print(f"h range   : {Q[1].min():.4f} .. {Q[1].max():.4f}", flush=True)
    print(f"total mass: {Q[1].sum():.6f}   (walls hold it)", flush=True)
    return os.path.join(outdir, name + ".h5")


_h5 = run()
import shutil
shutil.copy(_h5, "simulation.h5")
print("artifact -> simulation.h5", flush=True)
