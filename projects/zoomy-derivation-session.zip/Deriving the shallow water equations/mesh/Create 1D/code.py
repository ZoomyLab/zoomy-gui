from zoomy_core.mesh import BaseMesh

mesh = BaseMesh.create_1d(domain=(0.0, 10.0), n_inner_cells=200)
