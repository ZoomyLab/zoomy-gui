from zoomy_core.mesh import BaseMesh


def build_mesh(settings=None, case_dir=None):
    cfg = (settings or {}).get("mesh", {})
    return BaseMesh.create_1d(
        domain=tuple(cfg.get("domain", (0.0, 10.0))),
        n_inner_cells=int(cfg.get("n_cells", 200)))


mesh = build_mesh()
print(f"mesh: 1-D, {mesh.n_inner_cells} cells on [0, 10] m")
