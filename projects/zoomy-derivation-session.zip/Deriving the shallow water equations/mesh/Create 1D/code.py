"""Zoomy pipeline, example 1 of 3 -- GUI folder-case ``mesh.py``.

A plain 1-D mesh for the dam break the derived model is run on at the end. The
derivation itself needs no mesh: it is symbolic.
"""
from zoomy_core.mesh import BaseMesh


def build_mesh(settings=None, case_dir=None):
    cfg = (settings or {}).get("mesh", {})
    return BaseMesh.create_1d(
        domain=tuple(cfg.get("domain", (0.0, 10.0))),
        n_inner_cells=int(cfg.get("n_cells", 200)))


mesh = build_mesh()
print(f"mesh: 1-D, {mesh.n_inner_cells} cells on [0, 10] m")
