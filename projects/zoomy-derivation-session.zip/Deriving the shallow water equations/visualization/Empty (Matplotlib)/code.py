import h5py
import numpy as np
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt

try:
    from zoomy_plotting.plot import style as zstyle
    zstyle.use("thesis")
except Exception:
    mpl.rcParams.update({"font.size": 9, "font.family": "serif",
                         "figure.dpi": 130, "savefig.dpi": 130})

H5 = "simulation.h5"


def read(path):
    with h5py.File(path, "r") as f:
        keys = sorted(f["fields"], key=lambda k: int(k.split("_")[1]))
        frames = [(float(f["fields"][k]["time"][()]),
                   np.asarray(f["fields"][k]["Q"])) for k in keys]
        xv = np.asarray(f["mesh"]["vertex_coordinates"])[0]
    return frames, 0.5 * (xv[:-1] + xv[1:])


frames, xc = read(H5)
n = min(len(xc), frames[0][1].shape[1])
xc, o = xc[:n], np.argsort(xc[:n])
(t0, Q0), (t1, Q1) = frames[0], frames[-1]

fig, (a0, a1) = plt.subplots(1, 2, figsize=(7.0, 2.6))
a0.plot(xc[o], (Q0[0] + Q0[1])[:n][o], lw=1.0, ls="--",
        label=f"$t = {t0:.2f}$ s")
a0.plot(xc[o], (Q1[0] + Q1[1])[:n][o], lw=1.4, label=f"$t = {t1:.2f}$ s")
a0.set_xlabel("$x$ [m]")
a0.set_ylabel("$b + h$ [m]")
a0.set_title("(a) free surface")
a1.plot(xc[o], Q0[2][:n][o], lw=1.0, ls="--", label=f"$t = {t0:.2f}$ s")
a1.plot(xc[o], Q1[2][:n][o], lw=1.4, label=f"$t = {t1:.2f}$ s")
a1.set_xlabel("$x$ [m]")
a1.set_ylabel("$q_0$ [m$^2$ s$^{-1}$]")
a1.set_title("(b) discharge")
for a in (a0, a1):
    a.grid(True, alpha=0.3)
    a.legend(frameon=False)
fig.tight_layout()
fig.savefig("dambreak.png", dpi=150)
print("figure -> dambreak.png", flush=True)
plt.show()
