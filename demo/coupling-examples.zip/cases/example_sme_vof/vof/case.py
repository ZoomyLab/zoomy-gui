# %% [markdown] zoomy={"role":"meta","title":"vof (VOF participant)","description":"Coupled incompressible VOF."}
# # vof (VOF participant)
#
# Coupled incompressible VOF.

# %% [markdown] zoomy={"role":"heading","section":"model"}
# ## Model

# %% zoomy={"role": "model", "class_path": null, "card": "vof-openfoam", "init": {}}
import numpy as np
import zoomy_core.model.boundary_conditions as BC

# COUPLED incompressible Volume-of-Fluid participant (interFoam / incompressibleVoF).
# preCICE Coupled BC on the shared interface (mesh_name "VofInletMesh").
coupled_interfaces = BC.BoundaryConditions([
    BC.Coupled(tag="coupled", mesh_name="VofInletMesh")])

# %% [markdown] zoomy={"role":"heading","section":"mesh"}
# ## Mesh

# %% zoomy={"role": "mesh", "spec": {"x_min": 0, "x_max": 1.5, "y_min": 0, "y_max": 0.4, "nx": 30, "ny": 10}}
from zoomy_core.mesh import BaseMesh

mesh = BaseMesh.create_2d((0, 1.5, 0, 0.4), nx=30, ny=10)
mesh.write_to_hdf5("mesh.h5")

# %% [markdown] zoomy={"role":"heading","section":"settings"}
# ## Solver settings

# %% zoomy={"role":"settings","settings":{"backend": "OpenFOAM", "solver_id": "solver-foam-vof"}}
settings = {
  "backend": "OpenFOAM",
  "solver_id": "solver-foam-vof"
}

# %% [markdown] zoomy={"role":"heading","section":"run"}
# ## Run

# %% zoomy={"role":"run"}
# COUPLED PARTICIPANT — do not run standalone. Launch the whole coupling from
# the parent folder's "Run coupled" (OpenFOAM backend + preCICE): every
# participant is started together, shares the coupling folder (the preCICE
# exchange-directory) and they find each other over sockets. In the GUI, running
# this case alone is gated on a connected OpenFOAM backend (the selected solver
# is zoomyFoam / incompressibleVOF, not numpy) — it is NOT a local numpy run.
