# %% [markdown] zoomy={"role":"meta","title":"sme_out (SME outflow)","description":"Coupled SME outflow arm."}
# # sme_out (SME outflow)
#
# Coupled SME outflow arm.

# %% [markdown] zoomy={"role":"heading","section":"model"}
# ## Model

# %% zoomy={"role": "model", "class_path": "zoomy_core.model.models.SME", "init": {"level": 2, "dimension": 2}}
import numpy as np
from zoomy_core.model.models import SME
import zoomy_core.model.boundary_conditions as BC
import zoomy_core.model.initial_conditions as IC
from zoomy_core.systemmodel import SystemModel

# COUPLED SME arm. Wall on the outer boundary; a preCICE Coupled BC on the
# shared interface (mesh_name "Mesh2" = this participant's provide-mesh).
# A dam-break Riemann state (h: 2.0 -> 1.0 at x=5) feeds the arm.
model = SystemModel.from_model(SME(
    level=2, dimension=2,
    boundary_conditions=BC.BoundaryConditions([
        BC.FromModel(tag="outer", definition="wall"),
        BC.Coupled(tag="coupled", mesh_name="Mesh2")]),
    initial_conditions=IC.RP(
        high=lambda n: np.array([0.0, 2.0] + [0.0] * (n - 2)),
        low=lambda n: np.array([0.0, 1.0] + [0.0] * (n - 2)),
        jump_position_x=5.0)))

# %% [markdown] zoomy={"role":"heading","section":"mesh"}
# ## Mesh

# %% zoomy={"role": "mesh", "spec": {"x_min": 0, "x_max": 10, "n_cells": 40}}
from zoomy_core.mesh import BaseMesh

mesh = BaseMesh.create_1d(domain=(0, 10), n_inner_cells=40)
mesh.write_to_hdf5("mesh.h5")

# %% [markdown] zoomy={"role":"heading","section":"settings"}
# ## Solver settings

# %% zoomy={"role":"settings","settings":{"backend": "OpenFOAM", "solver_id": "solver-foam"}}
settings = {
  "backend": "OpenFOAM",
  "solver_id": "solver-foam"
}

# %% [markdown] zoomy={"role":"heading","section":"run"}
# ## Run

# %% zoomy={"role":"run"}
# COUPLED PARTICIPANT — do not run standalone. Launch the whole coupling from
# the parent folder's "Run coupled" (OpenFOAM backend + preCICE): every
# participant is started together, shares the coupling folder (the preCICE
# exchange-directory) and they find each other over sockets. In the GUI, running
# this case alone is gated on a connected OpenFOAM backend (the selected solver
# is zoomyFoam / incompressibleVOF, not numpy) — it is NOT a local numpy run.
